/*  
Desc:Get the All the Relation table and PJP plan Table    
*/  
CREATE PROCEDURE [dbo].[PROC_GETAllRelationTable]    
AS    
BEGIN    
    
CREATE TABLE #AllRelationTable (ID NUMERIC(18,0) IDENTITY (1,1),TableName VARCHAR(200))    
INSERT INTO #AllRelationTable    
SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES    
WHERE TABLE_NAME LIKE '%Relation'    
Union    
SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES    
WHERE TABLE_NAME LIKE 'Pjpplan'    
Union    
SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES    
WHERE TABLE_NAME LIKE 'PjpplanMaster'    
    
select * from #AllRelationTable    
    
END
go

