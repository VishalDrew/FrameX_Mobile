create procedure usp_GetSerchDetailsforTarget  
as  
begin  
select CityID,Name from CityMaster order by Name  
select ClassificationID,Name from ClassificationMaster order by Name  
end
go

