create procedure usp_ExistAuditQuestion  
@Question varchar(400)  
as  
begin  
select * from Auditmaster where Status=1 and AuditQuestion=@Question  
end
go

