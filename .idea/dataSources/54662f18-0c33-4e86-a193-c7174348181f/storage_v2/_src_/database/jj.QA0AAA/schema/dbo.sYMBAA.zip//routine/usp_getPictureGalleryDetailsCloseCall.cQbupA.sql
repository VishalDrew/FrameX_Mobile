   CREATE procedure usp_getPictureGalleryDetailsCloseCall  --'72','1=1','2014-10-07','2014-10-08'              
@FormID int,              
@Condition varchar(Max),            
@FromDate datetime,            
@ToDate datetime              
as              
begin              
              
declare @sql varchar(max)              
             
              
              
set @sql='SELECT SEM.StockEntryID, SEM.StockEntryId+''-''+Reason+''.jpg'' as Photo, TM.TargetID, TargetName, CM.Name as CityName, CLM.Name as ClassificationName       
FROM dbo.StockEntryMain SEM       
INNER JOIN dbo.TargetMaster   TM on TM.TargetID=SEM.TargetID      
INNER JOIN StockEntryCloseCall    PS on PS.StockEntryID=SEM.StockEntryID      
INNER JOIN dbo.CityMaster    CM on CM.CityID=TM.CityID              
INNER JOIN dbo.ClassificationMaster CLM on CLM.ClassificationID = TM.ClassificationID              
 where  '+@Condition+' and   
 Convert(varchar(10),SEM.EntryDate,120) >= '''+convert(varchar(10),@FromDate,120)+''' and Convert(Varchar(10),SEM.EntryDate,120)<= '''+ convert(varchar(10),@ToDate,120) +''''              
               
               
print(@sql)              
exec(@sql)              
           
              
end
   go

