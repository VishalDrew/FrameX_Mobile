
CREATE procedure usp_getalreadyenterentry-- '28208'   
@stockentryid varchar(150)
as    
begin    
    
select * from AuditEntryMain where  StockEntryID  = @stockentryid
    
end
go

