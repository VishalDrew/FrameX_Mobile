      
CREATE procedure usp_GetAuditQuestionforUpload      
as      
begin      
      
DECLARE @QuestionList nvarchar(max);      
SELECT @QuestionList = STUFF(      
(SELECT ', ' + quotename( AuditQuestion)      
FROM AuditMaster  where Status !=0    
GROUP BY AuditQuestion,AuditId      
ORDER BY AuditId      
FOR XML PATH(''))      
, 1, 2, '');    
--select @QuestionList   
  
  
  
      
DECLARE @query nvarchar(max);      
SET @query =      
'SELECT ''0'' as ''TargetID'', * FROM      
(      
    SELECT AuditID,AuditQuestion      
    FROM AuditMaster      
)t      
PIVOT (max(AuditID) FOR AuditQuestion      
IN ('+@QuestionList+')) AS pvt'      
  --print  (@query)       
 EXECUTE (@query)      
 end
go

