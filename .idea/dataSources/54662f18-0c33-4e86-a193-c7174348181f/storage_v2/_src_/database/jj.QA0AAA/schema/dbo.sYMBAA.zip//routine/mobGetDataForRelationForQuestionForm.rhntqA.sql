CREATE Procedure [dbo].[mobGetDataForRelationForQuestionForm]  --'Program_Question',' ChainID = 53 and RoleGroupID in (6,4)'                                                                
@TableName nvarchar(100),                                                                    
@Condition nvarchar(500)                                                                    
                                                                    
As                                                                    
BEgin                                                                    
Declare @ColumName nvarchar(100),                                                                    
        @ColumID nvarchar(100),                                                                     
        @RelationTableName nvarchar(100),                                                                    
        @MasterTableName nvarchar(100)                                                                    
                                                                            
        --Set @ColumName =@TableName+'Name'                                                                    
        Set @ColumID =@TableName+'ID'                                                                    
        Set @RelationTableName =@TableName+'Relation'                                                                    
        Set @MasterTableName =@TableName+'Master'                                                                    
DECLARE @cols nVARCHAR(MAX)                                         
select @cols= COALESCE(@cols + ', ' + FieldName + '','' +  FieldName + '') from FormFieldDetail inner join                                                             
FormMaster on FormMaster.FormID=FormFieldDetail.FormID                                                            
where FormMaster.Name=@TableName                          
and ForDEO='True' and ForPM='True'                                
if (@cols is null)                                                
begin                                                
return                                                
end                                                
else                                                
begin                                                          
EXEC('Select m.'+@ColumID+',m.CategoryId,m.QuestionMode,m.Qmodedatatype,QuestionRequired, '+@cols+'                                    
from '+@MasterTableName+' m inner join '+@RelationTableName+' r                                                                     
  on r.'+@ColumID+'=m.'+@ColumID+' Where m.status=''true'' and '+@Condition +' order by m.Sequence')            
  PRINT('Select m.'+@ColumID+',m.CategoryId,m.QuestionMode,m.Qmodedatatype,QuestionRequired, '+@cols+'                                    
from '+@MasterTableName+' m inner join '+@RelationTableName+' r                                                                     
  on r.'+@ColumID+'=m.'+@ColumID+' Where m.status=''true'' and '+@Condition +' order by m.Sequence')                                                                   
   Select FieldName,ControlType,[Required],                                                        
  FormLayout,DataType,AnswerByPM  From FormMaster                                                           
  inner join FormFieldDetail on FormMaster.FormID=FormFieldDetail.FormID                                                            
Where Name=@TableName and ForPM=1 and Fixed=1 and ForDEO=0 and ForQDEO=1                                    
UNION                                    
   Select FieldName,ControlType,[Required],                                                        
  FormLayout,DataType,AnswerByPM  From FormMaster                                                           
  inner join FormFieldDetail on FormMaster.FormID=FormFieldDetail.FormID                                                            
Where Name=@TableName and ForPM=0 and Fixed=0 and ForDEO=1 and ForQDEO=1                       
                                                             
EXEC('select FieldName,FormFieldOption.FormFieldOption,FormFieldOption.FQuestionID from FormFieldOption inner join                                                          
FormFieldDetail on FormFieldDetail.FormFieldID=FormFieldOption.FormFieldID                
inner join FormMaster on FormMaster.FormID=FormFieldOption.FormID                                                          
INNER join '+@RelationTableName+' r on r.'+@ColumID+'=Fquestionid                        
INNER JOIN '+@MasterTableName+' m on m.'+@ColumID+' = FQuestionId                                    
 Where m.status=''true'' AND '+@Condition +'   AND FormMaster.Name='''+@Tablename+'''')                                                           
                     
select FieldName,FormFieldOptionByPM.FormFieldOption,FormDataID from FormFieldOptionByPM inner join                                                            
FormFieldDetail on FormFieldDetail.FormFieldID=FormFieldOptionByPM.FormFieldID                                                          
inner join FormMaster on FormMaster.FormID=FormFieldOptionByPM.FormID                                                            
where FormMaster.Name=@TableName                   
                  
select FieldNAme,FormFieldDetail.Sequence,DisplayName From FormFieldDetail                   
INNER JOIN Formmaster ON Formmaster.FormId = FormFieldDetail.FormId                  
where FormMaster.Name=@TableName                  
and (ForPM=1 and Fixed=1 and ForDEO=0 and ForQDEO=1)                    
UNION                  
select FieldNAme,FormFieldDetail.Sequence,DisplayName From FormFieldDetail                   
INNER JOIN Formmaster ON Formmaster.FormId = FormFieldDetail.FormId                  
where FormMaster.Name=@TableName                  
AND  ForPM=1 and  ForDEO=1 and ForQDEO=1                   
                  
                  
                  
                  
                                                         
End                                                      
END             
          
          
          
          
           
go

