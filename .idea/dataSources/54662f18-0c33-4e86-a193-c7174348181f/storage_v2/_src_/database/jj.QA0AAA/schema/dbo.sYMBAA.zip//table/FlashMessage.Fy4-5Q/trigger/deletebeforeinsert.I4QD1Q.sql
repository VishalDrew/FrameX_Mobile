CREATE Trigger [dbo].[deletebeforeinsert] ON dbo.FlashMessage
 FOR INSERT 
AS BEGIN 
Delete From Flashmessage where id <> @@IDENTITY
END
go

