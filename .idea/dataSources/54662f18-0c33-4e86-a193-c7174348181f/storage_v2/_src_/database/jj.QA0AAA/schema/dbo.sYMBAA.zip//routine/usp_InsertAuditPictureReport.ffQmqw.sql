CREATE procedure usp_InsertAuditPictureReport    
@ReportName varchar(200),    
@ReportFilter varchar(500),    
@RowLabel varchar(500),    
@ReportStatus bit,    
@Mode int,    
@ReportID int    
as    
begin    
If(@Mode=1)    
BEGIN    
BEGIN TRY    
    
Insert into AuditPictureReport(ReportName,ReportFilter,RowLebel,ReportStatus)    
values(@ReportName,@ReportFilter,@RowLabel,@ReportStatus)    
select '1'    
END TRY    
BEGIN CATCH    
select '0'    
END CATCH    
    
END    
else if(@Mode=2)    
BEGIN    
BEGIN TRY    
update AuditPictureReport set  ReportName=@ReportName,ReportFilter=@ReportFilter,RowLebel=@RowLabel,ReportStatus=@ReportStatus where ReportID=@ReportID    
select '1'    
END TRY    
BEGIN CATCH    
select '0'    
END CATCH    
END    
else if(@Mode=3)    
BEGIN    
BEGIN TRY    
update AuditPictureReport set  ReportStatus='0' where ReportID=@ReportID    
select '1'    
END TRY    
BEGIN CATCH    
select '0'    
END CATCH    
END    
end
go

