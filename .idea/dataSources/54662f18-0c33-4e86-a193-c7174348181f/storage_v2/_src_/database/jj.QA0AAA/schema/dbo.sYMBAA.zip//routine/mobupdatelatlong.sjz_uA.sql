
  
CREATE PROC mobupdatelatlong   
@lat float,  
@long float,  
@targetid int  
AS BEGIN  
Update TargetMaster SET Latitude = @lat, Longitude=@long Where TargetID = @targetid  
END
go

