CREATE procedure usp_GetReportBasicandPictureAuditReport        
as        
begin        
select ReportID,RM.Name,RM.Filter,FM.Name as 'FormName',RM.ColumnLabel,RM.RowLabel,RM.ValueLabel,'ReportBasic' as 'RPTName' from ReportBasicMaster RM        
inner join FormMaster FM on FM.FormID=RM.FormID  where RM.ReportStatus=1       
        
Union ALl        
select ReportID,ReportName as 'Name',ReportFilter as 'Filter','' as 'FormName','' as 'ColumnLabel',ROwLebel as 'RowLabel','' as 'ValueLabel','AuditPicture' as 'RPTName' from AuditPictureReport        
end
go

