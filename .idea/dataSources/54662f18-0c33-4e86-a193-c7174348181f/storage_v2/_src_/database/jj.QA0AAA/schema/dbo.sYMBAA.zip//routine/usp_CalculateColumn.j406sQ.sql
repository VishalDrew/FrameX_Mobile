create procedure usp_CalculateColumn  
 @CalculateReportID int  
 as
begin  
 select ValueLabel,CalculateQuery from ReportCalculate where CalculateQuery<>'' and CalculateReportID=@CalculateReportID  
 end
go

