CREATE pROCEDURE [dbo].[GetJoinData] 
@TableName nvarchar(100)  
As  
Begin  
EXEC('Select Distinct B.'+@TableName+'ID as ID,B.Name From TargetMaster A inner join ' + @TableName + 'Master B on B.'+@TableName+'ID=A.'+@TableName+'ID ORDER BY B.Name')  
  
END
go

