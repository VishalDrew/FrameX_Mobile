
CREATE PROC RpTargetSelection          
AS BEGIN           
Select COLUMN_NAME from INFORMATION_SCHEMA.COLUMNS where TABLE_NAME = 'TargetMaster'          
AND COLUMN_NAME <> 'Sequence' and COLUMN_NAME <> 'Status' and COLUMN_NAME <> 'TargetID'        
AND COLUMN_NAME <> 'CreatedBy' AND COLUMN_NAME <> 'ModifiedBy'          
AND COLUMN_NAME <> 'CreatedDate' AND COLUMN_NAME <> 'ModifiedDate'         
      
select TableName = case when aa.TableName is null then isc.COLUMN_NAME else aa.TableName end,isc.COLUMN_NAME from INFORMATION_SCHEMA.COLUMNS isc      
left join       
(SELECT        
    COLUMN_NAME,        
    TableName =        
      CASE tc.CONSTRAINT_TYPE        
         WHEN 'FOREIGN KEY' THEN Replace(tc.CONSTRAINT_NAME,'FK_TargetMaster_','')        
         WHEN 'PRIMARY KEY' THEN 'TargetID'                
         ELSE tc.CONSTRAINT_NAME      
      END         
FROM        
    INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc        
    INNER JOIN        
    INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE ccu ON tc.CONSTRAINT_NAME = ccu.Constraint_name        
WHERE        
    tc.TABLE_NAME = 'TargetMaster'           
            
      )aa on aa.COLUMN_NAME=isc.COLUMN_NAME where isc.TABLE_NAME='TargetMaster'      
  --AND isc.COLUMN_NAME <> 'Sequence' and isc.COLUMN_NAME <> 'Status' and isc.COLUMN_NAME <> 'TargetID'        
  AND isc.COLUMN_NAME <> 'Sequence' and isc.COLUMN_NAME <> 'Status'     
  AND isc.COLUMN_NAME <> 'CreatedBy' AND isc.COLUMN_NAME <> 'ModifiedBy'          
  AND isc.COLUMN_NAME <> 'CreatedDate' AND isc.COLUMN_NAME <> 'ModifiedDate'      
       
END
go

