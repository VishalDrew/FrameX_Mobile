CREATE PROC spInsertExitStore        
      
 @TragetID int,             
 @ExitTime datetime,        
 @username varchar(200),        
 @RoleID int         
      
as  
Begin        
  insert into ExitStore(TragetID,ExitTime,username,RoleID,Createddate)        
  values(@TragetID,@ExitTime,@username,@RoleID,GETDATE())        
End
go

