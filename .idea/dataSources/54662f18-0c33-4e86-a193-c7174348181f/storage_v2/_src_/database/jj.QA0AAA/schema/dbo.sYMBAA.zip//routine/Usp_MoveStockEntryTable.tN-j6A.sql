CREATE procedure [dbo].[Usp_MoveStockEntryTable]

as
BEGIN
SET NOCOUNT ON;
 DECLARE @MyTable TABLE
(
  
  Name varchar(500),
  rowid int
)
 insert into @MyTable
 
 select Name+'StockEntry' as Name, ROW_NUMBER()over(order by name)as rowNo from FormMaster
 --select * from @MyTable
 DECLARE @intMax INT
 set @intMax= @@ROWCOUNT;
 DECLARE @intFlag INT
 SET @intFlag = 1
	WHILE (@intFlag <=@intMax)
	BEGIN
		DECLARE @Table_Name sysname, @DynamicSQL nvarchar(4000)
	    declare @tableName nvarchar(200);
	    set @tableName= (select name from @MyTable where rowid= @intFlag);
	    SET @Table_Name = @tableName
	    
	    declare @tblStockEntry Table
	    (
	     stockEntryID nvarchar(500),
	     row_ID int
	    )
	    insert into @tblStockEntry
	    select StockEntryID, ROW_NUMBER()  OVER (Order by StockEntryID) from StockEntryMain where EntryDate <= DATEADD(mm, -4, GETDATE()) order by EntryDate
	    Declare @iMax int
	    set @iMax=@@ROWCOUNT
	    Declare @i int
	    set @i=1;
	    WHILE(@i<=@iMax)
			BEGIN
			    declare @stockEntryID nvarchar(500)
			    set @stockEntryID = (select StockEntryID from @tblStockEntry where row_ID=@i)
				SET @DynamicSQL = N'Delete from '+@Table_Name+' where StockEntryID='+@stockEntryID
				EXECUTE sp_executesql @DynamicSQL
	 			set @i = @i + 1
			END
	 END
	 	set @intFlag = @intFlag + 1
	END
--exec Usp_DeleteRelationTable
go

