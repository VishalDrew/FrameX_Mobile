CREATE Procedure GetManageRelationControls --'SKU'  
 @TableName nvarchar(100)  
   
 AS  
 BEGIN  
 SELECT      
    COLUMN_NAME,  
    REPLACE(COLUMN_NAME,'ID','Master') as  'TABLE_NAME',  
    ControlType = CASE COLUMN_NAME  
     WHEN 'TargetID' THEN 'TextBox'       
     ELSE 'DropDownList'  
    END  
       
FROM      
    INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc      
    INNER JOIN      
    INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE ccu ON tc.CONSTRAINT_NAME = ccu.Constraint_name      
WHERE      
    (                
        tc.CONSTRAINT_TYPE = 'Foreign Key'      
    )      
    AND      
    tc.TABLE_NAME =@TableName+'Relation'   
    and COLUMN_NAME <> @TableName+'ID'  
      
      
    DECLARE @List VARCHAR(1000)  
Select  @List = COALESCE(@List + ', ', '') + COLUMN_NAME   
 FROM      
    INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc      
    INNER JOIN      
    INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE ccu ON tc.CONSTRAINT_NAME = ccu.Constraint_name      
WHERE      
    (                
        tc.CONSTRAINT_TYPE = 'Foreign Key'      
    )      
    AND      
    tc.TABLE_NAME =@TableName+'Relation'   
    and COLUMN_NAME <> @TableName+'ID'  
   
   
 EXEC('Select Distinct '+@List+' From TargetMaster')  
  
           
     
      
END
go

