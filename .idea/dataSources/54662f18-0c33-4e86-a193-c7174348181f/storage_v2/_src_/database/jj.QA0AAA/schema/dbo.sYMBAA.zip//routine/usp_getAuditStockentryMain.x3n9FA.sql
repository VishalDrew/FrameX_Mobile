
CREATE procedure usp_getAuditStockentryMain --'13572'               
@TargetID int                
as                
begin                
    --DECLARE @TargetID int='20530'          
 SELECT top 4 * from StockEntryMain           
 WHERE TargetID=@TargetID           
 AND StockEntryID not in(select StockEntryID from AuditEntryMain)        
 AND StockEntryID IN(Select StockEntryID From PictureStockEntry)         
 AND EntryDate > (GETDATE()-30)          
  ORDER BY NEWID()  
 --   ORDER BY EntryDate         
end         
--CREATE procedure usp_getAuditStockentryMain-- '28208'   
--@TargetID int    
--as    
--begin    
    
--select * from StockEntryMain where TargetID=@TargetID and StockEntryID not in(select StockEntryID from AuditEntryMain)    
    
--end 
go

