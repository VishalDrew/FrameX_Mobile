
CREATE Proc [dbo].[SelectEnumDBForSequenceUpdate]-- 'Usermaster'        
@enumtype varchar(500)        
as        
        
Begin        
  select       
  FieldControlID as 'FieldID',  
  FieldName        
 ,enum.Sequence       
           
   from EnumFieldControlInfo enum         
  inner join information_schema.columns on COLUMN_NAME = enum.FieldName         
        
  where table_name = @enumtype and enum.FormName=@enumtype        
        
End  
  
  
select * from EnumFieldControlInfo where FormName='TargetMaster'
go

