create PROC [dbo].[GetAllFormMaster_Export]  
As   
 begin    
  Select Name as FormName, FormSequence, FormStatus,REPLACE(FormMaster.FormMapWith,'%',',') as Mapping  
      From FormMaster order by Name  
 END
go

