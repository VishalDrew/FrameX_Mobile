CREATE procedure usp_GerUserrolebyID  
@RoleID varchar(20)  
as
begin  
select Name from RoleMaster where RoleID=@RoleID  
end
go

