
CREATE procedure usp_CheckDEOField  
@TableName varchar(500)  
as
begin  

Declare @Isquestionform varchar(20)
set @Isquestionform=(select IsQuestionForm from FormMaster where Name=@TableName)

if(@Isquestionform='0')
	BEGIN
	
		Select FieldName,ControlType,[Required],                          
		  FormLayout,DataType,AnswerByPM  From FormMaster                             
		  inner join FormFieldDetail on FormMaster.FormID=FormFieldDetail.FormID                              
		Where Name=@TableName and ForDEO='True' and ForPM = 'False'  
	END
ELSE
	BEGIN
				Select FieldName,ControlType,[Required],                                  
		  FormLayout,DataType,AnswerByPM  From FormMaster                                     
		  inner join FormFieldDetail on FormMaster.FormID=FormFieldDetail.FormID                                      
		Where Name=@TableName and ForPM=1 and Fixed=1 and ForDEO=0 and ForQDEO=1              
		UNION              
			   Select FieldName,ControlType,[Required],                                  
			  FormLayout,DataType,AnswerByPM  From FormMaster                                     
			  inner join FormFieldDetail on FormMaster.FormID=FormFieldDetail.FormID                                      
			Where Name=@TableName and ForPM=0 and Fixed=0 and ForDEO=1 and ForQDEO=1  

	END

 
end
go

