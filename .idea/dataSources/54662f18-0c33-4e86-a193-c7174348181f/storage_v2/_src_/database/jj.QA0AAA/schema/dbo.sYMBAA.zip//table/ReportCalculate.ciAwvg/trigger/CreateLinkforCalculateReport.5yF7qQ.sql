CREATE  TRIGGER [dbo].[CreateLinkforCalculateReport]  
ON [dbo].[ReportCalculate]  
AFTER INSERT
AS   
BEGIN
	declare @Name varchar(500),@ReportID int,@CreatedBy varchar(50)
	
	select @Name = Name from inserted
    
	select @ReportID = CalculateReportID from inserted
	select @CreatedBy = CreatedBy from inserted

	insert into SubSectionMaster values (22,@Name,'ReportCalculated.aspx?ID=' + convert(varchar,@ReportID),'True',@CreatedBy,@CreatedBy,getdate(),getdate())
END
go

