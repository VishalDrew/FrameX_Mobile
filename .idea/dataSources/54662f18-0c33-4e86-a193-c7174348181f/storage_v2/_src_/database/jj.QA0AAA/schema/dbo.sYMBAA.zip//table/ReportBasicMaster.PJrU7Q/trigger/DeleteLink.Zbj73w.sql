


CREATE  TRIGGER [dbo].[DeleteLink]  
ON [dbo].[ReportBasicMaster]  
AFTER Delete
AS   
BEGIN
	declare @Name varchar(500),@ReportID int
	select @ReportID = ReportID from deleted
	select @Name = 'ReportBasic.aspx?ID='+Convert(varchar,@ReportID)
	declare @subsecID int
	select @subsecID= subsectionid from SubSectionMaster where FormPathName = @Name
	Delete from RoleAccessManagement where SubsectionID=@subsecID
	Delete From SubSectionMaster Where FormPathName = @Name


	
END

go

