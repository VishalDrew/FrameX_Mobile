CREATE Proc GetformDetail  --asset            
@tablename nvarchar(100)                  
as begin                  
Exec('Select '+@tablename+'Master.Status AS DisplayStatus,Categorymaster.Name AS CategoryName,      
RoleGroupmaster.Name AS RoleName, '+@tablename+'Master.* from '+@tablename+'Master             
INNER JOIN Categorymaster ON Categorymaster.CategoryID = '+@tablename+'Master.CategoryId            
INNER JOIN RoleGroupMaster ON RoleGroupMaster.RoleGroupID = '+@tablename+'Master.RoleGroupID      
order by '+@tablename+'Master.Sequence'        
)                
end
go

