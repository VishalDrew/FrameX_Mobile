CREATE procedure usp_UpdateTargetbyExcelsheet --'select * from TargetMaster where TargetID=28706'    
@query varchar(max)    
as    
begin    
  
BEGIN TRY  
    -- Generate a divide-by-zero error.  
   exec(@query)  
   select '1'  
  
END TRY  
BEGIN CATCH  
    SELECT  
         
        ERROR_MESSAGE() AS ErrorMessage;  
END CATCH;  
    
end    
    
    
    
--select * from TargetMaster where TargetName='testtarget'
go

