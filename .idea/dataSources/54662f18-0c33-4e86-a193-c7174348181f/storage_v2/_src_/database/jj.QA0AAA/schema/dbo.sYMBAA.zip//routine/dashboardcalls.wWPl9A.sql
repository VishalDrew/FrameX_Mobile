
      
CREATE proc dashboardcalls --''      
@userid varchar(200)      
As begin      
      
if (@userid = '')      
begin      
Select Count(TargetID) FROM StockEntryMain Where Convert(varchar,Entrydate,102) = Convert(varchar,GETDATE()-1,102)        
Select Count(TargetID) FROM StockEntryMain Where Convert(varchar,Entrydate,102) >= Convert(varchar,GETDATE()-7,102)        
Select Count(TargetID) FROM StockEntryMain Where Convert(varchar,Entrydate,102) >= Convert(varchar,GETDATE()-15,102)        
Select Count(Distinct TargetID) FROM StockEntryMain Where Convert(varchar,Entrydate,102) >= Convert(varchar,GETDATE()-15,102)        
Select COUNT(TargetId) from TargetMaster WHERE Status=1
Select Count(userId) From UserMaster WHERE Status=1
end      
else       
begin      
Select Count(TargetID) FROM StockEntryMain Where Convert(varchar,Entrydate,102) = Convert(varchar,GETDATE()-1,102)    AND Username= @userid      
Select Count(TargetID) FROM StockEntryMain Where Convert(varchar,Entrydate,102) >= Convert(varchar,GETDATE()-7,102)    AND Username= @userid      
Select Count(TargetID) FROM StockEntryMain Where Convert(varchar,Entrydate,102) >= Convert(varchar,GETDATE()-15,102)    AND Username= @userid      
Select Count(Distinct TargetID) FROM StockEntryMain Where Convert(varchar,Entrydate,102) >= Convert(varchar,GETDATE()-15,102)   AND Username= @userid      
Select COUNT(TargetId) from TargetMaster WHERE Status=1
Select Count(userId) From UserMaster WHERE Status=1
end      
end 
go

