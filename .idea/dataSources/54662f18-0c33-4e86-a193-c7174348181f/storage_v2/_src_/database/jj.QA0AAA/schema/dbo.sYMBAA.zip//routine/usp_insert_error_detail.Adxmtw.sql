
CREATE PROC usp_insert_error_detail
@page_name varchar(max),
@error_message varchar(max)
AS BEGIN 
INSERT INTO errordetail(pagename,errormessage) VALUES(@page_name,@error_message)
END
go

