CREATE Proc [dbo].[getentryid]        
@targetid int,        
@entrydate datetime,        
@roleid int     
      
AS begin

SELECT stockentryid from mobblockstores Where targetid = @targetid AND entrydate = @entrydate AND roleid = @roleid  

       
END
go

