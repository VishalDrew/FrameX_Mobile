CREATE procedure usp_getFieldNamebyFormID-- '86'  
@FormID int  
as  
begin  
select FormFieldID,FormID,FieldName from FormFieldDetail where FormID=@FormID and FieldName='QuestionMode'  
end
go

