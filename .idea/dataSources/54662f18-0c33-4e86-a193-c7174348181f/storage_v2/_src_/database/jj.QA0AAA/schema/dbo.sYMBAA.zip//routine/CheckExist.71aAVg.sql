CREATE PROC CheckExist --'CityMaster','<row>    <Name>3</Name></row><row>	<Name>11</Name></row>'
@enumtype varchar(100),
@XML xml
As 
begin

declare @temp table (Name varchar(100))

insert into @temp
exec('select Name from '+ @enumtype)

--select * from @temp

select * from @temp enum
inner join 
(SELECT  
       Tbl.Col.value('Name[1]', 'varchar(500)') Name  
FROM   @xml.nodes('//row') Tbl(Col)
)aa
on aa.Name=enum.Name

End
go

