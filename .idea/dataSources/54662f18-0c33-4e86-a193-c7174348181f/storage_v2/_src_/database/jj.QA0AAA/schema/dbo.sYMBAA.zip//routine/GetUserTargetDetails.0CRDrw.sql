
CREATE Procedure [dbo].[GetUserTargetDetails]  --'TargetMaster','10001'      
@tableName nvarchar(50),      
@ID nvarchar(50)      
      
as            
begin            
      
--declare @tableName nvarchar(50) = 'UserMaster',@ID varchar(100) = '10063'      
      
      
    DECLARE  @imax INT,             
             @i    INT             
    DECLARE  @Contact VARCHAR(100),             
             @Company VARCHAR(50)             
 DECLARE  @where varchar(500)      
 if(@ID = 'All')      
 set @where = ' 1=1 '      
 else      
 set @where = SUBSTRING(@tableName, 0, len(@tableName)-5) +'ID = '+@ID+' '      
      
   DECLARE @MainTable nvarchar(60)            
   DECLARE @Full_String nvarchar(4000)            
   DECLARE @ColumName nvarchar(4000)            
   DECLARE @OrderBy nvarchar(4000)            
   set @MainTable='a';             
      
   DECLARE  @CompanyInfo  TABLE(             
                                 RowID       INT    IDENTITY ( 1 , 1 ),             
                                 CompanyName VARCHAR(100),             
                                 ContactName VARCHAR(50)             
                                 )             
    INSERT @CompanyInfo             
   SELECT            
    FieldName,FieldName      
FROM            
    EnumFieldControlInfo           
WHERE            
    FormName =@tableName and FieldName like '%ID' and FieldName<> SUBSTRING(@tableName, 0, len(@tableName)-5) +'ID'        
      
--select * from @CompanyInfo      
                 
    SET @imax = @@ROWCOUNT             
    SET @i = 1             
                 
    WHILE (@i <= @imax)             
      BEGIN             
        SELECT @Contact = ContactName,             
               @Company = CompanyName             
        FROM   @CompanyInfo             
        WHERE  RowID = @i                    
           
           
                   
        set @ColumName=ISNULL(@ColumName,'') +',' +REPLACE(@Contact,'ID','')+'.Name as '''+REPLACE(@Contact,'ID',' Name') +'''';            
         
       set @Full_String=ISNULL(@Full_String,'') +  ' left join ' +  REPLACE(@Contact,'ID','Master') + ' ' +  REPLACE(@Contact,'ID','') +' on '+ @MainTable +'.'+ @Contact + ' = ' + REPLACE(@Contact,'ID','') +'.'+@Contact              
         
        SET @i = @i + 1             
      END -- WHILE            
                  
                    
      DECLARE @List VARCHAR(1000)            
            
     Select  @List =COALESCE(@List + ', ', '') + FieldName             
     From EnumFieldControlInfo            
     Where FormName=@tableName             
     set @List=  REPLACE(','+@list,',',',a.')            
      set @ColumName=  SUBSTRING(@ColumName,2,(LEN(@ColumName)))            
      -- select @ColumName            
       set @ColumName=  REPLACE(@ColumName,'.*.*','')            
             
          set @OrderBy= Replace(@TableName,'Master','Name')        
   --print    'Select '+@ColumName+' '+@List+' From '+@tableName+' a ' + @Full_String +' where a.Status=''True'' and '+ @where+' Order By a.'+@OrderBy      
   EXEC('Select '+@ColumName+' '+@List+' From '+@tableName+' a ' + @Full_String +' where a.Status=''True'' and '+ @where+' Order By a.'+@OrderBy)      
    print('Select '+@ColumName+' '+@List+' From '+@tableName+' a ' + @Full_String +' where a.Status=''True'' and '+ @where+' Order By a.'+@OrderBy)      
      
select * from @CompanyInfo      
      
end


go

