CREATE Proc getstoreform            
            
AS Begin            
Select Name,Formmapwith,FormLayout,IsQuestionForm,Formsequence From FormMaster Where Formstatus = 1   ORDER BY  FORMSequence        
End
go

