CREATE PROC [dbo].[GetSpecificEnumDataForFormAttribute] -- 'EnumMeta',''                  
@enumtype varchar(100),                  
@enumid varchar(100)                  
As                   
begin                  
                  
declare @columnName varchar(100),@query varchar(100)                  
DECLARE @intErrorCode INT          
BEGIN TRAN          
if(@enumid = '')                  
 begin                  
  SELECT @columnName = column_name                  
  FROM INFORMATION_SCHEMA.COLUMNS                  
  WHERE Right(column_name,4) = 'Name'                  
  AND table_name = @enumtype                
              
SELECT @intErrorCode = @@ERROR          
IF (@intErrorCode <> 0) GOTO PROBLEM          
  IF (@enumtype='FormMaster')      
 BEGIN      
 exec('Select * from '+ @enumtype +' where Name<>''Picture'' order by '+ @columnName + ' asc')            
 END      
   ELSE      
 BEGIN      
 --exec('Select * from '+ @enumtype +'  order by '+ @columnName + ' asc')        
 exec('Select * from '+ @enumtype +' order by '+ @columnName + ' asc')           
 END      
        
          
SELECT @intErrorCode = @@ERROR          
IF (@intErrorCode <> 0) GOTO PROBLEM          
               
  exec('Select Validation from EnumMeta where EnumName='''+@enumtype+'''')                 
          
SELECT @intErrorCode = @@ERROR          
IF (@intErrorCode <> 0) GOTO PROBLEM          
          
 END                  
ELSE                   
 begin                   
  SELECT @columnName = column_name                  
  FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE                  
  WHERE OBJECTPROPERTY(OBJECT_ID(constraint_name), 'IsPrimaryKey') = 1                  
  AND table_name = @enumtype                  
            
SELECT @intErrorCode = @@ERROR          
IF (@intErrorCode <> 0) GOTO PROBLEM          
                  
  exec('Select * from '+ @enumtype +' where '+ @columnName +' = '+ @enumid +' order by Name asc')                
          
SELECT @intErrorCode = @@ERROR          
IF (@intErrorCode <> 0) GOTO PROBLEM          
          
   exec('Select Validation from EnumMeta where EnumName='''+@enumtype+'''')                  
          
SELECT @intErrorCode = @@ERROR          
IF (@intErrorCode <> 0) GOTO PROBLEM          
          
 END                  
end           
          
COMMIT TRAN          
          
PROBLEM:          
IF (@intErrorCode <> 0)           
BEGIN          
 Select 'Error'          
    ROLLBACK TRAN          
END
go

