CREATE trigger [dbo].[AddColumn] 
on [dbo].[FormFieldDetail]
After insert
AS
Begin

declare @columnname nvarchar(50), @datattype nvarchar(50) ,@formID int ,@formName nvarchar(60),@PM bit,@formfieldid int
declare @controlType nvarchar(50)
select @controlType = ControlType From inserted 
select @columnname = FieldName From inserted
select @formfieldid = FormFieldID from inserted


	if(@controlType = 'CheckBoxList')
	begin
		select @datattype = 'varchar(MAX)'
	end
	else
	begin
		select @datattype =Datatype From inserted
	end

select @formID =FormID From inserted
select @PM=ForPM from inserted 
select @formName =Name From FormMAster Where FormID=@formID

Select @datattype = Case When @datattype like 'Email%' THEN 'varchar(200)' else @datattype end 

if(@PM='true')
begin
Exec('Alter  table '+@formName+'Master  Add '+@columnname+' '+ @datattype +' null')
END
else
begin
Exec('Alter  table '+@formName+'StockEntry  Add '+@columnname+' '+ @datattype +' null')
Exec('Alter  table mob'+@formName+'StockEntry  Add '+@columnname+' '+ @datattype +' null')
END
update FormFieldDetail set Displayname = REPLACE(@columnname,'_',' ') where FormFieldID = @formfieldid

END
go

