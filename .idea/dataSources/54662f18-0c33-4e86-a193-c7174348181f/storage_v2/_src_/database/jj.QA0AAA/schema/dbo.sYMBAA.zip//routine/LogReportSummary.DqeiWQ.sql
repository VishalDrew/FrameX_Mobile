CREATE Proc LogReportSummary    
AS
Begin    
    
select COUNT(*) as 'Today Call' from PjpPlanMaster     
where CONVERT (varchar,Pjpdate,102) = CONVERT(varchar,getdate()-1,102)    
(select COUNT(*) as 'Pending Call' from Pjpplan where Status='P')     
select COUNT(*) as 'Attempted Call' from PjpPlan    
where CONVERT (varchar,Pjpdate,102) = CONVERT(varchar,getdate()-1,102) AND Status = 'A'    
SELECT COUNT(*) 'Upload Call' FROM StockEntryMain where CONVERT (varchar,dActaulEntryDate,102) = CONVERT(varchar,getdate()-1,102)     
AND cMobileNo <> 'Web'    
    
select COUNT(*) 'Not Upload Call' from PjpPlan    
where CONVERT (varchar,Pjpdate,102) = CONVERT(varchar,getdate()-1,102) AND Status = 'A' AND TargetId NOT IN(    
SELECT TargetId FROM StockEntryMain where CONVERT (varchar,dActaulEntryDate,102) = CONVERT(varchar,getdate()-1,102)     
AND cMobileNo <> 'Web')   
(select COUNT(*) as 'ExpiredCall' from Pjpplan where Status='E'  )      
END
go

