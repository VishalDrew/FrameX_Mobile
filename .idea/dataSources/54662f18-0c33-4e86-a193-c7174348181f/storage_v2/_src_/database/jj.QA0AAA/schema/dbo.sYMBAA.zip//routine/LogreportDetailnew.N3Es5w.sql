  
CREATE Proc LogreportDetailnew  
as begin  
select PjpTargetId,PjpUserName,'T' as Status  from PjpPlanMaster           
where CONVERT (varchar,Pjpdate,102) = CONVERT(varchar,getdate()-1,102)    
Union All  
Select TargetId,username,ISNULL((select 'TAU'  from PjpPlanMaster Where PjpTargetID = otr.TargetId     
 and  CONVERT(varchar,Pjpdate,102) = CONVERT (varchar,otr.EntryDate,102) and PjpUserName = otr.UserName),'PAU') as Status  
 From StockEntryMain otr Where  CONVERT (varchar,otr.EntryDate,102) = CONVERT(varchar,getdate()-1,102) and cMobileNo <> 'Web'  
Union All  
  
select TargetId,username,'ANU' as Status From PjpPlan Where Status = 'A'   
and CONVERT(varchar,Pjpdate,102) = CONVERT(varchar,getdate()-1,102)    
AND TargetId NOT IN(select SEM.TargetID  from StockEntryMain SEM Where     
 CONVERT (varchar,EntryDate,102) = CONVERT(varchar,GETDATE()-1,102) and SEM.username = Pjpplan.username)    
  Union All  
  Select TargetId,username, 'TNA' Status From PjpPlan where Status = 'T' AND CONVERT(varchar,Pjpdate,102) = CONVERT(varchar,getdate()-1,102)    
  Union All  
  Select  TargetId,username, 'PNA' Status From PjpPlan where Status = 'P'     
  Union All  
  Select TargetId,username, 'Expired' Status From Pjpplan where Status = 'E'      
  end
go

