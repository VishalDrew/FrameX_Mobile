CREATE procedure usp_updateQuestionformForPM  
@formid int  
as  
begin  
update FormFieldDetail set ForPM=0, ForDEO=1 where FieldName='QuestionMode' and FormID=@formid  
  
end
go

