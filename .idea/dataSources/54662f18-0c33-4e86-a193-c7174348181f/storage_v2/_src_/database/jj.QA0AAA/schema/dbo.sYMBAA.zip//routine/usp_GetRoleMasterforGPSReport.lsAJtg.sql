CREATE procedure usp_GetRoleMasterforGPSReport    
 as    
 begin    
     
 select RoleID,Name  from RoleMaster where Name not in('admin','Projectmanager') and Status=1 order by RoleID    
 end
go

