CREATE procedure usp_FormFieldFieldDetaislforDumpReport --'Program_Question'
@FormName varchar(200)
as
BEGIN
 declare @ID varchar(10)
 declare @IsQuestionForm varchar(200)
 set @ID=( select FormID from FormMaster where Name=@FormName)
 set @IsQuestionForm=( select IsQuestionForm  from FormMaster where Name=@FormName)
 if(@IsQuestionForm='1')
 BEGIN
 select * from FormFieldDetail where FormID=@ID and ForPM=1 and ForDEO=0 and ForQDEO=1
 select * from FormFieldDetail where FormID=@ID and ForPM=1 and ForDEO=1 and ForQDEO=1
 END
 ELSE
 BEGIN
 select * From FormFieldDetail where FormID=@ID  and ForPM=0 and ForDEO=1
 select FieldName from FormFieldDetail where ForPM=1 and ForDEO=1 and FormID=@ID
 END
 
 END
go

