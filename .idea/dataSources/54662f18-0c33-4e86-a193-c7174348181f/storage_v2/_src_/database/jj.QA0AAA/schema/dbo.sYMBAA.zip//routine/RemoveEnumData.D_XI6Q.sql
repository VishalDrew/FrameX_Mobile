CREATE PROC [dbo].[RemoveEnumData]   --'GroupMaster','2'  
@enumtype varchar(100),
@enumid varchar(100)  
As 
if(@enumid <> '') 
begin  
	declare @columnName varchar(100)

	  SELECT @columnName = column_name  
	  FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE  
	  WHERE OBJECTPROPERTY(OBJECT_ID(constraint_name), 'IsPrimaryKey') = 1  
	  AND table_name = @enumtype 
	--select @columnName
	
	--print('Delete from '+ @enumtype +' where '+ @columnName +' = '+ @enumid)
	
	exec('Delete from '+ @enumtype +' where '+ @columnName +' = '+ @enumid)  
	
	select '1'
end
go

