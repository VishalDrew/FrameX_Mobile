create procedure mobGetRoleGroupID  
@RoleId int  
as  
begin  
  
DECLARE @List VARCHAR(8000)  
  
SELECT @List = COALESCE(@List + ',', '') + CAST(RoleGroupID AS VARCHAR)  
FROM   RoleGroupMapping where RoleID=@RoleId  
SELECT @List as 'RolegroupID'  
end
go

