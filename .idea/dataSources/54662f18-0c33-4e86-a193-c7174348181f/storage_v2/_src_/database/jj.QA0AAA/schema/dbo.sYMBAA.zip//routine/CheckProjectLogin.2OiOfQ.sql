

Create proc [dbo].[CheckProjectLogin]   
@usrUserName varchar(500),      
@usrPassword varchar(500)      
as      
  
IF exists(select UserName from UserMaster where UserName=@usrUserName and Password=@usrPassword and Status='True')      
Begin      
	select * from UserMaster where UserName=@usrUserName and Password=@usrPassword and Status='True'
End      
Else      
Begin   
	select '0'   
End
go

