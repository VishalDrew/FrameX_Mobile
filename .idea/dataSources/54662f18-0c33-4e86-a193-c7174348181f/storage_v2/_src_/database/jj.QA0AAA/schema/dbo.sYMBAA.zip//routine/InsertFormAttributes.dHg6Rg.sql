CREATE Procedure InsertFormAttributes
@FormID int
,@FieldName varchar(100)
,@DataType varchar(200)
,@ControlType varchar(200)
,@Required bit
,@ForPM bit
,@ForDEO bit


As
Begin
  
if not exists (Select FormFieldID From FormFieldDetail Where FormID=@FormID and FieldName=@FieldName )
begin
INSERT INTO [FormFieldDetail]
           ([FormID]
           ,[FieldName]
           ,[DataType]
           ,[ControlType]
           ,[Required]
           ,[ForPM]
           ,[ForDEO]
           )
     VALUES
           (@FormID
           ,@FieldName
           ,@DataType
           ,@ControlType
           ,@Required
           ,@ForPM
           ,@ForDEO
           )
           Select @@IDENTITY
END
Else
Begin
Select '-1'
END

END
go

