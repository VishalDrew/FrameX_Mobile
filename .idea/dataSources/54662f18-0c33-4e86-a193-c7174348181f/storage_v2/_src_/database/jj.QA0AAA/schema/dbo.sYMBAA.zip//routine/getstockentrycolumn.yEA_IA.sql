CREATE Proc getstockentrycolumn    --'AssetStockEntry'  
@tablename varchar(100)      
As Begin      
Declare @sqlquery varchar(250)   
set @sqlquery = 'Select Top 1 * From '+ @tablename+' where 1 <>1'  
EXEC(@sqlquery)  
END
go

