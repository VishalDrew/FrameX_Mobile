CREATE Proc [dbo].[SelectEnumDB] --'Usermaster'  
@enumtype varchar(500)  
as  
  
Begin  
  select enum.FieldName,enum.Fieldvalidation,  
  REPLACE(enum.FieldName,'_',' ') AS FieldNameDisplay,  
   [Data_Type] =   
       case   
        when [Data_Type]='varchar'   
         then 'string'   
        when [Data_Type]='int' or [Data_Type]='bigint'  
         then 'numeric'   
       else [Data_Type]   
       end  
   ,character_maximum_length AS MaxLimit      
   ,enum.Fieldvalidation     
   ,[dbo].[fnGetFieldStatus] (@enumtype , enum.FieldName) EnumMaster  
   ,enum.Fixed,enum.Sequence 
     
   from EnumFieldControlInfo enum   
  inner join information_schema.columns on COLUMN_NAME = enum.FieldName   
  
  where table_name = @enumtype and enum.FormName=@enumtype  
  
End
go

