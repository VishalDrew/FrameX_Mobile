Create procedure usp_GetFormForDataTableforPictureAuditNew  
as  
begin  
  
  
select SUBSTRING(FormMapWith,1,LEN(FormMapWIth)-1) +'/'+Name+'Relation' from FormMaster where IsPictureForm=1  
end
go

