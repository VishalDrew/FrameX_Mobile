CREATE trigger [dbo].[createlinkinsubsection]
on [dbo].[AuditPictureReport]
after insert
as
begin
declare @Name varchar(200)
select @Name=ReportName from inserted
INSERT INTO SubSectionMaster(SectionID,SubSectionName,FormPathName,Status,CreatedBy,ModifiedBy,CreatedDate,ModifiedDate)
VALUES ('22',@Name,'AuditPictureReport.aspx','True','defualtpm','defaultpm',GETDATE(),GETDATE())

end
go

