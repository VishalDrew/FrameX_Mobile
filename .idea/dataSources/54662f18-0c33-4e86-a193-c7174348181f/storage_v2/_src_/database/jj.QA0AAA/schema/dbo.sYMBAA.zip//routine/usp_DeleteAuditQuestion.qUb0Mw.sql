CREATE procedure usp_DeleteAuditQuestion    
@AuditID int    
    
as    
begin    
BEGIN TRY    
update Auditmaster set Status=0 where AuditId=@AuditID    
select '1'    
END TRY    
BEGIN CATCH    
select '0'    
END CATCH    
end


go

