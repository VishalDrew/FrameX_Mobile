CREATE PROC getTargetAttributefordataentry
as begin
select * From TargetAttributesDetail
end
go

