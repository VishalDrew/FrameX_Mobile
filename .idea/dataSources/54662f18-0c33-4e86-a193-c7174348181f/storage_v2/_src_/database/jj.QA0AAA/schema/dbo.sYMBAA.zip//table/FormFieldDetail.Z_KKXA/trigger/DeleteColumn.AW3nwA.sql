-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE  TRIGGER [dbo].[DeleteColumn]
   ON  [dbo].[FormFieldDetail] 
   AFTER DELETE
AS 
BEGIN
	declare @columnname nvarchar(50), @datattype nvarchar(50) ,@formID int ,@formName nvarchar(60),@PM bit,@oldColumname nvarchar(50),@ControlType nvarchar(50),@FormFieldID nvarchar(50)

select @columnname = FieldName From deleted 
select @datattype =Datatype From deleted
select @formID =FormID From deleted
select @PM=ForPM from deleted 
select @formName =Name From FormMAster Where FormID=@formID
SELECT @oldColumname = FieldName FROM deleted
SELECT @ControlType =ControlType FROM deleted
SELECT @FormFieldID =FormFieldID FROM deleted
 
if(@ControlType <> 'Textbox')
begin
Exec('Delete From FormFieldOption Where FormFieldID ='+@FormFieldID+'')
end

if(@PM='true')
begin
Exec('ALTER TABLE '+@formName+'Master DROP COLUMN '+@oldColumname+'')
END
else
begin
Exec('ALTER TABLE '+@formName+'StockEntry DROP COLUMN '+@oldColumname+'')
Exec('ALTER TABLE mob'+@formName+'StockEntry DROP COLUMN '+@oldColumname+'')
END
END
go

