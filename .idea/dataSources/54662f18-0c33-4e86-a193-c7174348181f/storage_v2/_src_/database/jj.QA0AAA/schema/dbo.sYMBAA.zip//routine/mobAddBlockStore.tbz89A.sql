      
CREATE procedure [dbo].[mobAddBlockStore]      
     @targetid int,      
           @entrydate datetime,      
           @roleid int,      
           @stockentryid varchar(150),                
           @username varchar(100)      
as      
begin      
      
      
BEGIN TRY      
BEGIN TRAN      
update PjpPlan Set Status = 'A' Where username = @username AND TargetId = @targetid  AND (Status = 'P' OR Status = 'T')  
  
--delete from mobblockstores where targetid = @targetid AND username = @username and entrydate =  @entrydate   
if not exists(select * from mobblockstores where targetid = @targetid AND username = @username and entrydate =  @entrydate)  
Begin  
INSERT INTO [dbo].[mobblockstores]      
           ([targetid]      
           ,[entrydate]      
           ,[roleid]      
           ,[stockentryid]      
                
           ,[username])      
     VALUES      
           (@targetid,      
           @entrydate,      
           @roleid,      
           @stockentryid,      
               
           @username)      
End  
COMMIT       
   select '200'           
 END TRY      
 BEGIN CATCH      
 ROLLBACK      
 select '500'       
       
 END CATCH      
                 
end
go

