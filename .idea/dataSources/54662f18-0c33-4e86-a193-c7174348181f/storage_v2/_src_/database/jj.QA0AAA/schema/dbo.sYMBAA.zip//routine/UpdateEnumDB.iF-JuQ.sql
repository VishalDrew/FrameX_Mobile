CREATE Proc [dbo].[UpdateEnumDB] --'UserMaster','Role_Id','RoleID','500','validate[required,custom[alphanumeric] text-input'    ,10
@enumtype varchar(200),    
@FieldName varchar(100),    
@NewFieldName varchar(100),    
@MaxLength int,    
@validation nvarchar(200),        
@Sequence int = 0         
AS
Begin
IF EXISTs(Select FieldName From EnumFieldControlInfo Where FormName = @enumtype 
AND FieldName = @newfieldname and FieldName <> @Fieldname)
SELECT -1
else    
begin try  
  
begin tran   


update EnumFieldControlInfo Set Fieldvalidation=@validation, FieldName=@NewFieldName,Sequence=@Sequence  
 Where FieldName=@FieldName    
and FormName=@enumtype    
declare @Query nvarchar(MAX)    
set @Query = 'sp_RENAME '''+@enumtype+'.['+@FieldName+']'' , '''+@NewFieldName+''', ''COLUMN'''    
--set @Query = 'Alter table Employeemaster Alter Column  '+@FieldName+' varchar('+convert(varchar,@maxLength)+')'    
print @Query    
exec (@Query)    
if(@MaxLength <> '0')    
begin    
 set @Query = 'Alter table ' + @enumtype + ' Alter Column  '+@NewFieldName+' varchar('+convert(varchar,@maxLength)+')'    
 print @Query    
 exec (@Query)    
End    
Select '1'    
commit tran    
end try    
begin catch    
rollback tran    
Select '0'    
end catch    
End
go

