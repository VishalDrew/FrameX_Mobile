
CREATE procedure usp_getauditquestionforDataentry --'4'             
@QuestionID int,        
@TargetID varchar(200)           
as            
begin            
select AM.AuditId,AM.AuditQuestion,AM.QuestionMode,AM.FieldOption,AM.validation from TargetAuditQuestionRelation TA            
inner join Auditmaster AM            
on TA.QuestionID = AM.AuditId where TA.PictureID=@QuestionID and TA.TargetID=@TargetID 
order by QuestionSequence          
end
go

