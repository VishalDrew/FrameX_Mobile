CREATE proc mobchecklatlong    
@targetid int    
as begin    
    
  SELECT TargetID,Latitude,Longitude FROM TargetMaster where (targetid = @targetid AND isnull(Latitude,0) = 0)    
end
go

