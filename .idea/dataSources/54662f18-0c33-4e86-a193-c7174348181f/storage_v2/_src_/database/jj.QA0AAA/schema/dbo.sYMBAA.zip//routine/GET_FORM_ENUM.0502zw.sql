CREATE PROCEDURE GET_FORM_ENUM    
	(    
	 @FORMID VARCHAR(10)    
	)    
	AS    
	BEGIN    
	 --DECLARE @FORMID VARCHAR(10)='73'    
	 SELECT * FROM dbo.FormFieldOption    
	  WHERE FormID=@FORMID    
	END
go

