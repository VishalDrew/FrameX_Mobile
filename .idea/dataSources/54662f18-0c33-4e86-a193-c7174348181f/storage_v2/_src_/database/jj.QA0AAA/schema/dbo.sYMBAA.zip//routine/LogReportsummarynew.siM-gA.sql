CREATE PRoc LogReportsummarynew  
As  begin  
select COUNT(*) as 'T' from PjpPlanMaster         
where CONVERT (varchar,Pjpdate,102) = CONVERT(varchar,getdate()-1,102)  
SELECT SUM(ctr) as 'TAU' From(  
Select (  
select COUNT(*)  from StockEntryMain Where TargetID = otr.PjpTargetId   
and CONVERT (varchar,EntryDate,102) = CONVERT(varchar,otr.Pjpdate,102) and Username = otr.PjpUserName)Ctr   
From PjpPlanMaster otr  
where CONVERT (varchar,Pjpdate,102) = CONVERT(varchar,getdate()-1,102)  
) dd  
  
Select Count(ctr) 'PAU' from  
(select   
(Select COUNT(*) From PjpPlanMaster   
Where PjpTargetID = otr.TargetId And CONVERT (varchar,PjpDate,102) = CONVERT (varchar,EntryDate,102)   
and PjpUserName = Username)ctr  
   from StockEntryMain otr  
Where CONVERT (varchar,EntryDate,102) = CONVERT(varchar,getdate()-1,102)  
and cMobileNo<>'Web'   
) as dd  
where ctr = 0  
select  COUNT(*) 'ANU' From PjpPlan Where Status = 'A' and CONVERT(varchar,Pjpdate,102) = CONVERT(varchar,getdate()-1,102)  
AND TargetId NOT IN(select SEM.TargetID  from StockEntryMain SEM Where   
 CONVERT (varchar,EntryDate,102) = CONVERT(varchar,GETDATE()-1,102) and SEM.username = Pjpplan.username)  
   
  Select COUNT(*) 'TNA' From PjpPlan where Status = 'T' AND CONVERT(varchar,Pjpdate,102) = CONVERT(varchar,getdate()-1,102)  
  Select COUNT(*) 'PNA' From PjpPlan where Status = 'P'   
  Select COUNT(*) 'Expired' From Pjpplan where Status = 'E'    
end
go

