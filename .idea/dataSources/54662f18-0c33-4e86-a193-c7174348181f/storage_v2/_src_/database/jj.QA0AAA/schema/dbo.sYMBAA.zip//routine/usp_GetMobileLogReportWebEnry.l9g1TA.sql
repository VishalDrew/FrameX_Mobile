CREATE procedure usp_GetMobileLogReportWebEnry --'2015.09.05'        
@EntryDate varchar(200)        
as        
begin        
select TargetID,CONVERT(varchar,EntryDate,102)as EntryDate  from StockEntryMain where cMobileNo='Web' AND CONVERT(varchar,EntryDate,102)=@EntryDate        
Select  COUNT(*) as Total FROM StockEntryMain Where cMobileNo = 'web' AND  CONVERT(varchar,EntryDate,102)=@EntryDate        
end
go

