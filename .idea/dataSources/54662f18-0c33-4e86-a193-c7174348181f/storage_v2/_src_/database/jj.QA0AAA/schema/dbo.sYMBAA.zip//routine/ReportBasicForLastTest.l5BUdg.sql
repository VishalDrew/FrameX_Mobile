CREATE Procedure [dbo].[ReportBasicForLastTest] -- '9','2015-03-01','2015-03-27'  ,' ' and RoleId = 4 and a.CityID in ( ''24'' )'                      
@ReportID int,                      
@FromDate datetime,                      
@ToDate datetime,                      
@filterQuery varchar(MAX)=' and 1 = 1 '                      
as                      
begin                      
  SET nocount  ON                      
    DECLARE  @imax INT,                      
             @i    INT                      
    DECLARE  @Contact VARCHAR(100),                      
             @Company VARCHAR(50)                      
   DECLARE @MainTable nvarchar(60)                      
   DECLARE @Full_String nvarchar(4000)                      
   DECLARE @ColumName nvarchar(4000)                      
   DECLARE @RowLabel nvarchar(4000),@ColumnLabel nvarchar(4000),@FormNamne varchar(200),@ValueLabel varchar(200)                      
   DECLARE @Query nvarchar(MAX)                      
                         
   set @MainTable='a';                      
 select @RowLabel=RowLabel,@ColumnLabel=ColumnLabel,@ValueLabel=ValueLabel,    
 @FormNamne=FormMaster.Name from ReportBasicMaster                      
 inner join FormMaster on ReportBasicMaster.FormID=FormMaster.FormID                      
 where ReportID=@ReportID                      
                      
 DECLARE  @CompanyInfo  TABLE(                      
     RowID       INT    IDENTITY ( 1 , 1 ),                      
     CompanyName VARCHAR(100),                      
     ContactName VARCHAR(50)                      
     )                      
 INSERT @CompanyInfo                      
  SELECT                                
   COLUMN_NAME,COLUMN_NAME                      
  FROM                      
   INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc                      
   INNER JOIN                      
   INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE ccu ON tc.CONSTRAINT_NAME = ccu.Constraint_name                                
  WHERE                                
   (                                
    tc.CONSTRAINT_TYPE = 'Foreign Key'                                
   )                                
   AND                                
   tc.TABLE_NAME ='TargetMaster' and COLUMN_NAME in (select * from dbo.CommaToXML (@RowLabel))                      
    SET @imax = @@ROWCOUNT                                 
    SET @i = 1                                 
    WHILE (@i <= @imax)                                 
      BEGIN                                 
        SELECT @Contact = ContactName,                                 
               @Company = CompanyName                                 
        FROM   @CompanyInfo                                 
        WHERE  RowID = @i                                        
   set @ColumName=ISNULL(@ColumName,'') +',' +@Contact+'.Name as '''+REPLACE(@Contact,'ID',' Name') +'''';                                
   set @Full_String=ISNULL(@Full_String,'') +  ' left join ' +  REPLACE(@Contact,'ID','Master') + ' ' +  @Contact +' on '+ @MainTable +'.'+ @Contact + ' = ' + @Contact +'.'+@Contact                                  
                                                  
         SET @i = @i + 1                                 
      END -- WHILE                         
DECLARE @List VARCHAR(1000)                      
 select @List = COALESCE(@List + ', ', ',') + 'a.' + value from dbo.CommaToXML (@RowLabel) where                       
     value not in (select CompanyName from @CompanyInfo) and value<>''                      
    --set @ColumName=  SUBSTRING(@ColumName,2,(LEN(@ColumName)))                                
    set @ColumName=  REPLACE(@ColumName,'.*.*','')                                
           Print @ColumName                      
           Print @List                      
   if(@List is not null)                    
   set @ColumName = ISNULL(@ColumName,'') + @List                 
   if(@ColumName is not null)                    
   Begin              
  set @ColumName=  SUBSTRING(@ColumName,2,(LEN(@ColumName)))                
  set @ColumName = ',' + @ColumName + ','        
       
  --select @ColumName       
  --select @Full_String             
 End                
                       
   --set @Query = 'Select a.TargetID'+ISNULL(@ColumName,',')+'m.StockEntryID,Convert(varchar,m.EntryDate,103) as EntryDate,cMobileNo as Mobileno, m.Username From                       
   --StockEntryMain m left join TargetMaster a on a.TargetID=m.TargetID ' + ISNULL(@Full_String,'') +'                       
   --where m.EntryDate between '''+ convert(varchar(20),@FromDate,120)+''' and '''+ convert(varchar(20),@ToDate,120) +''''+ @filterQuery +' Order By a.TargetName'       
         
--   set @Query = 'Select a.TargetID'+ISNULL(@ColumName,',')+'m.StockEntryID,Convert(varchar,m.EntryDate,103) as EntryDate,cMobileNo as Mobileno, m.Username From                       
--   StockEntryMain m left join TargetMaster a on a.TargetID=m.TargetID ' + ISNULL(@Full_String,'') +'        
                        
--   where      
--    m.StockEntryID = (Select Top 1 StockEntryID From StockEntryMain sinn      
--    inner join TargetMaster a      
--    on a.TargetID= sinn.TargetID      
-- Where CONVERT(varchar,sinn.EntryDate,102) between '''+ convert(varchar(20),@FromDate,102)+''' and '''+ convert(varchar(20),@ToDate,102) +''''+ @filterQuery +'  AND sinn.TargetID = m.TargetID ORDER BY EntryDate DESC)'      
                     
----print(@Query)      
--exec(@Query)        
                   
--exec('select '+@ColumnLabel+','+@FormNamne+'ID from '+@FormNamne+'Master')                      
 set @Query = ''                      
 --set @Query = 'select b.'+@ColumnLabel+',a.StockEntryID,a.'+@ValueLabel+',a.'+@FormNamne+'ID from '+@FormNamne+'StockEntry a                   
 --  inner join '+@FormNamne+'Master b on a.'+@FormNamne+'ID = b.'+@FormNamne+'ID                       
 --  inner join StockEntryMain s on a.StockEntryID=s.StockEntryID                      
 --  where CONVERT(varchar,S.EntryDate,102) between '''+ convert(varchar(20),@FromDate,102)+''' and '''+ convert(varchar(20),@ToDate,102) +''''                      
      
--print(@Query)      
      
      
set @Query = 'select a.TargetID'+ISNULL(@ColumName,',')+'s.StockEntryID,  
Convert(varchar,s.EntryDate,103) as EntryDate,cMobileNo as Mobileno, s.Username,  
 b.'+@ColumnLabel+',SE.StockEntryID,SE.'+@ValueLabel+',  
 SE.'+@FormNamne+'ID from '+@FormNamne+'StockEntry SE  
                   
   inner join '+@FormNamne+'Master b on SE.'+@FormNamne+'ID = b.'+@FormNamne+'ID                       
   inner join StockEntryMain s on SE.StockEntryID=s.StockEntryID     
   left join TargetMaster a on a.TargetID=s.TargetID ' + ISNULL(@Full_String,'') +'                       
   where      
    s.StockEntryID = (Select Top 1 StockEntryID From StockEntryMain sinn      
    inner join TargetMaster a      
    on a.TargetID= sinn.TargetID      
Where CONVERT(varchar,sinn.EntryDate,102) between '''+ convert(varchar(20),@FromDate,102)+''' and '''+ convert(varchar(20),@ToDate,102) +''''+ @filterQuery +'  AND sinn.TargetID = s.TargetID ORDER BY EntryDate DESC )'        
      
print(@Query)      
                   
      
exec(@Query)      
                      
End           
      
      
--select * from StockEntryMain   left join CityMaster CityID on a.CityID = CityID.CityID
go

