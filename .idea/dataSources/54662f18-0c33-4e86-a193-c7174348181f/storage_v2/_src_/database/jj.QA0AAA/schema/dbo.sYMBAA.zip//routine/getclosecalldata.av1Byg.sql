CREATE PROC [dbo].[getclosecalldata]        
AS      
BEGIN         
Select CloseCallReasonId,Name,isnull(imagerequired,0) imagerequired from Closecallreasonmaster  where Status=1 
END

go

