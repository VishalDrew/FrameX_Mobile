CREATE  TRIGGER [dbo].[ReportCalculateDeleteLink]  
ON [dbo].[ReportCalculate]  
AFTER Delete
AS
BEGIN
	declare @Name varchar(500),@ReportID int
	select @ReportID = CalculateReportID from deleted
	select @Name = 'ReportCalculated.aspx?ID='+Convert(varchar,@ReportID)
	declare @subsecID int
	select @subsecID= subsectionid from SubSectionMaster where FormPathName = @Name
	Delete from RoleAccessManagement where SubsectionID=@subsecID
	Delete From SubSectionMaster Where FormPathName = @Name
	
END
go

