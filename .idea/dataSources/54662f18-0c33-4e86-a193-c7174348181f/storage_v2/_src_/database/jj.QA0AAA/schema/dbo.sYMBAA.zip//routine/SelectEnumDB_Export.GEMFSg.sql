CREATE Proc [dbo].[SelectEnumDB_Export] --'Usermaster'    
@enumtype varchar(500)    
as    
    
Begin    
  select   
  REPLACE(enum.FieldName,'_',' ') AS Field,    
   [validation] =     
       case     
        when enum.Fieldvalidation='validate[required]'     
         then 'required'     
        when enum.Fieldvalidation='validate[required,custom[integer]]'  
         then 'numeric'    
           when enum.Fieldvalidation='validate[required,custom[email]'     
         then 'email'     
        when enum.Fieldvalidation='validate[required] text-input datepicker'    
         then 'date'    
       else 'none'  
       end    
   ,character_maximum_length AS Length  
    ,[Data Type] =     
       case     
        when [Data_Type]='varchar'     
         then 'string'     
        when [Data_Type]='int' or [Data_Type]='bigint'    
         then 'numeric'     
       else [Data_Type]     
       end       
 ,enum.Sequence   
       
   from EnumFieldControlInfo enum     
  inner join information_schema.columns on COLUMN_NAME = enum.FieldName     
    
  where table_name = @enumtype and enum.FormName=@enumtype    
    
End
go

