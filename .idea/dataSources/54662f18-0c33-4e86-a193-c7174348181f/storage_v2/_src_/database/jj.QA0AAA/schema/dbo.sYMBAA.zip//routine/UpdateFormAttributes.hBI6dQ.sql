
CREATE Procedure [dbo].[UpdateFormAttributes]
@FormID int
,@FieldName varchar(100)
,@DataType varchar(200)
,@ControlType varchar(200)
,@Required bit
,@ForPM bit
,@ForDEO bit
,@FormFieldID int


As
Begin
  UPDATE [FormFieldDetail]
   SET
       [FieldName] = @FieldName      
      ,[ForPM] = @ForPM
      ,[ForDEO] =@ForDEO
      ,ControlType=@ControlType
      ,DataType=@DataType
      ,[Required]=@Required     
 WHERE FormFieldID=@FormFieldID

 Select @FormFieldID


END
go

