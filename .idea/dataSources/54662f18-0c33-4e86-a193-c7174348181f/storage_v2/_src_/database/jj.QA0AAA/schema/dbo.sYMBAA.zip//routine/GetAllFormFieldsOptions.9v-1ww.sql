CREATE  procedure [dbo].[GetAllFormFieldsOptions] --'CityMaster'  
(  
@TableName nvarchar(50)  
)  
  
As  
Begin  

EXEC('Select * From '+ @TableName +' Where Status= ''true'' ')  
  
  
  
END
go

