  
CREATE PROC [dbo].[RemoveFormMaster]   --'FormMaster',4,false        
@enumtype varchar(100),      
@enumid int      
,@status bit        
As       
      
BEGIN TRANSACTION      
 begin try      
  if(@enumid <> '')       
  begin        
   Update FormMaster       
   set FormStatus=@status      
   WHere FormID=@enumid      
   declare @SectionID int    
   if(@status = 'false')    
   begin    
     
       
 select @SectionID = SectionID from SectionMaster     
 where SectionName = (select Name from FormMaster where FormID=@enumid) + ' Master'    
 delete from RoleAccessManagement where SectionID=@SectionID    
 delete from SubSectionMaster where SectionID=@SectionID    
 delete  from HelpMaster Where SectionID = @SectionID  
 delete from SectionMaster where SectionID=@SectionID    
   
   End    
   else     
    if(@status = 'true')    
    begin    
        
   declare @FormName varchar(500),@CreatedBy varchar(50)    
   select @FormName = Name from FormMaster where FormID=@enumid    
   select @CreatedBy = CreatedBy from FormMaster where FormID=@enumid    
   insert into SectionMaster values (@FormName + ' Master','10','True',@CreatedBy,@CreatedBy,getdate(),getdate())    
   set @SectionID = SCOPE_IDENTITY()    
   insert into SubSectionMaster values (@SectionID,'Add/Edit ' + @FormName,'formdisplay.aspx?form=' + @FormName,'True',@CreatedBy,@CreatedBy,getdate(),getdate())    
   insert into SubSectionMaster values (@SectionID,'Upload ' + @FormName,'UploadMaster.aspx?form=' + @FormName,'True',@CreatedBy,@CreatedBy,getdate(),getdate())    
   insert into SubSectionMaster values (@SectionID,'Manage ' + @FormName +' Relation','ManageFormRelation.aspx?form=' + @FormName,'True',@CreatedBy,@CreatedBy,getdate(),getdate())
   insert into SubSectionMaster values (@SectionID,'Upload ' + @FormName +' Relation','UploadRelation.aspx?form=' + @FormName,'True',@CreatedBy,@CreatedBy,getdate(),getdate())    
    
    End       
   select '1'      
  end      
 COMMIT TRAN      
    end try      
    begin catch      
  select '0'      
  ROLLBACK TRAN      
    end catch
go

