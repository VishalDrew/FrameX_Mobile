CREATE Procedure TargetExists        
       
@TargetID int     
As        
Begin        
if  exists(select * from TargetMaster where TargetID=@TargetID)        
 begin        
  select 'True'        
 END        
ELSE        
 Begin        
  select 'False'        
 END        
END
go

