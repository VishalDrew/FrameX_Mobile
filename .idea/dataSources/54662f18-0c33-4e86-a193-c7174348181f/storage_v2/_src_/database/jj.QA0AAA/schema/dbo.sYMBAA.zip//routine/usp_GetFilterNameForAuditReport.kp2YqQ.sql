CREATE procedure usp_GetFilterNameForAuditReport    
as    
begin    
select ReportFilter from AuditPictureReport    
end
go

