CREATE Proc  GetDateForFormExport --'asset'
@Table nvarchar(50)
As
Begin

Declare @Name nvarchar(50),
        @TableName nvarchar(100),
        @ColumName nvarchar(100),
        @ColumID nvarchar(100),
        @TableRelation nvarchar(100)
        
        
  set @Name =@Table    
  Set @TableName=@Name+'Master' 
  Set @ColumName=@Name+'Name'    
  Set @ColumID=@Name +'ID'
  set @TableRelation=@Name+'Relation'

EXEC('Select '+@ColumName+','+@ColumID+' From '+@TableName)



 DECLARE  @imax INT,   
             @i    INT   
    DECLARE  @Contact VARCHAR(100),   
             @Company VARCHAR(50)   
             
             DECLARE  @CompanyInfo  TABLE(   
                                 RowID       INT    IDENTITY ( 1 , 1 ),   
                                 CompanyName VARCHAR(100),   
                                 ContactName VARCHAR(50)   
                                 )   
INSERT @CompanyInfo   
Select COLUMN_NAME,tc.TABLE_NAME From INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc INNER JOIN  
INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE ccu ON tc.CONSTRAINT_NAME = ccu.Constraint_name wHEre  
CONSTRAINT_TYPE='PRIMARY KEY' and COLUMN_NAME in (Select COLUMN_NAME From INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc INNER JOIN  
INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE ccu ON tc.CONSTRAINT_NAME = ccu.Constraint_name wHEre  
CONSTRAINT_TYPE='FOREIGN KEY' and tc.TABLE_NAME=@TableRelation)
     
       
    SET @imax = @@ROWCOUNT   
    SET @i = 1   
       
    WHILE (@i <= @imax)   
      BEGIN   
        SELECT @Contact = ContactName,   
               @Company = CompanyName   
        FROM   @CompanyInfo   
        WHERE  RowID = @i          
         
         Declare @FColumname nvarchar(100),@FColumnID nvarchar(100)
         
         set @FColumname=REPLACE (@Contact,'Master','Name')
         set @FColumnID=REPLACE (@Contact,'Master','ID')
         
      --  exec('select * From '+@Contact +' Where Status=''True''')
       
                    
        SET @i = @i + 1   
      END   
      
   END
go

