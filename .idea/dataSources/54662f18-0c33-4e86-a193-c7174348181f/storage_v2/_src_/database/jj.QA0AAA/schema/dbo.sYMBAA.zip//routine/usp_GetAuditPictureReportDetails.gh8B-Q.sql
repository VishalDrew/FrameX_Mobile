CREATE procedure usp_GetAuditPictureReportDetails --'2015.11.25','2015.11.27',''          
                 
@FromDate datetime,                                
@ToDate datetime,                                
@filterQuery varchar(MAX)=' and 1 = 1 '           
as              
begin              
              
--select RowLebel from AuditPictureReport              
              
              
              
              
--select SM.TargetID,SM.StockEntryID,AEM.AuditEntryId,              
--CM.Name as 'City',CLM.Name as 'Classification',              
-- AED.PicId,PM.Activity, AED.AuditQuestionId,AM.AuditQuestion,PM.Activity+'('+AM.AuditQuestion+')' as 'Quesions', AED.AuditAnswer from StockEntryMain SM          
         
--inner join AuditEntryMain AEM              
--on SM.StockEntryID = AEM.StockEntryId              
--inner join AuditEntryDetail AED on AED.AuditEntryId=AEM.AuditEntryId              
--inner join PictureMaster PM              
--on pm.PictureID=AED.PicId              
--inner join Auditmaster AM              
--on AM.AuditId=AED.AuditQuestionId              
--Inner join TargetMaster TM              
--on TM.TargetID=SM.TargetID              
--inner join CityMaster CM              
--on CM.CityID=TM.CityID              
--inner join ClassificationMaster CLM              
--on CLM.ClassificationID= TM.ClassificationID              
              
              
              
SET nocount  ON                                    
    DECLARE  @imax INT,                                    
             @i    INT                                    
    DECLARE  @Contact VARCHAR(100),                                    
             @Company VARCHAR(50)                                    
   DECLARE @MainTable nvarchar(60)                                    
   DECLARE @Full_String nvarchar(4000)                                    
   DECLARE @ColumName nvarchar(4000)                                    
   DECLARE @RowLabel nvarchar(4000),@ColumnLabel nvarchar(4000),@FormNamne varchar(200),@ValueLabel varchar(200)                                    
   DECLARE @Query nvarchar(MAX)                                    
                                       
   set @MainTable='a';                                    
              
               
 select  @RowLabel= RowLebel from AuditPictureReport                                 
                                    
 DECLARE  @CompanyInfo  TABLE(                                    
     RowID       INT    IDENTITY ( 1 , 1 ),                                    
     CompanyName VARCHAR(100),                                    
     ContactName VARCHAR(50)                                    
     )                                    
 INSERT @CompanyInfo                                    
  SELECT                                              
   COLUMN_NAME,COLUMN_NAME                                    
  FROM                                    
   INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc                                    
   INNER JOIN                                    
   INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE ccu ON tc.CONSTRAINT_NAME = ccu.Constraint_name                                              
  WHERE                                              
   (                                              
    tc.CONSTRAINT_TYPE = 'Foreign Key'                                              
   )                                              
   AND                                              
   tc.TABLE_NAME ='TargetMaster' and COLUMN_NAME in (select * from dbo.CommaToXML (@RowLabel))                                    
    SET @imax = @@ROWCOUNT                                               
    SET @i = 1                                               
    WHILE (@i <= @imax)                                               
      BEGIN                                               
        SELECT @Contact = ContactName,                                               
               @Company = CompanyName                           
        FROM   @CompanyInfo                                               
        WHERE  RowID = @i                              
   set @ColumName=ISNULL(@ColumName,'') +',' +@Contact+'.Name as '''+REPLACE(@Contact,'ID','Name') +'''';                            
   set @Full_String=ISNULL(@Full_String,'') +  ' left join ' +  REPLACE(@Contact,'ID','Master') + ' ' +  @Contact +' on '+ @MainTable +'.'+ @Contact + ' = '      
+ @Contact +'.'+@Contact                                                
                                                                
         SET @i = @i + 1                                               
      END -- WHILE                                       
DECLARE @List VARCHAR(1000)                                    
 select @List = COALESCE(@List + ', ', ',') + 'a.' + value from dbo.CommaToXML (@RowLabel) where                                     
     value not in (select CompanyName from @CompanyInfo) and value<>''                                    
    --set @ColumName=  SUBSTRING(@ColumName,2,(LEN(@ColumName)))                           
    set @ColumName=  REPLACE(@ColumName,'.*.*','')                                              
           Print @ColumName                                    
           Print @List                                    
   if(@List is not null)                                  
   set @ColumName = ISNULL(@ColumName,'') + @List                               
   if(@ColumName is not null)                                  
   Begin                               
  set @ColumName=  SUBSTRING(@ColumName,2,(LEN(@ColumName)))                              
  set @ColumName = ',' + @ColumName + ','                                
 End              
               
                      
   set @Query = 'Select a.TargetID'+ISNULL(@ColumName,',')+'m.StockEntryID,Convert(varchar(11),m.EntryDate,113) as EntryDate,cMobileNo as Mobileno,      
m.Username,convert(varchar,AEM.Auditdate,103) as CreatedDate,AEM.createdby as ''AuditUser'' From                  
                       
   StockEntryMain m left join TargetMaster a on a.TargetID=m.TargetID inner join AuditEntryMain AEM              
   on m.StockEntryID = AEM.StockEntryId ' + ISNULL(@Full_String,'') +'          
   where convert(varchar,AEM.Auditdate,102) between '''+ convert(varchar(20),@FromDate,102)+''' and '''+ convert(varchar(20),@ToDate,102) +''''+ @filterQuery      
+' Order By a.TargetName'                                
            
                                       
   --where convert(varchar,m.EntryDate,102) between '''+ convert(varchar(20),@FromDate,102)+''' and '''+ convert(varchar(20),@ToDate,102) +''''+ @filterQuery      
--+' Order By a.TargetName'                                    
             
             
            
  print(@Query)                 
  exec(@Query)                
    set @Query = ''                
  set @Query = 'Select PM.Activity+''(''+AM.AuditQuestion+'')'' as ''Quesions'',m.StockEntryID, AED.AuditAnswer From                                     
   StockEntryMain m left join TargetMaster a on a.TargetID=m.TargetID inner join AuditEntryMain AEM              
on m.StockEntryID = AEM.StockEntryId              
inner join AuditEntryDetail AED on AED.AuditEntryId=AEM.AuditEntryId              
inner join PictureMaster PM              
on pm.PictureID=AED.PicId              
inner join Auditmaster AM              
on AM.AuditId=AED.AuditQuestionId ' + ISNULL(@Full_String,'') +'          
 where convert(varchar,AEM.Auditdate,102) between '''+ convert(varchar(20),@FromDate,102)+''' and '''+ convert(varchar(20),@ToDate,102) +''''+ @filterQuery      
+''                                
                                    
   --where convert(varchar,m.EntryDate,102) between '''+ convert(varchar(20),@FromDate,102)+''' and '''+ convert(varchar(20),@ToDate,102) +''''+ @filterQuery      
+' Order By a.TargetName'                                    
  print(@Query)                 
  exec(@Query)   
                                
                                     
--exec('select '+@ColumnLabel+','+@FormNamne+'ID from '+@FormNamne+'Master')                                    
              
                 
              
              
    
end
go

