CREATE Procedure GetColumnName --'TargetMaster'      
@TableName nvarchar(50)      
      
As      
BEGIN      
--DECLARE @TableName nvarchar(50) ='TargetMaster'    
Declare @Columname nvarchar(100)      
      
set @Columname =REPLACE(@TableName,'Master','ID')      
      
EXEC('Select COLUMN_NAME FRom INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME='''+@TableName+'''      
and COLUMN_NAME <> ''CreatedDate''      
and COLUMN_NAME <> ''ModifiedDate''      
and COLUMN_NAME <> ''CreatedBy''      
and COLUMN_NAME <> '''+@Columname+'''      
and COLUMN_NAME <> ''ModifiedBy''    
and COLUMN_NAME <> ''Latitude''    
and COLUMN_NAME <> ''Longitude''    
')      
      
Select COLUMN_NAME,tc.TABLE_NAME From INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc INNER JOIN        
INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE ccu ON tc.CONSTRAINT_NAME = ccu.Constraint_name wHEre        
CONSTRAINT_TYPE='PRIMARY KEY' and COLUMN_NAME in (Select COLUMN_NAME From INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc INNER JOIN        
INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE ccu ON tc.CONSTRAINT_NAME = ccu.Constraint_name wHEre        
CONSTRAINT_TYPE='FOREIGN KEY' and tc.TABLE_NAME=@TableName)        
      
END 
go

