CREATE PROC [dbo].[GetAllFormMaster]

As 
 begin  
  Select *
      From FormMaster order by Name 
 END
go

