create procedure usp_getSequnceForUpdate
@FormID int,
@FormFieldName varchar(300),
@Sequence int

as
begin

select FieldName,Sequence from FormFieldDetail where Sequence=@Sequence and FormFieldID<>@FormFieldName and FormID=@FormID
end
go

