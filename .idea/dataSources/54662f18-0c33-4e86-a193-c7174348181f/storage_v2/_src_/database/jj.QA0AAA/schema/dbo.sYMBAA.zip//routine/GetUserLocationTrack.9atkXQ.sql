CREATE PROCEDURE [dbo].[GetUserLocationTrack]                                    
 @UserName nvarchar(200)                                    
AS                                    
BEGIN      
select Targetid,TargetName,EntryDate,visitedDate,Intime,Outtime,Latitude,Longitude,Username,Distance,TravelHours,SpentHours from (    
 --select top 5 convert(date,EntryDate) from StockEntryMain where Username = @UserName group by convert(date,EntryDate) order by convert(date,EntryDate) desc      
 select distinct 'Attedance' as Targetid,'Attedance' as TargetName,Left(convert(varchar,ad.date,100),11) as EntryDate,ad.date as visitedDate,    
 Rtrim(Ltrim(RIGHT(CONVERT(VARCHAR, ad.createddate, 100), 7))) Intime,RIGHT(CONVERT(VARCHAR, ad.createddate, 100), 7) Outtime,ad.lat as Latitude,      
 ad.long as Longitude,ad.Username,0  as Distance,'' as TravelHours,'' as SpentHours from Attendancedetail ad     
 --left Join UserDailyLocationTracker udl  on ad.username = udl.Username and ad.status = 'P'    
-- Join StockEntryMain sem on sem.Username = ad.username    
 where ad.Username = @UserName and convert(date,ad.date) in       
 (select top 5 convert(date,EntryDate) from StockEntryMain where Username = @UserName group by convert(date,EntryDate) order by convert(date,EntryDate) desc)       
 --order by sem.EntryDate     
 Union All    
 Select sem.TargetID,Tm.TargetName,Left(convert(varchar,sem.EntryDate,100),11) as EntryDate,sem.EntryDate as visitedDate,    
 Rtrim(Ltrim(RIGHT(CONVERT(VARCHAR, sem.Intime, 100), 7))) Intime,RIGHT(CONVERT(VARCHAR, sem.Outtime, 100), 7) Outtime,sem.Latitude,      
 sem.Longitude,sem.Username,isnull(Distance,0) as Distance,isnull(TravelHours,'') as TravelHours,isnull(SpentHours,'') as SpentHours from StockEntryMain sem      
 left join UserDailyLocationTracker udl on udl.TravelName = sem.TargetID and visitedDate = convert(date,EntryDate) and udl.TravelName != 'Attendance'    
 Join TargetMaster tm on tm.TargetID = sem.TargetID      
 --Join UserMaster um on um.username = sem.Username      
 where sem.Username = @UserName and convert(date,sem.EntryDate) in       
 (select top 5 convert(date,EntryDate) from StockEntryMain where Username = @UserName group by convert(date,EntryDate) order by convert(date,EntryDate) desc) ) #A      
 order by visitedDate,Intime      
      
End      
go

