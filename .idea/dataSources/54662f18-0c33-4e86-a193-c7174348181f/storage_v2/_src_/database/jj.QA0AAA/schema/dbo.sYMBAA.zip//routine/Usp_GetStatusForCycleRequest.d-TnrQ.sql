                  
CREATE Procedure [dbo].[Usp_GetStatusForCycleRequest] --'p', '2014-11-01','2014-11-30'                         
  @status nvarchar(300),    
  @CycleStartDate varchar(200),    
  @CycleEndDate varchar(200)    
      
                    
As                          
Begin                          
--Select * FROM CycleCloseMaster WHERE Status!=@status     
    
select CycleStartDate,CycleEndDate from   CycleCloseMaster WHERE CycleStartDate=@CycleStartDate and CycleEndDate=@CycleEndDate    
                    
END                 
                
                
--select * from CycleCloseMaster            
--Select * FROM CycleCloseMaster WHERE Status!='Approved'    
    
--select CycleStartDate,CycleEndDate from   CycleCloseMaster WHERE CycleStartDate='2014-11-01' and CycleEndDate='2014-11-30'
go

