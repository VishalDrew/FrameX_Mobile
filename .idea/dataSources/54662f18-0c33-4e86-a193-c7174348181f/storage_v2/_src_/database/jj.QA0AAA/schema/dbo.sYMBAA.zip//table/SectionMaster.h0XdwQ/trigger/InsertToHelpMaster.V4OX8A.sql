
CREATE TRIGGER [dbo].[InsertToHelpMaster]  
ON [dbo].[SectionMaster]  
AFTER INSERT
AS
BEGIN
	declare @CreatedBy varchar(50),@SectionID int
	select @SectionID = SectionID from inserted
	select @CreatedBy = CreatedBy from inserted
	insert into HelpMaster values (@SectionID,'','','True',@CreatedBy,@CreatedBy,getdate(),getdate())
END
go

