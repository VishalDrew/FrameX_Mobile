 -- [ReportCalculationTestLastCallTest] '5','2023.07.12','2023.07.12'  ,' and RoleId = 4'       
CREATE Procedure [dbo].[ReportCalculationTestLastCallTest] --'4','2016.12.10','2016.12.31'  ,' and RoleId = 4 '                             
@ReportID int,                                      
@FromDate datetime,                                      
@ToDate datetime,                                      
@filterQuery varchar(MAX)=' and 1 = 1 '                                      
as              
begin                                      
  SET nocount  ON                                      
    DECLARE  @imax INT,                                      
             @i    INT                                      
    DECLARE  @Contact VARCHAR(100),                                      
             @Company VARCHAR(50)                                      
   DECLARE @MainTable nvarchar(60)                                      
   DECLARE @Full_String nvarchar(4000)                                      
   DECLARE @ColumName nvarchar(4000)                                      
   DECLARE @RowLabel nvarchar(4000),@ColumnLabel nvarchar(4000),@FormNamne varchar(200),@ValueLabel varchar(200)                                      
   DECLARE @Query nvarchar(MAX)                                      
                                         
   set @MainTable='a';                                      
 select @RowLabel=RowLabel,@ColumnLabel=ColumnLabel,@ValueLabel=ValueLabel,@FormNamne=FormMaster.Name from ReportBasicMaster                                      
 inner join FormMaster on ReportBasicMaster.FormID=FormMaster.FormID                                      
 where ReportID=@ReportID                                      
                                      
 DECLARE  @CompanyInfo  TABLE(                                      
     RowID       INT    IDENTITY ( 1 , 1 ),                                      
     CompanyName VARCHAR(100),                                      
     ContactName VARCHAR(50)                                      
     )                                      
 INSERT @CompanyInfo                                      
  SELECT                                                
   COLUMN_NAME,COLUMN_NAME                                      
  FROM                                      
   INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc                                      
   INNER JOIN                                      
   INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE ccu ON tc.CONSTRAINT_NAME = ccu.Constraint_name                                                
  WHERE                                                
   (                                                
    tc.CONSTRAINT_TYPE = 'Foreign Key'                                                
   )                                                
   AND                                                
   tc.TABLE_NAME ='TargetMaster' and COLUMN_NAME in (select * from dbo.CommaToXML (@RowLabel))                                      
    SET @imax = @@ROWCOUNT                                                 
    SET @i = 1                                                 
    WHILE (@i <= @imax)                                                 
      BEGIN                                                 
        SELECT @Contact = ContactName,                                                 
               @Company = CompanyName                                                 
        FROM   @CompanyInfo                                                 
        WHERE  RowID = @i                                                        
   set @ColumName=ISNULL(@ColumName,'') +',' +@Contact+'.Name as '''+REPLACE(@Contact,'ID',' Name') +'''';                                                
   set @Full_String=ISNULL(@Full_String,'') +  ' left join ' +  REPLACE(@Contact,'ID','Master') + ' ' +  @Contact +' on '+ @MainTable +'.'+ @Contact + ' = ' + @Contact +'.'+@Contact   
                                                                  
         SET @i = @i + 1                                                 
      END -- WHILE     
DECLARE @List VARCHAR(1000)                                      
 select @List = COALESCE(@List + ', ', ',') + 'a.' + value from dbo.CommaToXML (@RowLabel) where                                       
     value not in (select CompanyName from @CompanyInfo) and value<>''                                      
    --set @ColumName=  SUBSTRING(@ColumName,2,(LEN(@ColumName)))                                                
    set @ColumName=  REPLACE(@ColumName,'.*.*','')                                    
           Print @ColumName                                      
           Print @List                   
   if(@List is not null)                                    
   set @ColumName = ISNULL(@ColumName,'') + @List                                 
   if(@ColumName is not null)                                    
   Begin                                 
  set @ColumName=  SUBSTRING(@ColumName,2,(LEN(@ColumName)))                                
  set @ColumName = ',' + @ColumName + ','                                  
 End                                
                            
   set @Query = 'Select distinct a.TargetID'+ISNULL(@ColumName,',')+'m.StockEntryID,Convert(varchar(11),m.EntryDate,113) as EntryDate, m.dActaulEntryDate AS EntryDateWithTime,cMobileNo as Mobileno, m.Username From                                       
   StockEntryMain m left join TargetMaster a on a.TargetID=m.TargetID ' + ISNULL(@Full_String,'') +'     
   inner join '+@FormNamne+'StockEntry p on p.StockEntryID=m.StockEntryID                      
   inner join '+@FormNamne+'Master b on p.'+@FormNamne+'ID = b.'+@FormNamne+'ID     
   where m.StockEntryID = (Select Top 1 StockEntryID From StockEntryMain sinn        
   Where CONVERT(varchar,sinn.EntryDate,102) between '''+ convert(varchar(20),@FromDate,102)+''' and '''+ convert(varchar(20),@ToDate,102) +''''+ @filterQuery +'  AND sinn.TargetID = m.TargetID         
   ORDER BY EntryDate DESC )   Order By a.TargetName'                                      
   --print(@Query)                   
  exec(@Query)                                      
--exec('select '+@ColumnLabel+','+@FormNamne+'ID from '+@FormNamne+'Master')                                      
 set @Query = ''                                      
 set @Query = 'select b.'+@ColumnLabel+',SE.StockEntryID,SE.'+@ValueLabel+',SE.'+@FormNamne+'ID from '+@FormNamne+'StockEntry SE                                   
   inner join '+@FormNamne+'Master b on SE.'+@FormNamne+'ID = b.'+@FormNamne+'ID                                       
   inner join StockEntryMain s on SE.StockEntryID=s.StockEntryID                   
           
           
      where s.StockEntryID = (Select Top 1 StockEntryID From StockEntryMain sinn           
Where CONVERT(varchar,sinn.EntryDate,102) between '''+ convert(varchar(20),@FromDate,102)+''' and '''+ convert(varchar(20),@ToDate,102) +''''+ @filterQuery +'   AND sinn.TargetID = s.TargetID         
ORDER BY EntryDate DESC ) order by b.Sequence'                                      
           
--print(@Query)                          
exec(@Query)                              
End        
    
go

