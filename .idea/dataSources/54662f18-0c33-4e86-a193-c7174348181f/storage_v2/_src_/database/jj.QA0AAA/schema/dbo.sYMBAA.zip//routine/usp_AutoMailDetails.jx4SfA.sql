    
CREATE procedure [dbo].[usp_AutoMailDetails]    
    @rptType nvarchar(250),    
 @rptID int,  
 @rptName nvarchar(250),    
 @city nvarchar(250),    
 @emailAddress nvarchar(250),    
 @rptSentOption nvarchar(250),    
 @rptSentDate nvarchar(250),    
 @rptSentDay nvarchar(250),  
 @rptScheduleRange nvarchar(50),    
 @CreatedBy nvarchar(250),    
 @CreatedDate dateTime    
as    
begin    
 SET NOCOUNT ON;    
 insert into AutoMailerDetails(ReportID, AutoReportType, AutoReportName, CityMaster, EmailAddress, ScheduleTime, ScheduleDate, ScheduleDay, ScheduleRange, CreatedBy,CreatedDate)    
 Values(@rptID, @rptType, @rptName, @city, @emailAddress,@rptSentOption,@rptSentDate,@rptSentDay,@rptScheduleRange,@CreatedBy,@CreatedDate)    
 select '1'      
end    
    
--select * from AutoMailerDetails    
    
--sp_helptext RemoveRecord
go

