CREATE Proc GetAllFormRelationColumn  --'sos'            
@FormName nvarchar(100)            
As            
Begin             
   
   exec('Select Top 1 * From ' + @FormName + 'Relation '  )           
END  
go

