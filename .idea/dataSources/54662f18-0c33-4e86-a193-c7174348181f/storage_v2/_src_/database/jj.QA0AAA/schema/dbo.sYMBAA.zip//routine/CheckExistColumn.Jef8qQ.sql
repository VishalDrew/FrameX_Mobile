CREATE PROC [dbo].[CheckExistColumn]   
@enumtype varchar(1000),  
@Columname varchar(MAX)  
  
As   
begin  
  
exec('select *  from '+ @enumtype +' Where '+@Columname  )  
  
  
End
go

