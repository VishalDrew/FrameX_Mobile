create Procedure getflashmessage   
AS
BEGIN    
Select id,mtext from flashmessage
ORDER by Createddate DESC
end
go

