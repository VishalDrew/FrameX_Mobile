create procedure usp_getCyclecloseBackup  
as  
begin  
declare @dbname varchar(300)    
set @dbname=(select DB_NAME())    
DECLARE @dateTimeAtt NVARCHAR(50) DECLARE @sfilenameAtt NVARCHAR(100)    
set @sfilenameAtt = 'D:/MonthlyBackup/'+DB_NAME()+'_' + datename(MM, GETDATE()) +'_'+ CONVERT(varchar, DATEPART(YEAR,GETDATE()))+ '.BAK'    
select @sfilenameAtt    
exec('BACKUP DATABASE '+@dbname+' TO DISK ='''+@sfilenameAtt+'''')    
    
end
go

