CREATE PROCEDURE [dbo].[usp_Update_FormInfo_By_Query]        
	@QUERY AS VARCHAR(MAX)        
	AS        
	BEGIN        
	 EXEC(@QUERY)        
	 SELECT '1'     
	END
go

