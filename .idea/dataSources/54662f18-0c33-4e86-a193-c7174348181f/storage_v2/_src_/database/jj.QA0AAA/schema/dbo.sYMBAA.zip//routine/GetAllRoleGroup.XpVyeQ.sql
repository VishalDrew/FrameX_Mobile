  
  
 CREATE procedure GetAllRoleGroup  --'GroupId'  
 @GroupID varchar(100)    
 as    
 begin    
 select Distinct rm.RoleGroupID,y.Name,y.Status,    
  Stuff((SELECT distinct ',' + s.Name     
         FROM RoleGroupMapping l    
         LEFT join RoleMaster s    
           on l.RoleID = s.RoleID     
        where l.RoleGroupID=y.RoleGroupID    
         FOR XML PATH('')),1,1,'') rolename    
from RoleGroupMapping rm,RoleGroupMaster y  where rm.RoleGroupID=y.RoleGroupID    
 end


 go

