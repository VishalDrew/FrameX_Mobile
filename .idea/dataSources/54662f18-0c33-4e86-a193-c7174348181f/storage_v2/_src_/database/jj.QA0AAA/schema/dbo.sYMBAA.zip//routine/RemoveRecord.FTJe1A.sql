
CREATE procedure RemoveRecord  --'Sosmaster','3'  
@TableName nvarchar(50)  
,@ColumnName  nvarchar(50)  
  
As  
Begin  
begin try 
Declare @Col nvarchar(100)  
set @Col= Replace(@TableName,'Master','ID')  
  
EXEC('Delete From '+@TableName +' Where '+@Col +'  ='''+@ColumnName+'''')  
select '1'   
  end try                
begin catch                
Select '0'                
end catch 
END
go

