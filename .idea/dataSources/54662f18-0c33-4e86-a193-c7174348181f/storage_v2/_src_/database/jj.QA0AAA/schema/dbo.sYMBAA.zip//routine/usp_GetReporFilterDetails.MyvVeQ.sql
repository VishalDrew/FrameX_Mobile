CREATE procedure usp_GetReporFilterDetails        
as
begin        
        
select RoleID,Name from RoleMaster where Status=1  and RoleID not in(1,2)       
        
select CityID,Name from CityMaster where Status=1        
select ClassificationID,Name from ClassificationMaster where Status=1        
select ChainID,Name  from ChainMaster where Status=1        
select RegionID,Name from RegionMaster where Status=1        
select BranchID,Name from BranchMaster where Status=1        
      
select SKU_Name, AvailabilityID from AvailabilityMaster where Status=1      
      
select distinct Sub_Category from AvailabilityMaster where Status=1      
select CategoryID,Name from CategoryMaster where Status=1  


  
  
        
    
    
        
end
go

