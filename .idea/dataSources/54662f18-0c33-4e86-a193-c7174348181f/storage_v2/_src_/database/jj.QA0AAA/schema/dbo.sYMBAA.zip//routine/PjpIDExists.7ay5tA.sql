CREATE Procedure PjpIDExists          
         
@PjpID nvarchar(50)       
As          
Begin          
if  exists(select * from pjpPlanmaster where PjpID=@PjpID)          
 begin          
  select 'True'          
 END          
ELSE          
 Begin          
  select 'False'          
 END          
END
go

