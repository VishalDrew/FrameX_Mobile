--EXEC [dbo].[GetValidationData] 'Availability_Report',' TargetID = 12140 and RoleGroupID in (2,5,6)', 'Merc_12140_201904241013419703'
--EXEC [dbo].[GetValidationData] 'Picture','TargetID = 10023 and RoleGroupID in (2,5,6)', 'Merc_10023_201905021213536223'
--EXEC [dbo].[GetValidationData] 'CompetitorActivity','RegionID = 3 and RoleGroupID in (2)', 'Merc_11016_201904251310080177'
--EXEC [dbo].[GetValidationData] 'promotion',' Targetid =10212  and RoleGroupID in (2) ', 'Merc_10212_201805221737448368'   
CREATE Procedure [dbo].[GetValidationData]  --'Picture',' Targetid =10025 and RoleGroupID in (2,3)'         
@TableName nvarchar(100),                                             
@Condition nvarchar(500),
@StockEntryId varchar(100)                                         
AS
BEGIN      

CREATE Table #Table1
(
ID int 
)


CREATE Table #Table2
(
FieldName varchar(200) 
)

Declare @SqlQuery varchar(max) = ''
                              
Declare @ColumName nvarchar(100),                                              
        @ColumID nvarchar(100),                                               
        @RelationTableName nvarchar(100),                                              
        @MasterTableName nvarchar(100)              

		Set @ColumID =@TableName+'ID'                                              
        Set @RelationTableName =@TableName+'Relation'                                              
        Set @MasterTableName =@TableName+'Master'                                              
 
  if(@TableName = 'Picture')    
begin                                       
EXEC('insert into #Table1 Select m.'+@ColumID+'           
from '+@MasterTableName+' m inner join '+@RelationTableName+' r                                               
  on r.'+@ColumID+'=m.'+@ColumID+' Where m.status=''true'' and m.QuestionRequired=1 and '+@Condition +' order by m.Sequence')   
  END
  ELSE
  BEGIN
  EXEC('insert into #Table1 Select m.'+@ColumID+'           
from '+@MasterTableName+' m inner join '+@RelationTableName+' r                                               
  on r.'+@ColumID+'=m.'+@ColumID+' Where m.status=''true'' and '+@Condition +' order by m.Sequence') 
  END                                         

 insert into #Table2 Select FieldName  From FormMaster                                         
  inner join FormFieldDetail on FormMaster.FormID=FormFieldDetail.FormID                                          
Where Name=@TableName and ForDEO='True' and ForPM = 'False' and Required = 1 

CREATE Table #FormsSpecification
(
fieldname varchar(200),
id int,
formname varchar(200)
)

insert into #FormsSpecification select t2.FieldName as FieldName,t1.ID as ID, @TableName as FormName from #table2 t2, #table1 t1 order by t2.FieldName,t1.ID

CREATE table #Uploaddata
(
	[formname] [varchar](max) NULL,
	[targetid] [varchar](100) NULL,
	[formnamemasterid] [varchar](max) NULL,
	[fieldname] [varchar](max) NULL,
	[keyvalue] [varchar](max) NULL,
	[stockentryid] [varchar](max) NULL,
	[CreatedDt] [datetime] NULL,
	[UserName] [varchar](max) NULL
)

insert into #Uploaddata select formname,targetid,formnamemasterid,fieldname,keyvalue,stockentryid,CreatedDt,UserName from [UploadCallsLoggingDB].dbo.tbl_uploaddatawithkey where projectname = db_name() and Stockentryid = @StockEntryId and formname = @TableName 


--select * from #FormsSpecification

--select * from #Uploaddata

if((select count(*) from #FormsSpecification fs where fs.formname = @TableName
 and fs.fieldname not in (select fieldname from #Uploaddata) and fs.id not in (select formnamemasterid from #Uploaddata)) > 0)
 BEGIN
  select 'False' 
  END
  ELSE
  BEGIN
  select 'True' 
  END

DROP Table #table1
DROP Table #table2

END
go

