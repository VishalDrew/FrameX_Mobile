CREATE Procedure UserExists            
           
@UserID int         
As
Begin            
if  exists(select * from UserMaster where UserID=@UserID)            
 begin            
  select 'True'            
 END            
ELSE            
 Begin            
  select 'False'            
 END            
END
go

