
create procedure usp_getRoleForDownload  
as  
begin  
  
select RoleID,Name from RoleMaster where RoleID in (4,5) and status=1  
end
go

