-- =============================================  
-- Author:  <Author,,Name>  
-- Create date: <Create Date,,>  
-- Description: <Description,,>  
-- =============================================  
create PROCEDURE [dbo].[mobgetGeofencingInfo]  
 @projectname varchar(150),  
 @targetid varchar(100)  
AS  
BEGIN  
  
 select Latitude, Longitude from targetmaster where TargetID =@targetid  
  
 select Radius,IsGeofencingRequired from framenew_main.dbo.projectmaster where ProjectName = @projectname  
   
END
go

