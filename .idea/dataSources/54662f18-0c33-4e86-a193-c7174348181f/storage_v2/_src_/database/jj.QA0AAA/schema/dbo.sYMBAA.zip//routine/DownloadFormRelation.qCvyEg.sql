Create Proc [dbo].[DownloadFormRelation] --'Implementation'            
@FormName nvarchar(100)            
As            
Begin  
      DECLARE @cols nVARCHAR(MAX)    
          
      if exists (select FormFieldDetail.FieldName from FormFieldDetail    
     inner join FormMaster on FormMaster.FormID=FormFieldDetail.FormID     
     where FormMaster.Name = @FormName and ForPM=1 and ForDEO=1)    
  Begin    
    select @cols= COALESCE(@cols + ', m.' + FormFieldDetail.FieldName    
        ,'m.' +  FormFieldDetail.FieldName)     
        from FormFieldDetail    
        inner join FormMaster on FormMaster.FormID=FormFieldDetail.FormID     
        where FormMaster.Name = @FormName and ForPM=1 and ForDEO=1    
       
     print @FormName  
     print @cols  
  
       
       
--select r.*,m.AssetElement from AssetRelation r  
--inner join AssetMaster m on r.AssetID = m.AssetID  
       
   exec('Select r.*,' + @cols + ' From ' + @FormName + 'Master m  
   inner join ' + @FormName + 'Relation r on r.' + @FormName + 'ID = m.' + @FormName + 'ID  
     WHere m.Status=''True'''  )     
  End    
   Else    
  Begin    
   select '0'    
  End    
END
go

