CREATE PROC GetAllEnumData
@enumtype varchar(100)
As 
 begin  
  exec('Select * from '+ @enumtype)  
 END
go

