CREATE Procedure [dbo].[DateExists]          
@EntryDate datetime,          
@roleid varchar(100),    
@StoreCode varchar(100)        
As          
Begin          
if  exists(Select * FROM StockEntryMain WHERE CONVERT(varchar, EntryDate,102)=@EntryDate and roleid=@roleid and TargetID=@StoreCode)          
 begin          
  select 'True'          
 END          
ELSE          
 Begin          
  select 'False'          
 END          
END  

go

