create procedure usp_getUserDetaislForUpdate        
as
begin        
select COLUMN_NAME from INFORMATION_SCHEMA.COLUMNS where TABLE_NAME='UserMaster' and COLUMN_NAME not in(        
'UserID','CreatedBy',        
'ModifiedBy',        
'CreatedDate',        
'ModifiedDate')        
End
go

