CREATE PROC SupplierStats 
AS 
  BEGIN 
  SET nocount  ON
    DECLARE  @imax INT, 
             @i    INT 
    DECLARE  @Contact VARCHAR(100), 
             @Company VARCHAR(50) 
             
   DECLARE @MainTable nvarchar(60)
   DECLARE @Full_String nvarchar(4000)
   DECLARE @ColumName nvarchar(4000)
   set @MainTable='a'; 

    DECLARE  @CompanyInfo  TABLE( 
                                 RowID       INT    IDENTITY ( 1 , 1 ), 
                                 CompanyName VARCHAR(100), 
                                 ContactName VARCHAR(50) 
                                 ) 
    INSERT @CompanyInfo 
   SELECT
    COLUMN_NAME,COLUMN_NAME
FROM
    INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc
    INNER JOIN
    INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE ccu ON tc.CONSTRAINT_NAME = ccu.Constraint_name
WHERE
    (
       
        tc.CONSTRAINT_TYPE = 'Foreign Key'
    )
    AND
    tc.TABLE_NAME = 'TargetMaster' 
   
     
    SET @imax = @@ROWCOUNT 
    SET @i = 1 
     
    WHILE (@i <= @imax) 
      BEGIN 
        SELECT @Contact = ContactName, 
               @Company = CompanyName 
        FROM   @CompanyInfo 
        WHERE  RowID = @i        
       
        set @ColumName=ISNULL(@ColumName,'') +',' +Right(@Contact,'4')+'.Name';
       set @Full_String=ISNULL(@Full_String,'') +  ' inner join ' +  REPLACE(@Contact,'ID','Master') + ' ' +  Right(@Contact,'4') +' on '+ @MainTable +'.'+ @Contact + ' = ' + Right(@Contact,'4') +'.'+@Contact  
                  
        SET @i = @i + 1 
      END -- WHILE
      
        
      DECLARE @List VARCHAR(1000)

     Select  @List =COALESCE(@List + ', ', '') + FieldName 
     From EnumFieldControlInfo
     Where FormName='TargetMaster ' 
     set @List=  REPLACE(','+@list,',',',a.')
      set @ColumName=  SUBSTRING(@ColumName,2,(LEN(@ColumName)))
      -- select @ColumName
       set @ColumName=  REPLACE(@ColumName,'.*.*','')
 
   --select @ColumName
 select 'Select '+@ColumName+' '+@List+' From TargetMaster a ' + @Full_String
   EXEC('Select '+@ColumName+' '+@List+' From TargetMaster a ' + @Full_String)
  END -- SPROC


go

