CREATE procedure usp_getQuestionOptionValue-- 'EQuestionsForm','94'  
@FormName varchar(200),  
@FormID varchar(200)  
  
as
begin  
  
  
declare @strQuery varchar(max)  
set @strQuery ='select FO.FormFieldOptionID,FO.FormID,FormFIeldID,FormFieldOption,FQuestionID,FM.QuestionMode from FormFieldOption FO inner join '+@FormName+'Master FM on FM.'+@FormName+'ID=FO.FQuestionID'   
  
set @strQuery = @strQuery+ ' Inner join FormMaster FMS on FMS.FormID=FO.FormID where FMS.FormID='+@FormID+''  
print (@strQuery)  
exec(@strQuery)  
end  
  
--select * from FormMaster
go

