
CREATE procedure usp_getDatatypeofFormbyid --'SOS'            
@FormName varchar(200)            
as            
begin            
declare @formID int            
set @formID=(select FormID  from FormMaster where Name=@FormName)            
select ControlType from FormFieldDetail where FormID=@formID       
and ForPM=1       
and ForDEO=0 and ForQDEO=1       
Union ALL      
  select ControlType from FormFieldDetail where FormID=@formID       
and ForPM=0      
and ForDEO=1 and ForQDEO=1    
Union ALL  
select ControlType from FormFieldDetail where FormID=@formID       
and ForPM=1      
and ForDEO=1 and ForQDEO=0         
end
go

