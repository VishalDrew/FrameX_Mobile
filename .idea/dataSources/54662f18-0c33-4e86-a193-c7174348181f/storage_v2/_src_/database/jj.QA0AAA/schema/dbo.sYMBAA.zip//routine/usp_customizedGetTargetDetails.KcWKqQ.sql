CREATE procedure usp_customizedGetTargetDetails
@TargetID int   
as  
begin  
select TargetID, TargetName,CM.Name as 'City',CM.CityID,CLM.Name as 'Classification',CLM.ClassificationID,CHM.Name as 'Chain',CHM.ChainID, Branch from TargetMaster TM  
inner join CityMaster CM  
on TM.CityID=CM.CityID  
inner join ClassificationMaster CLM  
on TM.ClassificationID= clm.ClassificationID  
inner join ChainMaster CHM  
on CHM.ChainID = TM.ChainID where TM.TargetID=@TargetID  
  
end
go

