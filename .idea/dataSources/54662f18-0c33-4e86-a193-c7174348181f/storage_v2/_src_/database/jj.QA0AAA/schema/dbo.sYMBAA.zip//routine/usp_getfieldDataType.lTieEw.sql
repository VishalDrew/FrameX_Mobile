
CREATE procedure usp_getfieldDataType --'End_Date'  
@fieldName varchar(300)  
as  
begin  
 select DataType from FormFieldDetail where FieldName=@fieldName  
 end
go

