create procedure usp_getTargetDetaislForUpdate  
as  
begin  
select COLUMN_NAME from INFORMATION_SCHEMA.COLUMNS where TABLE_NAME='TargetMaster' and COLUMN_NAME not in(  
'TargetID','CreatedBy',  
'ModifiedBy',  
'CreatedDate',  
'ModifiedDate')  
End
go

