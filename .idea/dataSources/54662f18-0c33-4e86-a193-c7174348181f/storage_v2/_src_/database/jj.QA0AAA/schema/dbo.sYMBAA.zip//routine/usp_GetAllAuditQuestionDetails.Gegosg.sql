create procedure usp_GetAllAuditQuestionDetails  
as  
begin  
select * from Auditmaster where Status=1  
end
go

