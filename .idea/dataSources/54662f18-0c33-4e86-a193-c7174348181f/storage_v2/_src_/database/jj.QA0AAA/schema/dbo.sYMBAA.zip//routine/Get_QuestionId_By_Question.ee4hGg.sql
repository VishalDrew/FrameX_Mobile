CREATE PROCEDURE Get_QuestionId_By_Question    
	(    
	@FORM_NAME VARCHAR(50),    
	@QUESTIONS VARCHAR(MAX)    
	)    
	AS    
	BEGIN    
	--DECLARE @FORM_NAME VARCHAR(50)    
	--DECLARE @QUESTIONS VARCHAR(MAX)    
	--SET @FORM_NAME='Program_Question'    
	--SET @QUESTIONS=' ''Star - Both Shelf Strip Backing Sheet? (Y/N)'', ''TOP 5 Countries'''    
	--PRINT @QUESTIONS    
     
	 DECLARE @QUERY VARCHAR(MAX)    
	 SET @QUERY='SELECT '+@FORM_NAME+'ID, Question FROM dbo.'+@FORM_NAME+'Master WHERE Question IN ('+@QUESTIONS+')'    
	 --PRINT @QUERY    
	 EXEC(@QUERY)    
	END
go

