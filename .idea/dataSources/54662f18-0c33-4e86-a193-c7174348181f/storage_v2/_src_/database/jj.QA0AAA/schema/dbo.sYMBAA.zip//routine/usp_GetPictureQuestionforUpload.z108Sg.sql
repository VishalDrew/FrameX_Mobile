create procedure usp_GetPictureQuestionforUpload  
as  
begin  
  
  
select TargetID, PictureID from PictureStockEntry PS  
inner join StockEntryMain SM  
on SM.StockEntryID = PS.StockEntryID group by PictureID,TargetID order by TargetID  
end
go

