
  
CREATE procedure ups_getPjpPlanMasterDetails      
as      
begin      
      
      
select PjpID,PjpTargetID,PjpUserName,CONVERT(varchar, PjpDate,104)as PjpDate from PjpPlanMaster      
end
go

