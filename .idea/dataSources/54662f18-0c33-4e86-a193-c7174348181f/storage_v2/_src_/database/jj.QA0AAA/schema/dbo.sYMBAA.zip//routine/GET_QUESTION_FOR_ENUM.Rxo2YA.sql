CREATE PROCEDURE GET_QUESTION_FOR_ENUM        
 @FORM_NAME VARCHAR(500)        
AS        
BEGIN         
 DECLARE @FORMID VARCHAR(20)        
 SET @FORMID=(SELECT FM.FormID FROM dbo.FormMaster FM WHERE Name=@FORM_NAME AND IsQuestionForm='1')        
         
 SELECT FormFieldID, FieldName        
  FROM dbo.FormFieldDetail        
  WHERE FormID=@FORMID        
  AND DataType!='int'        
  AND ControlType!='CheckBox'        
  AND ControlType!='DropDownList'        
END
go

