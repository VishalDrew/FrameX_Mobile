-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[DeleteTable]
   ON  dbo.FormMaster 
   AFTER DELETE
AS 
BEGIN
	
	declare @FormName nvarchar(50)--,@FormID int	
	--select @FormName =name from deleted
	----select @FormID =FormID from deleted
	
	----delete from FormFieldDetail where FormID=@FormID
	
	--exec('Drop table '+@FormName+'Relation')
	--exec('Drop table '+@FormName+'StockEntry')
	--exec('Drop table '+@FormName+'Master')

END
go

