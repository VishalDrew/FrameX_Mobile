create PROCEDURE usp_getCloseCallDetailsforDump        
(          
 @Condition VARCHAR(MAX),          
 @FromDate DATETIME,          
 @ToDate  DATETIME          
)          
AS          
BEGIN        
 --DECLARE @Condition VARCHAR(MAX)      
 --DECLARE @FromDate DATETIME='2016-10-01'      
 --DECLARE @ToDate  DATETIME ='2016-10-07'      
 DECLARE @QUERY VARCHAR(MAX)      
           
 SET @QUERY='SELECT TM.TargetID, TM.TargetName,TM.Address,CM.Name AS CityName,  
 SEM.StockEntryID, CONVERT(varchar,SEM.EntryDate,103) as Entrydate, SEM.Username,SEM.cMobileNo,SCC.Reason             
 FROM dbo.StockEntryMain SEM            
 INNER JOIN dbo.StockEntryCloseCall SCC ON SCC.StockEntryID=SEM.StockEntryID                  
 INNER JOIN dbo.TargetMaster   TM ON TM.TargetID=SEM.TargetID          
 INNER JOIN dbo.CityMaster   CM ON CM.CityID=TM.CityID          
 INNER JOIN dbo.ClassificationMaster CLM on CLM.ClassificationID = TM.ClassificationID          
 WHERE '+@Condition+'         
 AND Convert(varchar(10),SEM.EntryDate,120) >= '''+convert(varchar(10),@FromDate,120)+'''           
 AND Convert(Varchar(10),SEM.EntryDate,120)<= '''+ convert(varchar(10),@ToDate,120) +''''          
           
 --PRINT(@QUERY)                      
 EXEC(@QUERY)          
END
go

