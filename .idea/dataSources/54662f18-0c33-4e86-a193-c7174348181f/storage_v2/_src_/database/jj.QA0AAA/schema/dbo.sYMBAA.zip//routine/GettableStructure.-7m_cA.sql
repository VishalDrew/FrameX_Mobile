CREATE Procedure GettableStructure  
@TableName nvarchar(100)  
As  
BEgin  
EXEC('select * from '+@TableName+' Where 1=2')             
END
go

