create PROC [dbo].[AddNewRoleMap]  --'CityMaster',''  
@RoleGroupID int,  
@RoleID varchar(10)
As     
 declare @intErrorCode  Int    
 Set Nocount off               
 Begin Transaction    
begin 
  
begin  
	 declare @query varchar(8000)  
	 insert into RoleGroupMapping (RoleGroupID,RoleID) values (@RoleGroupID,@RoleID)  
	 SELECT @intErrorCode = @@ERROR            
	 IF (@intErrorCode <> 0) GOTO PROBLEM   
End  
  
 SELECT @intErrorCode = @@ERROR            
 IF (@intErrorCode <> 0) GOTO PROBLEM   
  
End  
  
COMMIT TRAN            
          select '1'  
PROBLEM:            
IF (@intErrorCode <> 0) BEGIN      
PRINT @intErrorCode  
PRINT 'Unexpected error occurred!'            
    ROLLBACK TRAN            
   select '0'           
   --drop table #temp           
END

go

