  
              
CREATE Proc sp_CycleClosedbyAdmin                      
@ID int,        
@ClosedBy varchar(200)                    
as begin                      
                     
          
declare @from  int          
set @from=1          
declare @to int          
    
--Backup of Database    
    
--declare @dbname varchar(300)    
--set @dbname=(select DB_NAME())    
--DECLARE @dateTimeAtt NVARCHAR(50) DECLARE @sfilenameAtt NVARCHAR(100)    
--set @sfilenameAtt = 'D:/MonthlyBackup/'+DB_NAME()+'_' + datename(MM, GETDATE()) +'_'+ CONVERT(varchar, DATEPART(YEAR,GETDATE()))+ '.BAK'    
--select @sfilenameAtt    
--exec('BACKUP DATABASE '+@dbname+' TO DISK ='''+@sfilenameAtt+'''')    
    
        
create table #temptable          
(tablename varchar(300),          
rowid int)          
insert into #temptable           
select TABLE_NAME, ROW_NUMBER()over(order by TABLE_NAME desc)  from INFORMATION_SCHEMA.TABLES where TABLE_NAME like '%Relation'          
set @to = @@ROWCOUNT          
while @from <=@to          
 begin          
     declare @tableName varchar(300)          
     set @tableName = (select  tablename from #temptable where rowid=@from)          
  declare @Query varchar(max)          
  set @Query = 'Truncate Table ' + @tableName          
  exec(@Query)          
  set @from=@from+1          
 end          
          
Truncate table PjpPlanMaster            
Truncate Table mVersionInfo                    
Truncate table PjpPlan                
              
Update CycleCloseMaster  set Status='Approved', ClosedDate =GETDATE(),ClosedBy=@ClosedBy where ID=@ID                     
end

go

