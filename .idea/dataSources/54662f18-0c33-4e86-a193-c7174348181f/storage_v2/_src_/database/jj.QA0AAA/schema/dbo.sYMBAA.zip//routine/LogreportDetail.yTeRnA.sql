CREATE Proc  [dbo].[LogreportDetail]    
as begin    
select PjpTargetId,PjpUserName,'T' as Status,CONVERT (varchar,Pjpdate,102)date,name as City  from PjpPlanMaster             
INNER JOIN TargetMaster TM ON Tm.TargetID = Pjptargetid      
    
INNER JOIN CityMaster CM ON CM.CityID = TM.CityID  
where CONVERT (varchar,Pjpdate,102) = CONVERT(varchar,getdate()-1,102)      
  
Union All    
Select otr.TargetId,username,ISNULL((select distinct  'TAU'  from PjpPlanMaster Where PjpTargetID = otr.TargetId       
 and  CONVERT(varchar,Pjpdate,102) = CONVERT (varchar,otr.EntryDate,102) and PjpUserName = otr.UserName),'PAU') as Status    
 ,CONVERT (varchar,EntryDate,102),name as city From StockEntryMain otr  
 INNER JOIN TargetMaster TM ON Tm.TargetID = otr.targetid        
 INNER JOIN CityMaster CM ON CM.CityID = TM.CityID  
   Where  CONVERT (varchar,otr.EntryDate,102) = CONVERT(varchar,getdate()-1,102) and cMobileNo <> 'Web'    
Union All    
   
select PjpPlan.TargetId,username,'ANU' as Status,CONVERT (varchar,Pjpdate,102),name as City From PjpPlan   
INNER JOIN TargetMaster TM ON Tm.TargetID = Pjpplan.targetid        
 INNER JOIN CityMaster CM ON CM.CityID = TM.CityID  
Where Pjpplan.Status = 'A'     
and CONVERT(varchar,Pjpdate,102) = CONVERT(varchar,getdate()-1,102)      
AND Pjpplan.TargetId NOT IN(select SEM.TargetID  from StockEntryMain SEM   
Where       
 CONVERT (varchar,SEM.EntryDate,102) = CONVERT(varchar,GETDATE()-1,102) and SEM.username = Pjpplan.username)      
  Union All    
  Select pjpplan.TargetId,username, 'TNA' Status,CONVERT (varchar,Pjpdate,102),name as City From PjpPlan   
  INNER JOIN TargetMaster TM ON Tm.TargetID = Pjpplan.targetid        
 INNER JOIN CityMaster CM ON CM.CityID = TM.CityID  
  where pjpplan.Status = 'T' AND CONVERT(varchar,Pjpdate,102) = CONVERT(varchar,getdate()-1,102)      
  Union All    
  Select  pjpplan.TargetId,username, 'PNA' Status,CONVERT (varchar,Pjpdate,102),name as City From PjpPlan   
  INNER JOIN TargetMaster TM ON Tm.TargetID = Pjpplan.targetid        
 INNER JOIN CityMaster CM ON CM.CityID = TM.CityID  
  where pjpplan.Status = 'P'       
  Union All    
  Select pjpplan.TargetId,username, 'Expired' Status,CONVERT (varchar,Pjpdate,102),name as City   
    
  From Pjpplan   
  INNER JOIN TargetMaster TM ON Tm.TargetID = Pjpplan.targetid        
 INNER JOIN CityMaster CM ON CM.CityID = TM.CityID  
  where pjpplan.Status = 'E'        
  end
go

