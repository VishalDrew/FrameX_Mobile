CREATE procedure usp_InsertPictureFormFieldDetails         
              
as      
begin                
declare @formID varchar(10)                
set @formID =(select FormID from FormMaster where Name='Picture')                
               
                
Insert Into FormFieldDetail (FormID,FieldName,DataType,ControlType,Required,ForPM,ForDEO,Fixed,UniqueField,Sequence,AnswerByPM,ForQDEO)                
values(@formID,'Activity','Varchar(500)','TextBox',1,1,1,0,1,4,0,0)                
Insert Into FormFieldDetail (FormID,FieldName,DataType,ControlType,Required,ForPM,ForDEO,Fixed,UniqueField,Sequence,AnswerByPM,ForQDEO)                
values(@formID,'Photo','Varchar(500)','FileUpload',1,0,1,0,0,5,0,1)                
Insert Into FormFieldDetail (FormID,FieldName,DataType,ControlType,Required,ForPM,ForDEO,Fixed,UniqueField,Sequence,AnswerByPM,ForQDEO)                
values(@formID,'QuestionRequired','bit','CheckBox',1,1,0,1,0,6,0,0)                   
select '1'                
end

go

