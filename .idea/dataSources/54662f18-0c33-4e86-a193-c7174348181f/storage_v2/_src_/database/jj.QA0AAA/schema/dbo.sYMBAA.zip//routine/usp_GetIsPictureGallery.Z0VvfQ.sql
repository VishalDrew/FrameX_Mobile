
CREATE procedure usp_GetIsPictureGallery  
@ReportID int  
as  
begin  
select ReportID,Name,isPictureGallery from ReportBasicMaster where ReportID=@ReportID  
end  
  
go

