CREATE PROC [dbo].[UpdateNewEnum]  --'TestMaster','Test1'  
@oldEnumName varchar(100),  
@newEnumName varchar(100),
@validation varchar(200)=''
  
As   
  
 declare @intErrorCode  Int,@oldEnumID varchar(100),@query varchar(8000)  
  
 Set Nocount off               
 Begin Transaction    
  
begin  
if not exists(select name from sys.tables where name=@newEnumName)  
begin  
  SELECT @oldEnumID = column_name  
  FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE  
  WHERE OBJECTPROPERTY(OBJECT_ID(constraint_name), 'IsPrimaryKey') = 1  
  AND table_name = @oldEnumName  
    
 SELECT @intErrorCode = @@ERROR            
 IF (@intErrorCode <> 0) GOTO PROBLEM   
  
  set @query= 'sp_RENAME '+@oldEnumName+' ,'+ @newEnumName + 'Master'  
  print @query  
    exec (@query)  
    set @query=''  
  
 SELECT @intErrorCode = @@ERROR            
 IF (@intErrorCode <> 0) GOTO PROBLEM   
  
  set @query='exec sp_RENAME '''+@newEnumName+'Master.'+@oldEnumID+''' , '''+@newEnumName+'ID'', ''COLUMN'''  
  print @query  
  exec (@query)  
  
 SELECT @intErrorCode = @@ERROR            
 IF (@intErrorCode <> 0) GOTO PROBLEM   
  
  update EnumMeta set EnumName=@newEnumName+'Master',source_table=@newEnumName+'Master'
  ,Validation =@validation
  
  where EnumName=@oldEnumName  
  
 SELECT @intErrorCode = @@ERROR            
 IF (@intErrorCode <> 0) GOTO PROBLEM   
  
End  
else   
 begin  
  select '2'  
 End  
End  
  
COMMIT TRAN            
     select '1'          
PROBLEM:            
IF (@intErrorCode <> 0) BEGIN      
PRINT @intErrorCode  
PRINT 'Unexpected error occurred!'            
    ROLLBACK TRAN            
   select '0'           
   --drop table #temp           
END
go

