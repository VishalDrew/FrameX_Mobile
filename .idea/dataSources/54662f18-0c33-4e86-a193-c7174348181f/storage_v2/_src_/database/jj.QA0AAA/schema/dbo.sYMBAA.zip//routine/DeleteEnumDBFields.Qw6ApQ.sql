CREATE Proc [dbo].[DeleteEnumDBFields]   
@enumtype varchar(500),
@FieldName varchar(100)    
AS Begin      
begin try      
declare @Query nvarchar(MAX),@FK varchar(200)      

SELECT @FK=CONSTRAINT_NAME FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE 
			WHERE OBJECTPROPERTY(OBJECT_ID(constraint_name), 'IsforeignKey') = 1
			AND table_name = @enumtype and COLUMN_NAME=@FieldName
set @Query = 'Alter table '+ @enumtype +' drop CONSTRAINT '+ @FK
print @Query    
exec (@Query)      
set @Query=''
set @Query = 'Alter table '+ @enumtype +' drop Column '+ @FieldName    
print @Query    
exec (@Query)      
delete from EnumFieldControlInfo where FieldName = @FieldName
Select '1'      
end try      
begin catch      
Select '0'      
end catch      
End
go

