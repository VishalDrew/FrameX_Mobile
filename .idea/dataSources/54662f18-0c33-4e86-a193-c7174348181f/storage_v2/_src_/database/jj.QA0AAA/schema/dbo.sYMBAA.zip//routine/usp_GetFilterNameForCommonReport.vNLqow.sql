create procedure usp_GetFilterNameForCommonReport 
@ReportName varchar(100)
as      
begin      
select Filter as ReportFilter,ReportID from CommonReportMaster  where ReportName = @ReportName    
end
go

