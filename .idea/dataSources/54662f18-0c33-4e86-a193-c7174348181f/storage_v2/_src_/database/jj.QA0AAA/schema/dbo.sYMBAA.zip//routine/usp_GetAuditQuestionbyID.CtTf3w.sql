create procedure usp_GetAuditQuestionbyID  
@ID int  
as  
begin  
select * from Auditmaster where AuditId=@ID  
end
go

