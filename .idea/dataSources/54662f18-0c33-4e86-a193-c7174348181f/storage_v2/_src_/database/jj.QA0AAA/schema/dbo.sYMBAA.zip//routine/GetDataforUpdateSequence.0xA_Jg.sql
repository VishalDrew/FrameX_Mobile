CREATE Proc GetDataforUpdateSequence  --'General_Question'            
@FormName nvarchar(100)            
As            
Begin   
  DECLARE  @imax INT,               
             @i    INT               
    DECLARE  @Contact VARCHAR(100),               
             @Company VARCHAR(50)               
                         
             DECLARE  @CompanyInfo  TABLE(               
                                 RowID       INT    IDENTITY ( 1 , 1 ),               
                                 CompanyName VARCHAR(100),               
                                 ContactName VARCHAR(50)               
                                 )               
INSERT @CompanyInfo               
Select COLUMN_NAME,COLUMN_NAME From INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc INNER JOIN              
INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE ccu ON tc.CONSTRAINT_NAME = ccu.Constraint_name wHEre              
CONSTRAINT_TYPE='FOREIGN KEY' and tc.TABLE_NAME=@FormName+'Relation' and COLUMN_NAME not in (            
            
Select COLUMN_NAME From INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc INNER JOIN              
INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE ccu ON tc.CONSTRAINT_NAME = ccu.Constraint_name wHEre              
CONSTRAINT_TYPE='PRIMARY KEY' and tc.TABLE_NAME=@FormName+'Master')            
            
SET @imax = @@ROWCOUNT               
    SET @i = 1               
                   
    WHILE (@i <= @imax)               
      BEGIN               
        SELECT @Contact = ContactName,               
               @Company = CompanyName               
        FROM   @CompanyInfo               
        WHERE  RowID = @i                      
                     
         Declare @FColumname nvarchar(100),@FColumnID nvarchar(100),@ColumName nvarchar(100)            
                     
         set @FColumname=REPLACE (@Contact,'ID','Master')            
         set @FColumnID=REPLACE (@Contact,'Master','ID')            
                     
         set @ColumName=ISNULL(@ColumName,'') + ','''' as '''+@FColumnID +'''' ;              
        -- select @ColumName as Name             
        SET @i = @i + 1               
                    
      END              
          
      DECLARE @cols nVARCHAR(MAX)    
          
      if exists (select FormFieldDetail.FieldName from FormFieldDetail    
     inner join FormMaster on FormMaster.FormID=FormFieldDetail.FormID     
     where FormMaster.Name = @FormName and ForPM=1 and ForDEO=1)    
  Begin    
    select @cols= COALESCE(@cols + ', ' + FormFieldDetail.FieldName    
        ,'' +  FormFieldDetail.FieldName)     
        from FormFieldDetail    
        inner join FormMaster on FormMaster.FormID=FormFieldDetail.FormID     
        where FormMaster.Name = @FormName and ForPM=1 and ForDEO=1    
       
   exec('Select '+@FormName+'Master.' + @FormName + 'ID, Sequence, ' + @cols + ' From ' + @FormName + 'Master           
     WHere '+@FormName+'Master.Status=''True'''  )     
            
  End    
   Else    
  Begin    
   select '0'    
   select '0'    
  End    
end  
  
--select * from General_QuestionMaster
go

