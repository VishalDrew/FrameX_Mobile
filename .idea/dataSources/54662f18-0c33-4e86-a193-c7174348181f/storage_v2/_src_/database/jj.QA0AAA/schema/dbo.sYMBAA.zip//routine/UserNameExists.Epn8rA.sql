CREATE Procedure UserNameExists        
       
@PjpUserName nvarchar(300)     
As        
Begin        
if  exists(select * from UserMaster where UserName=@PjpUserName)        
 begin        
  select 'True'        
 END        
ELSE        
 Begin        
  select 'False'        
 END        
END
go

