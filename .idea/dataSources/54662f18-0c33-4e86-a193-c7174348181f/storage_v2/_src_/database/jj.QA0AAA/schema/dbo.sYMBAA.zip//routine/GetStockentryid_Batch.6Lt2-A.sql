-- GetStockentryid_Batch 36404,'2023-11-29 11:49:00.000',4
CREATE Procedure GetStockentryid_Batch           
@targetid int,            
@entrydate datetime,            
@roleid int                 
AS begin      
declare @StockEntryId Varchar(500)  
SELECT @StockEntryId = stockentryid from mobblockstores Where targetid = @targetid AND convert(date,entrydate) = convert(date,@entrydate) AND roleid = @roleid       
IF @StockEntryId IS NULL  
BEGIN  
SELECT @StockEntryId = stockentryid from stockentrymain Where targetid = @targetid AND convert(date,entrydate) = convert(date,@entrydate)  AND roleid = @roleid      
end   
SELECT @StockEntryId         
end
go

