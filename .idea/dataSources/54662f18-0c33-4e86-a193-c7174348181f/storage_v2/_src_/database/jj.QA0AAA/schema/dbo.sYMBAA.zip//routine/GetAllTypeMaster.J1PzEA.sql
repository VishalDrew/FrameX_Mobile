CREATE PROC [dbo].[GetAllTypeMaster]

As 
 begin  
  Select *,IsDelete =
      CASE Name
         WHEN 'Merchandiser' THEN 'False'
         WHEN 'Supervisor' THEN 'False'
        
         ELSE 'True'
      END From RoleMaster  
 END
go

