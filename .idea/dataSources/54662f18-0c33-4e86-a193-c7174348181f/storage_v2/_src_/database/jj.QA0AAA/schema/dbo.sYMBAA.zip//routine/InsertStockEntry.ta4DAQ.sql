CREATE proc InsertStockEntry  
@TargetID varchar(50),          
@EntryDate datetime,          
@Remarks varchar(255),               
@Username varchar(50),            
@dActaulEntryDate datetime,          
@cMobileNo varchar(50)  
  
as              
-- declare @intErrorCode Int,@Query varchar(MAX),@FK varchar(2000) = '',@columnName varchar(100),@datatype varchar(100)          
-- Set Nocount off                
-- Begin Transaction            
          
--Begin      
  
  
    
--End              
--COMMIT TRAN                  
--PROBLEM:            
--IF (@intErrorCode <> 0) BEGIN            
--PRINT 'Unexpected error occurred!'            
--    ROLLBACK TRAN            
--   select '0'    
      
--END 
go

