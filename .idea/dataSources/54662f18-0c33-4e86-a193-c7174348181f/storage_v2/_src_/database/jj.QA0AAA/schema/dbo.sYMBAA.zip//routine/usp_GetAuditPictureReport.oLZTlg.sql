CREATE procedure usp_GetAuditPictureReport    
as    
begin    
select * from AuditPictureReport where Reportstatus=1    
end
go

