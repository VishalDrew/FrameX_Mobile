create procedure [dbo].[sp_createmenu1]-- '2'  
@RoleID int  
  
AS  
BEGIN  
  
 Select SM.SectionID,  
        UPPER(LEFT(SM.SectionName,1))+SUBSTRING(SM.SectionName,2,LEN(SM.SectionName)) as 'SectionName',  
        SSM.SubSectionID,  
        UPPER(LEFT(SSM.SubSectionName,1))+SUBSTRING(SSM.SubSectionName,2,LEN(SSM.SubSectionName)) as 'SubSectionName',  
        SSM.FormPathName   
        From  RoleAccessManagement inner join SectionMaster SM on RoleAccessManagement.SectionID=SM.SectionID  
        inner join SubSectionMaster SSM on RoleAccessManagement.SubsectionID=SSM.SubSectionID  
        Where RoleID=@RoleID  and SM.SectionName !='PJP Master'
        order by SectionSequence asc  
        --SectionName,SubSectionName,  
   
 END


go

