Create Proc [dbo].[InsertFlashmessage]
@mtext varchar(500),
@status bit,
@createdby varchar(200),
@modifiedby varchar(200)
AS BEGIN 
INSERT INTO FlashMessage(mtext,Status,createdby,modifiedby) VALUES(@mtext,@status,@createdby,@modifiedby)
select 1
END 
go

