Create Proc TranTest2
AS
BEGIN TRAN

INSERT INTO [authors]([au_id], 
	[au_lname], 
	[au_fname], 
	[phone], 
	[contract])
VALUES	('172-32-1176', 
	'Gates', 
	'Bill', 
	'800-BUY-MSFT', 
	1)

IF @@ERROR <> 0
   BEGIN
	ROLLBACK TRAN
	return 10
   END
go

