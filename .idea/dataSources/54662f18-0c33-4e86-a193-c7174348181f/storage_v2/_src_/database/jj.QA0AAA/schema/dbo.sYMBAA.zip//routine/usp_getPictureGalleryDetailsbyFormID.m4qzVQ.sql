--use jj
CREATE procedure usp_getPictureGalleryDetailsbyFormID  --'72','1=1','2014-10-07','2014-10-08'                
@FormID int,                
@Condition varchar(Max),              
@FromDate datetime,              
@ToDate datetime                
as                
begin                
declare @fldName  varchar(200)                
declare @FName varchar(300)                
declare @sql varchar(max)                
set  @fldName=(select FieldName from FormFieldDetail where FormID=@FormID and ForDEO=1 and ForPM=0 and ControlType='FileUpload')                
set  @FName=(select Name from FormMaster where FormID=@FormID and FormStatus=1)                
                
declare @picGaller varchar(300)                
set @picGaller = @FName+'StockEntry'                
                
                
set @sql='SELECT SEM.StockEntryID, '+@fldName+' as Photo, TM.TargetID, TargetName, CM.Name as CityName, CLM.Name as ClassificationName     
    FROM dbo.StockEntryMain SEM     
    INNER JOIN dbo.TargetMaster   TM on TM.TargetID=SEM.TargetID    
    INNER JOIN '+@picGaller+'    PS on PS.StockEntryID=SEM.StockEntryID    
    INNER JOIN dbo.CityMaster    CM on CM.CityID=TM.CityID            
    INNER JOIN dbo.ClassificationMaster CLM on CLM.ClassificationID = TM.ClassificationID              
    INNER JOIN dbo.PictureMaster   PM ON PM.PictureID=PS.PictureID    
    WHERE '+@Condition+'     
    AND Convert(varchar(10),SEM.EntryDate,120) >= '''+convert(varchar(10),@FromDate,120)+'''     
    AND Convert(Varchar(10),SEM.EntryDate,120)<= '''+ convert(varchar(10),@ToDate,120) +''''                
print(@sql)                
exec(@sql)                
               
end      
--CREATE procedure usp_getPictureGalleryDetailsbyFormID  --'72','1=1','2014-10-07','2014-10-08'            
--@FormID int,            
--@Condition varchar(Max),          
--@FromDate datetime,          
--@ToDate datetime            
--as            
--begin            
--declare @fldName  varchar(200)            
--declare @FName varchar(300)            
--declare @sql varchar(max)            
--set  @fldName=(select FieldName from FormFieldDetail where FormID=@FormID and ForDEO=1 and ForPM=0 and ControlType='FileUpload')            
--set  @FName=(select Name from FormMaster where FormID=@FormID and FormStatus=1)            
            
--declare @picGaller varchar(300)            
--set @picGaller = @FName+'StockEntry' 

--set @sql='select  SEM.StockEntryID,'+@fldName+' as Photo, TM.TargetID,TargetName,CM.Name as CityName,CLM.Name as ClassificationName from StockEntryMain SEM inner join TargetMaster TM            
--on TM.TargetID=SEM.TargetID            
--inner join '+@picGaller+' PS            
--on PS.StockEntryID=SEM.StockEntryID         
--Inner join CityMaster  CM on CM.CityID=TM.CityID        
--inner join ClassificationMaster CLM on CLM.ClassificationID = TM.ClassificationID          
-- where  '+@Condition+' and Convert(varchar(10),SEM.EntryDate,120) >= '''+convert(varchar(10),@FromDate,120)+''' and Convert(Varchar(10),SEM.EntryDate,120)<= '''+ convert(varchar(10),@ToDate,120) +''''
--print(@sql)            
--exec(@sql)  
--end 
go

