
CREATE procedure ups_inserauditmaster      
@Question varchar(800),      
@QuestionMode varchar(100),      
@CreatedBy varchar(200),      
@ModifiedBy varchar(200),      
@Validation varchar(400),      
@FieldOption varchar(max),      
@Status int,    
@Mode int,    
@QuestionID int ,
@QuestionSequence int  
as      
begin      
 BEGIN TRY 
 IF @Mode=1    
  BEGIN    
  Insert into Auditmaster (AuditQuestion,createdby,modifiedby,QuestionMode,[validation] ,FieldOption,[Status],QuestionSequence)      
  Values(@Question,@CreatedBy,@ModifiedBy,@QuestionMode,@Validation,@FieldOption,@Status,@QuestionSequence)      
  select '1'       
  END    
 ELSE IF @Mode=2    
  BEGIN    
   Update  Auditmaster SET AuditQuestion=@Question,createdby=@CreatedBy,modifiedby=@ModifiedBy,QuestionMode=@QuestionMode,[validation]=@Validation ,FieldOption=@FieldOption,[Status]=@Status  ,QuestionSequence=@QuestionSequence  
   WHERE AuditId=@QuestionID      
   select '1'       
  END 
 END TRY      
 BEGIN CATCH      
  select '0'      
 END CATCH 
end
go

