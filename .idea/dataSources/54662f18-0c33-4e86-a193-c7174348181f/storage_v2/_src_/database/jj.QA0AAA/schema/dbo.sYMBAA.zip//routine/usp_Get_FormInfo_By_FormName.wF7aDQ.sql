CREATE PROCEDURE usp_Get_FormInfo_By_FormName      
	(      
	 @Form_Name VARCHAR(100)      
	)      
	AS      
	BEGIN      
	 --DECLARE @Form_Name VARCHAR(50)      
	 --SET  @Form_Name='Program_Question'      
	 SELECT FM.FormID, FFD.FormFieldID     
	 FROM dbo.FormMaster    FM    
	 INNER JOIN dbo.FormFieldDetail FFD ON FFD.FormID=FM.FormID    
	 WHERE FM.Name=@Form_Name    
	 AND  FFD.FieldName='QuestionMode' AND FFD.ControlType='DropDownList'    
	END
go

