CREATE PROC DeleteQuestionFieldOption  -- 'FormMaster',2          
@FormID varchar(100),        
@FormFielD varchar(100),       
@QuestionID varchar(100)         
As         
        
BEGIN    
    
Delete from FormFieldOption where FormID=@FormID and FormFieldID=@FormFielD and FQuestionID=@QuestionID    
select '1'    
END
go

