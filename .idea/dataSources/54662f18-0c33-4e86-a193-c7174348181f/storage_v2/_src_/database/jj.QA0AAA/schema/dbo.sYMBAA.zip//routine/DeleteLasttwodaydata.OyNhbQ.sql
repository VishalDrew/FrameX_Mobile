CREATE Proc [dbo].[DeleteLasttwodaydata] 
as
begin
Declare @columns varchar(max),@qry varchar(max),
@grybloc varchar(max)  
 Select @columns=stuff((select  ','''+ stockentryid+''''   
  from MobBlockStores 
    
where  convert(varchar, entrydate, 1)  
<  DATEADD(day ,-2,convert(varchar, getdate(), 1))  
for xml path('')),1,1,'') 
--select @columns


create table #temp
(TableName varchar(200), RowiD int)
Insert into #temp

select  'Mob'+Name+'StockEntry', ROW_NUMBER()over(order by FormID)  from FormMaster
--select * from #temp

declare @count int
set @count = (select COUNT(*) from #temp)
--select @count
set @qry=''

declare @start int
set @start=1
while @start <=@count
	BEGIN
		declare @tablename varchar(300)
		set @tablename= (select TableName from #temp where RowiD=@start)
		--select @tablename
		set @qry =@qry+ ' Delete From '+@tablename+ ' where StockEntryID in ('+@columns+') '
		--print(@qry)
		set @start=@start+1
		
	END
set @qry=@qry +' Delete from MobBlockStores  where stockentryid in ('+@columns+')'
print(@qry)
drop table #temp

end
go

