 -- mobCheckAttendance 'test3','2023-05-15','P'     
CREATE PROCEDURE [dbo].[mobCheckAttendance]          
(          
 @UserName VARCHAR(50),          
 @Date  DateTime,    
 @attendanceTypes varchar(10)    
 --@res  VARCHAR(10) OUTPUT          
)          
AS          
BEGIN           
 --DECLARE @UserName VARCHAR(50)='deo'          
 --DECLARE @Date  DateTime='2017-06-25'          
           
 DECLARE @SCOUNT INT=0          
 DECLARE @res VARCHAR(10)='0'          
 SET @res=(SELECT top 1 Status FROM dbo.Attendancedetail          
     WHERE username=@UserName -- and Status =  @attendanceTypes        
     AND  date=Convert(date,@Date,111) order by date desc          
    )          
              
 IF @res IS NULL          
  SET @res='0'          
            
 --PRINT @SCOUNT          
              
 --IF @SCOUNT>0          
 -- SET @res=1          
 --ELSE          
 -- SET @res=0          
          
 SELECT @res          
END  
go

