  
 CREATE Procedure mobGetFormForDataTable --'SOS'            
 @TableName nvarchar(100)            
 As            
 BEgin            
DECLARE @List VARCHAR(1000)            
select @List =COALESCE(@List + ',', '') + COLUMN_NAME From (            
Select COLUMN_NAME,tc.TABLE_NAME From INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc INNER JOIN              
INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE ccu ON tc.CONSTRAINT_NAME = ccu.Constraint_name wHEre              
CONSTRAINT_TYPE='FOREIGN KEY' and tc.TABLE_NAME  IN           
(Select @TableName+'Relation' as Name from FormMaster Where FormStatus='true') and COLUMN_NAME not in   
(Select Name+'ID' as Name from FormMaster Where FormStatus='true')  ) a              
Select @List as 'formRelation'     
Select  Isquestionform From formmaster Where Name = @TableName  
END
 go

