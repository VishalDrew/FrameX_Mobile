  
CREATE procedure usp_GetFormForDataTableTest           
as            
begin            
             
create table #tempMap            
(Name varchar(300),            
Mapwith varchar(100),            
ROwId int            
)            
Insert into #tempMap            
select Name, FormMapWith, ROW_NUMBER()over(order by FormSequence) from FormMaster where FormStatus=1 order by FormSequence            
create table #tempFinal            
  (MapColumn varchar(300),            
  TableName varchar(300))            
            
            
declare @from int            
set @from=1            
declare @to int            
            
set @to =(select COUNT(*)+1 from #tempMap)            
            
while @from<@to            
 begin            
  declare @mapValue varchar(300)            
  declare @Name varchar(300)            
  set @mapValue = (select Mapwith from #tempMap where ROwId=@from)            
  set @Name = (select Name from #tempMap where ROwId=@from)            
              
  declare @vValue varchar(300)            
  set @vValue=(select substring(@mapValue,1,len(@mapValue)-1))            
  create table #mpValue            
  (id int,            
  MapName varchar(300))            
  insert into #mpValue            
  select top 10 * from dbo.split(@vValue,'%')            
  declare @frm int            
  set @frm=1            
  declare @tm int            
  set @tm=(select COUNT(*)+1 from #mpValue)            
  while @frm <@tm            
   begin            
    declare @mVal varchar(300)            
    set @mVal = (select MapName from #mpValue where id=@frm)            
    insert into #tempFinal            
    values(@mVal,@Name+'Relation')            
    set @frm=@frm+1            
   end            
              
  drop table #mpValue            
  set @from=@from+1            
 end            
            
            
DECLARE @List VARCHAR(max)             
select @List =COALESCE(@List + ', ', '') + MapColumn+'/'+TableName From #tempFinal             
Select @List             
             
drop table #tempFinal            
drop Table #tempMap            
            
--select * from FormMaster            
end
go

