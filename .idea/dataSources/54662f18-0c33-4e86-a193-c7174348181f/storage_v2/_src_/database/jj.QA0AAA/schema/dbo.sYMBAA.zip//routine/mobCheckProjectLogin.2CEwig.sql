CREATE proc [dbo].[mobCheckProjectLogin] --'test1','test1'               
@usrUserName varchar(500),                  
@usrPassword varchar(500)                  
as      
IF exists(select UserName from UserMaster where UserName=@usrUserName and Password=@usrPassword and Status=1)                  
Begin                  
 select *,isnull((Select status as todayattendance  From Attendancedetail where username = @usrUserName AND Convert(varchar(10),date,120) = Convert(varchar(10),GETDATE(),120) and status != 'OUT'),'') todayattendance 
 from UserMaster where UserName=@usrUserName and Password=@usrPassword   
and Status='True'                 
End                  


go

