
Create Proc usp_PjpvsActual -- '1=1'
@cond varchar(max)
AS BEGIN 
declare @query varchar(max)
declare @query1 varchar(max)
set @query = 'Select  PjpTargetID,(Convert(Varchar,PjpTargetId)+ '' '' +TargetName+'' ''+ Address) as Description,Ms.Latitude,Ms.Longitude,
                            ISNULL((Select ''green.png'' From StockEntryMain SEM Where 
                            SEM.TargetID = PjpTargetID AND UserName = PjpUserName AND CONVERT(varchar(10),EntryDate,121) = CONVERT(varchar(10),PjpDate,121)
                            ),''red.png'') as ''icontype'' From PjpPlanMaster 
                            INNER JOIN TargetMaster MS ON PjpTargetID = Ms.TargetID
                            where PjpDate =  CONVERT(varchar(10),Getdate(),121) AND '+ @cond+ 'ORDER BY icontype '

set @query1 ='SELECT Pjpusername,Convert(varchar, PjpDate,111) as Pjpdate, COUNT(*) ''PlannedCall'',(Select COUNT (*) FROM StockEntryMain Where   
 Convert(varchar, EntryDate,111) = Convert(varchar, pjp.PjpDate,111) AND Username = pjp.PjpUserName) ''UploadedCall''    From Pjpplanmaster pjp  
  Where Convert(varchar, PjpDate,111) = Convert(varchar, GETDATE(),111) AND  '+ @cond+'
Group By Pjpusername,Pjpdate'  
  EXEC(@query)
  EXEC(@query1)
  
END


go

