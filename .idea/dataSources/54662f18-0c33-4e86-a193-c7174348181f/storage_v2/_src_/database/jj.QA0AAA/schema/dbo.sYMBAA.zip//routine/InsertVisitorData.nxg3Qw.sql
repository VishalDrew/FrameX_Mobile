
CREATE Proc [dbo].[InsertVisitorData]        
 @Type varchar(300),          
 @Name varchar(300),          
 @Designation varchar(300),          
 @Remarks varchar(MAX),        
 @TargetId int,        
 @username varchar(300),          
 @RoleId int    ,     
 @groomed varchar(100),  
 @maintained varchar(100),  
 @aware varchar(100)    
           
AS  
BEGIN         
          INSERT INTO VisitorData(Type,Name,Designation,Remarks,TargetId,username,RoleId,createdby,modifiedby,  groomed,  maintained,  aware  )         
          VALUES(@Type,@Name,@Designation,@Remarks,@TargetId,@username,@RoleId,@username,@username, @groomed, @maintained, @aware  )        
          select @@identity      
END

go

