
CREATE Procedure GetAllRelationStatus --'SOS',' TargetId=''10043'''    
@tablename nvarchar(250),    
@conditions nvarchar(550)        
As    
Begin    
Declare @RelationTable nvarchar(250),@MasterTable nvarchar(250)    
    
set @RelationTable=@tablename+'Relation'    
set @MasterTable=@tablename+'Master'    
    
EXEC('Select Distinct ''True'' as ''StatusNew'','+@MasterTable+'.*     
From '+@RelationTable+' inner join '+@MasterTable+' on '+@MasterTable+'.'+@tablename+'ID='+@RelationTable+'.'+@tablename+'ID Where '+@conditions+'    
union    
Select ''False'' as ''StatusNew'','+@MasterTable+'.*    
FRom '+@MasterTable+' Where Status=''true'' and '+@tablename+'ID not 
in ( Select Distinct '+@tablename+'ID From '+@RelationTable+' Where '+@conditions+')')    
    
END    
go

