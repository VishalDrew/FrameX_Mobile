CREATE procedure usp_getTaregerAuditQuestioRelation --'23004'      
@TargetID varchar(100),  
@PictureID varchar(100)      
as      
begin      
    
select * from (     
select AuditId as 'ID',AuditQuestion as 'Question','True' as 'Status' from Auditmaster where AuditId in (select QuestionID from TargetAuditQuestionRelation  where TargetID=@TargetID and PictureID=@PictureID)  and Status=1      
union all      
      
select  AuditId as 'ID',AuditQuestion as 'Question','False' as 'Status'  from Auditmaster where AuditId  not in (select QuestionID from TargetAuditQuestionRelation where TargetID=@TargetID  and PictureID=@PictureID) and Status=1      
)a order by a.ID     
end      
      
 --select * from TargetAuditQuestionRelation
go

