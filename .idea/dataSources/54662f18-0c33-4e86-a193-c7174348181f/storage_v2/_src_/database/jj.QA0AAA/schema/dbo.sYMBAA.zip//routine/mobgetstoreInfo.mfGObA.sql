-- [mobgetstoreInfo] '10000','test'   
CREATE Proc [dbo].[mobgetstoreInfo] --'32408','muthu'          
@targetid varchar(100),              
@username varchar(150)                        
AS    
Begin                        
declare @dynamiccol varchar(max)                      
set @dynamiccol =(select ISNULL(stuff((select ',TM.'+convert(varchar(100),COLUMN_NAME)                       
  from INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE                       
  Where TABLE_NAME = 'TargetMaster' AND CONSTRAINT_NAME like 'FK%' AND COLUMN_NAME NOT IN('CityId','ClassificationID')                       
   for xml path(''))                        
   ,1,1,''),'TM.Status') )                       
declare @query varchar(max)                        
set @query ='Select cVerId as Version, TargetId,TargetId As Store_id,TargetId As StoreCode,Targetname as StoreName,TM.Classificationid,cla.Name as Classification                       
,Address,TM.CityID,CM.Name as City,TM.Latitude, TM.Longitude, '+@dynamiccol+'                        
 From TargetMaster TM                        
INNER JOIN Citymaster CM ON Tm.CityId = CM.CityId                        
INNER JOIN ClassificationMaster cla ON cla.ClassificationId = TM.ClassificationId           
INNER JOIN mversionINFO ON cVerTargetId = TargetId                     
Where TargetId = '''+@targetid+''' AND TM.Status =1'                        
                    
EXEC(@query)                
SELECT RM.RoleID,Substring(Name,0,5) RoleType from RoleMaster RM              
INNER JOIN UserMaster UM on UM.RoleId   = RM.RoleID              
Where UserName = @username   

--SELECT STUFF((SELECT Top 3 ',' + convert(varchar,EntryDate,23)          
--FROM Stockentrymain          
--where TargetID = @targetid and username = @username          
--ORDER BY convert(varchar,EntryDate,23) desc          
--FOR XML PATH('')) ,1,1,'') AS Date     
--Geofencing Changes    
  select 100 as raidus,'FALSE' as IsGeofencingRequired    
END  
  
  
go

