CREATE procedure [dbo].[sp_sections]
@RoleID int
As
BEGIN

SELECT SM.SectionID,SM.SectionName,SSM.SubSectionID,SSM.SubSectionName from 
SectionMaster SM  inner join SubSectionMaster SSM on SM.SectionID=SSM.SectionID

select * from RoleAccessManagement  Where RoleID=@RoleID
END
go

