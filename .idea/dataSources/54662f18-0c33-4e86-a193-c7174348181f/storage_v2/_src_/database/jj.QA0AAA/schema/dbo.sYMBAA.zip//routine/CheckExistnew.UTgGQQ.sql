


CREATE PROC CheckExistnew --'citymaster','bihar'
@enumtype varchar(100),  
@text varchar(200)
As   
begin  

exec('select Name from '+ @enumtype+' Where name = '''+@text+'''')  
End
go

