CREATE procedure [dbo].[usp_deletestockentriestable]
as
begin
declare @tblStockentry Table
(Name varchar(500),
rowid int)
insert into @tblStockentry
select Name+'StockEntry' as Name, ROW_NUMBER()over(order by name)as rowNo from FormMaster
--select * from @tblStockentry
declare @imax int
set @imax = @@ROWCOUNT
--select @imax
declare @iStart int
set @iStart=1
while (@iStart<=@imax)
 BEGIN
	 DECLARE @Table_Name sysname, @DynamicSQL nvarchar(4000)  
     declare @tableName nvarchar(200);  
     set @tableName= (select name from @tblStockentry where rowid= @iStart);  
     SET @Table_Name = @tableName 
	  --SET @DynamicSQL='Delete from '+ @Table_Name+' where stockEntryID in(select StockEntryID from'+ @tblStockEntryMain+')'
	  SET @DynamicSQL = N'DELETE From '+@Table_Name+' where StockentryID in (select StockEntryID from StockEntryMain where EntryDate <= DATEADD(mm, -4, GETDATE()))'
	 EXECUTE sp_executesql @DynamicSQL 
	set @iStart= @iStart+1;	
 END
end

--exec usp_deletestockentriestable
go

