Create Proc PjpvsActual
AS BEGIN
SELECT Pjpusername,Pjpdate, COUNT(*) 'PlannedCall',(Select COUNT (*) FROM StockEntryMain Where 
 Convert(varchar, EntryDate,111) = Convert(varchar, pjp.PjpDate,111) AND Username = pjp.PjpUserName) 'Uploaded Call'    From Pjpplanmaster pjp
  Where Convert(varchar, PjpDate,111) <= Convert(varchar, GETDATE(),111)
Group By Pjpusername,Pjpdate

Select PjpTargetID,PjpUserName,Convert(varchar, PjpDate,104) as PJPdate,
CASE When TargetID IS NULL THEN 'NO' else 'YES' END as 'Uploaded Same day'  From PjpPlanMaster
LEFT JOIN StockEntryMain ON TargetID = PjpTargetID AND Convert(varchar, PjpDate,111) = Convert(varchar, EntryDate,111)
Where Convert(varchar, PjpDate,111) <= Convert(varchar, GETDATE(),111)
ORDER BY PjpUserName
END




go

