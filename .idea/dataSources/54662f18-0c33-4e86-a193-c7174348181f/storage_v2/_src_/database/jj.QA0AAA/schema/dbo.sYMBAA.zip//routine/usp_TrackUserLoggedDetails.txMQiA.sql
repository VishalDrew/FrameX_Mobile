CREATE procedure usp_TrackUserLoggedDetails    
as
begin    
    
with ctr    
as    
(    
select ID,Username,Loggeddate,ROW_NUMBER()over(partition by Username order by loggeddate desc)as p from UserTracker    
)    
select UserName,LoggedDate from ctr where p=1 order by LoggedDate desc   
end
go

