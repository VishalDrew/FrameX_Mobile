CREATE proc [dbo].[USP_DeleteOldCycle]                        
as                         
Begin                        
                      
create table #tempstores                      
(StockEntryID varchar(50));                      
                    
--Insert #tempstores                      
--SELECT StockEntryID FROM StockEntryMain                         
--WHERE EntryDate < (select  top 1 * from (select top 3  CycleStartDate from CycleCloseMaster        
--Group by CycleStartDate,CycleEndDate order by CycleStartDate desc) tbl order by CycleStartDate);         
  
Insert #tempstores                      
SELECT StockEntryID FROM StockEntryMain                         
WHERE EntryDate < (select top 1  DATEADD(m,-12,CycleStartDate) CycleStartDate from CycleCloseMaster        
Group by CycleStartDate,CycleEndDate order by CycleStartDate desc);  
  
  
declare @from int        
set @from =1        
declare @to int        
create table #stockTable        
(TableName varchar(300),        
RowID int        
)        
Insert into #stockTable        
select TABLE_NAME, ROW_NUMBER()over (order by TABLE_NAME)  from INFORMATION_SCHEMA.TABLES where TABLE_NAME like '%StockEntry'        
set @to=@@ROWCOUNT        
while @from <=@to        
 begin        
  declare  @tableName nvarchar(200)        
  set @tableName = (select TableName from #stockTable where RowID=@from)        
  declare @Query varchar(Max)      
           
     set @Query=' Delete From ' +@tableName+ ' Where StockEntryID in (SELECT StockEntryID FROM #tempstores)'        
     --print (@Query)      
     exec(@Query)      
              
  set @from=@from+1        
 end        
        
Delete From StockEntryMain Where StockEntryID in (SELECT StockEntryID FROM  #tempstores);                 
Delete From PjpPlan          
RETURN @@ERROR                    
END
go

