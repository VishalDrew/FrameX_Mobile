    
CREATE Proc GetformDetailForQuestion --'Program_Question','1'                      
@tablename nvarchar(100) ,            
@questionid int            
                         
as begin             
            
              
   begin            
  --Exec('Select  '+@tablename+'Master.* from '+@tablename+'Master where '+@tablename+'ID='+@questionid  Inner join Category           
  --)        
        
    Exec('Select  '+@tablename+'Master.*,CM.Name from '+@tablename+'Master      
 Inner join CategoryMaster CM on CM.CategoryID='+@tablename+'Master.CategoryID      
 where '+@tablename+'ID='+@questionid         
  )       
             
   end                
             
              
            
end
go

