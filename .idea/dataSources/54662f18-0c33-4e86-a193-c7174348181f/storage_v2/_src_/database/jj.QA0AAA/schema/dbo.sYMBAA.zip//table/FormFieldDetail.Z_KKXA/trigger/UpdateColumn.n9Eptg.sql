CREATE trigger [dbo].[UpdateColumn] 
on [dbo].[FormFieldDetail]
After update
AS
Begin

declare @columnname nvarchar(50), @datattype nvarchar(50) ,@formID int ,@formName nvarchar(60),
@PM bit,@oldColumname nvarchar(50),@formfieldid int

select @columnname = FieldName From inserted 
select @datattype =Datatype From inserted
select @formID =FormID From inserted
select @PM=ForPM from inserted 
select @formName =Name From FormMAster Where FormID=@formID
SELECT @oldColumname = FieldName FROM deleted
select @formfieldid = FormFieldID from inserted

Select @datattype = Case When @datattype like 'Email%' THEN 'varchar(200)' else @datattype end 

if(@PM='true')
begin
Exec('sp_RENAME '''+@formName+'Master.['+@oldColumname+']'','+@columnname+',''COLUMN''')
Exec('ALTER TABLE '+@formName+'Master ALTER COLUMN '+@columnname+' '+@datattype+'')
END
else
begin
Exec('sp_RENAME '''+@formName+'StockEntry.['+@oldColumname+']'','+@columnname+',''COLUMN''')
Exec('sp_RENAME ''mob'+@formName+'StockEntry.['+@oldColumname+']'','+@columnname+',''COLUMN''')
END
update FormFieldDetail set Displayname = REPLACE(@columnname,'_',' ') where FormFieldID = @formfieldid
END
go

