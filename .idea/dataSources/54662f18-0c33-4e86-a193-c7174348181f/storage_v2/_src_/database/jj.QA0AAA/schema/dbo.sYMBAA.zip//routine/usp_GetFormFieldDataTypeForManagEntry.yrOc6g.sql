
create  procedure usp_GetFormFieldDataTypeForManagEntry-- 'SOS','Industry_Facing'  
@FormName varchar(200),  
@FieldName varchar(200)  
as  
begin  
declare @FormID int  
set @FormID=(select FormID from FormMaster where Name=@FormName)  
select DataType from FormFieldDetail where FieldName=@FieldName and FormID=@FormID  
end
go

