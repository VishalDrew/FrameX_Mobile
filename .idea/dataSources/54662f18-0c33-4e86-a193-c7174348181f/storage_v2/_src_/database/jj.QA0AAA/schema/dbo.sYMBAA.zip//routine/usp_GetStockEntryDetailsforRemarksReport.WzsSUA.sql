create procedure usp_GetStockEntryDetailsforRemarksReport  
as
begin  
select SEM.StockEntryID,TM.TargetID,TM.TargetName, SEM.EntryDate,SEM.Remarks,CONVERT(varchar,SEM.dActaulEntryDate,102)as 'ActualEntryDate',RM.Name from StockEntryMain SEM  
Inner join TargetMaster TM  
on  TM.TargetID = SEM.TargetID  
Inner join RoleMaster RM  
on RM.RoleID=SEM.RoleID  
end
go

