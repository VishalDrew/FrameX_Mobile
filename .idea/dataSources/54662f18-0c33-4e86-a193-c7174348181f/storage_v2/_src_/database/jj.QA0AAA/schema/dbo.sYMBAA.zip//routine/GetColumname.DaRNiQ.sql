CREATE Procedure GetColumname --'SKURelation'
@tableName nvarchar(60)
As
BEGIN

Select COLUMN_NAME From INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME=@tableName 

and COLUMN_NAME <>'Status' and COLUMN_NAME <> 'CreatedDate'

END
go

