CREATE Proc getflashmessagemodifyuser
@id varchar(250)
As
begin
Select username From Flashmessageuser where msgid = @id

end
go

