CREATE procedure usp_GetRoleNameforCustomizedReport-- '6'      
 @ReportID int      
 as      
 BEGIN      
 declare @role varchar(200)      
 set @role=(select Role from ReportCalculate where CalculateReportID =@ReportID)      
 select RM.Name, RM.RoleID from RoleMaster RM      
inner join       
(      
select * from dbo.splitcomma(@role,','))a      
on RM.RoleID=a.Items      
END
go

