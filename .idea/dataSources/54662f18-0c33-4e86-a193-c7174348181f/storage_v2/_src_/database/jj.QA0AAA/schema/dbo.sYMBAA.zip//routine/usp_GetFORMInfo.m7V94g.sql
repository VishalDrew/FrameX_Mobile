
CREATE PROCEDURE usp_GetFORMInfo  
(  
 @FORM_NAME VARCHAR(50)  
)  
AS  
BEGIN  
 --DECLARE @FORM_NAME VARCHAR(50)='Picture'  
     SELECT IsQuestionForm, IsPictureForm FROM dbo.FormMaster WHERE Name=@FORM_NAME  
END
go

