CREATE Proc [dbo].[DownloadRetailerscanRelation] --'Implementation'                  
@FormName nvarchar(100)                  
As                  
Begin        
                   
   exec('Select PictureID,Activity,RetailerScan,CreatedDate From ' + @FormName + 'Relation')           
End 
go

