  
            
                
CREATE Proc [dbo].[sp_getSchedulePJP]                            
                  
@username nvarchar(100)          
                       
AS BEGIN                             
Select TargetId,Status,Version,      
datename(dw,Pjpdate) AS dayofstore From PjpPlan       
Where username = @username  
SELECT Status,isnull(COUNT(*),0) AS CountStore  From PjpPlan       
Where username = @username  
GROUP BY status              
end
go

