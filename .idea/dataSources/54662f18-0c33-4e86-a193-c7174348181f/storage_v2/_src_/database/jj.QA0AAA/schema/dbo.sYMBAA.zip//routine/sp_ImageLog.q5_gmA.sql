  
CREATE proc [dbo].[sp_ImageLog]  
 @project varchar(50),  
 @visiteddate varchar(50),  
 @targetid varchar(50),  
 @storename varchar(50),  
 @calltype varchar(50),  
 @imagename varchar(50),  
 @capturetime varchar(50),  
 @originalsize varchar(50),  
 @compressedsize varchar(50),  
 @imagewith0kb varchar(50),  
 @mandatory varchar(50),  
 @totalimages varchar(50),  
 @totalmandatory varchar(50),  
 @totalnonmandatory varchar(50)  
   
  
AS  
BEGIN  
SET NOCOUNT ON;  
 Insert into ImageLog (Project_Name, Visited_Date, TargetId, StoreName, CallType, ImageName, CaptureTime, ImageOriginalSize, ImageCompressedSize, Imagewith0kb, Mandatory, TotalImages, TotalMandatory, TotalNonMandatory)  
 values(@project, @visiteddate, @targetid, @storename, @calltype, @imagename, @capturetime, @originalsize, @compressedsize, @imagewith0kb, @mandatory, @totalimages, @totalmandatory, @totalnonmandatory )  
END
go

