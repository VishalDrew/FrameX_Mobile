CREATE  TRIGGER [dbo].[CreateTables]  
ON [dbo].[FormMaster]  
AFTER INSERT
AS
BEGIN
	declare @FormName varchar(500),@Mapping varchar(500),
	@FormID int,@CreatedBy varchar(50),@SectionID int,@FormStatus int
	
	declare @isQuestionForm varchar(20)
	select @isQuestionForm = IsQuestionForm from inserted
	select @FormName = Name from inserted
	select @Mapping = FormMapWith from inserted  
	SELECT @FormStatus=FormStatus FROM INSERTED
	
    set	@Mapping=replace(@Mapping,'%',' [int] NOT NULL,')	
    
	select @FormID = FormID from inserted
	select @CreatedBy = CreatedBy from inserted
	
	--cretae form master table
    
   Exec('CREATE TABLE ' +@FormName+'Master ( '+ @FormName+'ID [int] IDENTITY(1,1) NOT NULL PRIMARY KEY,[Status] [bit] NOT NULL DEFAULT (1),[QModeDatatype] [varchar](50) NULL, [CreatedBy] [varchar](50) NOT NULL,[ModifiedBy] [varchar](50) NOT NULL,[CreatedDate] [datetime] NOT NULL DEFAULT GETDATE(),[ModifiedDate] [datetime] NOT NULL DEFAULT GETDATE())')
   Exec('CREATE TABLE ['+@FormName+'StockEntry]([StockEntryID] [varchar](50) NOT NULL,['+@FormName+'ID] [int] NOT NULL,[CreatedDate] [datetime] NOT NULL DEFAULT GETDATE(),CONSTRAINT fk_MasterStockEntry'+@FormName+' FOREIGN KEY ('+@FormName+'ID) REFERENCES '+@FormName+'Master ('+@FormName+'ID))') 
   EXEC('CREATE TABLE ['+@FormName+'Relation](['+@FormName+'ID] [int] NOT NULL,'+@Mapping+' [Status] [bit] NOT NULL,[CreatedDate] [datetime] NOT NULL DEFAULT GETDATE(),CONSTRAINT fk_MasterRelation'+@FormName+' FOREIGN KEY ('+@FormName+'ID) REFERENCES '+@FormName+'Master ('+@FormName+'ID))')
   Exec('CREATE TABLE [mob'+@FormName+'StockEntry]([StockEntryID] [varchar](50) NOT NULL,['+@FormName+'ID] [int] NOT NULL,[CreatedDate] [datetime] NOT NULL DEFAULT GETDATE())') 
   
   
   --Insert Into FormFieldDetail VALUES(@FormID,'' + @FormName+'Name','Varchar(500)','TextBox','True','True','True','True')
   Insert Into FormFieldDetail VALUES(@FormID,'CategoryID','int','DropDownList','True','True','False','True','False','1','False','False','CategoryID')
   Insert Into FormFieldDetail VALUES(@FormID,'RoleGroupID','int','DropDownList','True','True','False','True','False','2','False','False','RoleGroupID')
   Insert Into FormFieldDetail VALUES(@FormID,'Sequence','int','TextBox','True','True','False','True','False','3','False','False','Sequence')
   Insert Into FormFieldDetail VALUES(@FormID,'OneTimeQuestion','bit','CheckBox','True','True','False','True','False','4','False','False','OneTimeQuestion')
   --added for question mode
   --Insert Into FormFieldDetail VALUES(@FormID,'QuestionMode','Varchar(250)','DropDownList','True','True','False','True','False','4','False','True')
   IF(@isQuestionForm='1')
   BEGIN
   Insert Into FormFieldDetail VALUES(@FormID,'QuestionMode','Varchar(250)','DropDownList','True','True','False','True','False','6','False','True','QuestionMode')
   Insert Into FormFieldDetail VALUES(@FormID,'QuestionRequired','bit','CheckBox','True','True','False','True','False','7','False','False','QuestionRequired')
   END
   
   
   Exec('Alter Table ' +@FormName+'Master Add FOREIGN KEY (CategoryID) REFERENCES CategoryMaster(CategoryID)')
   Exec('Alter Table ' +@FormName+'Master Add FOREIGN KEY (RoleGroupID) REFERENCES RoleGroupMaster(RoleGroupID)')

	IF(@FormStatus='1')
		BEGIN
			insert into SectionMaster values (REPLACE(@FormName,'_',' ') + ' Master','10','True',@CreatedBy,@CreatedBy,getdate(),getdate())
			set @SectionID = SCOPE_IDENTITY()
			insert into SubSectionMaster values (@SectionID,'Add/Edit ' + REPLACE(@FormName,'_',' '),'formdisplay.aspx?form=' + @FormName,'True',@CreatedBy,@CreatedBy,getdate(),getdate())
			insert into SubSectionMaster values (@SectionID,'Upload ' + REPLACE(@FormName,'_',' '),'UploadMaster.aspx?form=' + @FormName,'True',@CreatedBy,@CreatedBy,getdate(),getdate())
			insert into SubSectionMaster values (@SectionID,'Manage ' + REPLACE(@FormName,'_',' ') +' Relation','ManageFormRelation.aspx?form=' + @FormName,'True',@CreatedBy,@CreatedBy,getdate(),getdate())
			insert into SubSectionMaster values (@SectionID,'Upload ' + REPLACE(@FormName,'_',' ') +' Relation','UploadRelation.aspx?form=' + @FormName,'True',@CreatedBy,@CreatedBy,getdate(),getdate())
			insert into SubSectionMaster values (@SectionID,'Update ' + REPLACE(@FormName,'_',' ') +' Sequence','UpdateSequence.aspx?form=' + @FormName,'True',@CreatedBy,@CreatedBy,getdate(),getdate())
			insert into SubSectionMaster values (@SectionID,'Update ' + REPLACE(@FormName,'_',' '),'UpdateFormMaster.aspx?form=' + @FormName,'True',@CreatedBy,@CreatedBy,getdate(),getdate())
			 --,' + @FormName+'Name [varchar](500) NOT NULL,[CategoryID] [int] not NULL,[RoleID] [int] not NULL,[Status] [bit] NOT NULL
		END
END

----OLD TRIGGER ---07_December_2016
--ALTER  TRIGGER [dbo].[CreateTables]    
--ON [dbo].[FormMaster]    
--AFTER INSERT  
--AS  
--BEGIN  
  
   
-- declare @FormName varchar(500),@Mapping varchar(500),@FormID int,@CreatedBy varchar(50),@SectionID int  
   
-- declare @isQuestionForm varchar(20)  
-- select @isQuestionForm = IsQuestionForm from inserted  
-- select @FormName = Name from inserted  
-- select @Mapping = FormMapWith from inserted    
--    set @Mapping=replace(@Mapping,'%',' [int] NOT NULL,')   
      
-- select @FormID = FormID from inserted  
-- select @CreatedBy = CreatedBy from inserted  
   
-- --cretae form master table  
      
--   Exec('CREATE TABLE ' +@FormName+'Master ( '+ @FormName+'ID [int] IDENTITY(1,1) NOT NULL PRIMARY KEY,[Status] [bit] NOT NULL DEFAULT (1),[QModeDatatype] [varchar](50) NULL, [CreatedBy] [varchar](50) NOT NULL,[ModifiedBy] [varchar](50) NOT NULL,[CreatedDate] [datetime] NOT NULL DEFAULT GETDATE(),[ModifiedDate] [datetime] NOT NULL DEFAULT GETDATE())')  
--   Exec('CREATE TABLE ['+@FormName+'StockEntry]([StockEntryID] [varchar](50) NOT NULL,['+@FormName+'ID] [int] NOT NULL,[CreatedDate] [datetime] NOT NULL DEFAULT GETDATE(),CONSTRAINT fk_MasterStockEntry'+@FormName+' FOREIGN KEY ('+@FormName+'ID) REFERENCES '+@FormName+'Master ('+@FormName+'ID))')   
--   EXEC('CREATE TABLE ['+@FormName+'Relation](['+@FormName+'ID] [int] NOT NULL,'+@Mapping+' [Status] [bit] NOT NULL,[CreatedDate] [datetime] NOT NULL DEFAULT GETDATE(),CONSTRAINT fk_MasterRelation'+@FormName+' FOREIGN KEY ('+@FormName+'ID) REFERENCES '+@FormName+'Master ('+@FormName+'ID))')  
--   Exec('CREATE TABLE [mob'+@FormName+'StockEntry]([StockEntryID] [varchar](50) NOT NULL,['+@FormName+'ID] [int] NOT NULL,[CreatedDate] [datetime] NOT NULL DEFAULT GETDATE())')   
     
     
--   --Insert Into FormFieldDetail VALUES(@FormID,'' + @FormName+'Name','Varchar(500)','TextBox','True','True','True','True')  
--   Insert Into FormFieldDetail VALUES(@FormID,'CategoryID','int','DropDownList','True','True','False','True','False','1','False','False')  
--   Insert Into FormFieldDetail VALUES(@FormID,'RoleGroupID','int','DropDownList','True','True','False','True','False','2','False','False')  
--   Insert Into FormFieldDetail VALUES(@FormID,'Sequence','int','TextBox','True','True','False','True','False','3','False','False')  
--   Insert Into FormFieldDetail VALUES(@FormID,'OneTimeQuestion','bit','CheckBox','True','True','False','True','False','4','False','False')  
--   --added for question mode  
--   --Insert Into FormFieldDetail VALUES(@FormID,'QuestionMode','Varchar(250)','DropDownList','True','True','False','True','False','4','False','True')  
--   IF(@isQuestionForm='1')  
--   BEGIN  
--   Insert Into FormFieldDetail VALUES(@FormID,'QuestionMode','Varchar(250)','DropDownList','True','True','False','True','False','6','False','True')  
--   Insert Into FormFieldDetail VALUES(@FormID,'QuestionRequired','bit','CheckBox','True','True','False','True','False','7','False','False')  
--   END  
     
     
--   Exec('Alter Table ' +@FormName+'Master Add FOREIGN KEY (CategoryID) REFERENCES CategoryMaster(CategoryID)')  
--   Exec('Alter Table ' +@FormName+'Master Add FOREIGN KEY (RoleGroupID) REFERENCES RoleGroupMaster(RoleGroupID)')  
  
-- insert into SectionMaster values (@FormName + ' Master','10','True',@CreatedBy,@CreatedBy,getdate(),getdate())  
-- set @SectionID = SCOPE_IDENTITY()  
-- insert into SubSectionMaster values (@SectionID,'Add/Edit ' + @FormName,'formdisplay.aspx?form=' + @FormName,'True',@CreatedBy,@CreatedBy,getdate(),getdate())  
-- insert into SubSectionMaster values (@SectionID,'Upload ' + @FormName,'UploadMaster.aspx?form=' + @FormName,'True',@CreatedBy,@CreatedBy,getdate(),getdate())  
-- insert into SubSectionMaster values (@SectionID,'Manage ' + @FormName +' Relation','ManageFormRelation.aspx?form=' + @FormName,'True',@CreatedBy,@CreatedBy,getdate(),getdate())  
-- insert into SubSectionMaster values (@SectionID,'Upload ' + @FormName +' Relation','UploadRelation.aspx?form=' + @FormName,'True',@CreatedBy,@CreatedBy,getdate(),getdate())  
-- insert into SubSectionMaster values (@SectionID,'Update ' + @FormName +' Sequence','UpdateSequence.aspx?form=' + @FormName,'True',@CreatedBy,@CreatedBy,getdate(),getdate())  
  
  
--   --,' + @FormName+'Name [varchar](500) NOT NULL,[CategoryID] [int] not NULL,[RoleID] [int] not NULL,[Status] [bit] NOT NULL  
  
   
--END  
go

