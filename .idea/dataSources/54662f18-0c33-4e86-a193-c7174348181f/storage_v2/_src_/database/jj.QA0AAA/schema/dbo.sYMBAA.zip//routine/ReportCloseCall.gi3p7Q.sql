CREATE PROCEDURE ReportCloseCall      
(      
 @FromDate DATETIME,--='2016.07.06'      
 @ToDate  DATETIME,--='2016.07.15'      
 @LastCall INT=0,      
 @TargetID VARCHAR(10),--='10441'      
 @RoleID  VARCHAR(10)='0',      
 @CityID  VARCHAR(50)='0'    
)       
AS      
BEGIN      
 --DECLARE @FromDate DATETIME='2016.07.06'      
 --DECLARE @ToDate  DATETIME='2016.07.15'      
 --DECLARE @LastCall INT=0      
 --DECLARE @TargetID VARCHAR(10)--='10441'      
 --DECLARE @RoleID   VARCHAR(10)='0'      
 --DECLARE @CityID   VARCHAR(20)='0'      
       
 DECLARE @QUERY  VARCHAR(MAX)      
       
 IF(@LastCall=0)      
  BEGIN      
   SET @QUERY='SELECT SEM.StockEntryID, SEM.TargetID, TM.TargetName, SEM.EntryDate, SEM.Username, SEM.dActaulEntryDate, SEM.cMobileNo, SEM.Latitude, SEM.Longitude,      
      SCC.Reason,    
      CM.Name AS CityName    
      
      FROM dbo.StockEntryMain SEM      
      INNER JOIN dbo.StockEntryCloseCall SCC ON SCC.StockEntryID=SEM.StockEntryID      
      INNER JOIN dbo.TargetMaster   TM  ON TM.TargetID=SEM.TargetID    
      INNER JOIN dbo.CityMaster    CM  ON CM.CityID=TM.CityID    
      WHERE CONVERT(VARCHAR,SEM.dActaulEntryDate,102) BETWEEN '''+CONVERT(VARCHAR(20),@FromDate,102)+''' AND '''+CONVERT(VARCHAR(20),@ToDate,102)+''' '      
  END      
 ELSE      
  BEGIN      
   SET @QUERY='SELECT TOP 1 SEM.StockEntryID, SEM.TargetID, TM.TargetName, SEM.EntryDate, SEM.Username, SEM.dActaulEntryDate, SEM.cMobileNo, SEM.Latitude, SEM.Longitude,      
      SCC.Reason,    
      CM.Name AS CityName    
          
      FROM dbo.StockEntryMain SEM      
      INNER JOIN dbo.StockEntryCloseCall SCC ON SCC.StockEntryID=SEM.StockEntryID      
      INNER JOIN dbo.TargetMaster   TM  ON TM.TargetID=SEM.TargetID    
      INNER JOIN dbo.CityMaster    CM  ON CM.CityID=TM.CityID    
      WHERE CONVERT(VARCHAR,SEM.dActaulEntryDate,102) BETWEEN '''+CONVERT(VARCHAR(20),@FromDate,102)+''' AND '''+CONVERT(VARCHAR(20),@ToDate,102)+''' '      
  END      
           
 IF(@TargetID!='')      
 BEGIN      
  SET @QUERY+=' AND TargetID='+@TargetID+' '      
 END      
       
 IF(@RoleID!='0')      
 BEGIN      
  SET @QUERY+=' AND RoleID='+@RoleID+' '      
 END      
     
 IF(@CityID!='0')      
 BEGIN      
  SET @QUERY+=' AND CM.CityID IN ('+@CityID+') '      
 END      
    
       
 IF(@LastCall!=0)      
 BEGIN      
  SET @QUERY+=' ORDER BY dActaulEntryDate DESC'      
 END      
      
 --PRINT(@QUERY)      
 EXEC(@QUERY)      
END 

go

