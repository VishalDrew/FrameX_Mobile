CREATE procedure usp_getFormMasterlForUpdate     
@tableName varchar(100)    
as        
begin        
select COLUMN_NAME from INFORMATION_SCHEMA.COLUMNS where TABLE_NAME= @tableName + 'Master' and COLUMN_NAME not in(        
@tableName+'ID','CreatedBy',        
'ModifiedBy',        
'CreatedDate',        
'ModifiedDate')        
End 
go

