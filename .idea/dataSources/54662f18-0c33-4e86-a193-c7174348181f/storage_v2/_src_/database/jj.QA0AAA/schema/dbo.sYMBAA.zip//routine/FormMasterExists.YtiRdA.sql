-- FormMasterExists 45,'Promotion'  
CREATE PROCEDURE FormMasterExists  
    @MasterID INT,  
    @FormName VARCHAR(100)  
AS  
BEGIN  
    DECLARE @SQL NVARCHAR(MAX)  
  
    -- Construct the dynamic SQL query  
    SET @SQL = N'  
        IF EXISTS (SELECT 1 FROM ' + QUOTENAME(@FormName + 'Master') + ' WHERE ' + QUOTENAME(@FormName + 'ID') + ' = @MasterID)  
            SELECT ''True'' AS Result  
        ELSE  
            SELECT ''False'' AS Result'  
    -- Execute the dynamic SQL query  
    EXEC sp_executesql @SQL, N'@MasterID INT', @MasterID  
END  
go

