CREATE PROCEDURE usp_getCloseCallDetails            
(            
 @Condition VARCHAR(MAX),            
 @FromDate DATETIME,            
 @ToDate  DATETIME            
)            
AS            
BEGIN          
 --DECLARE @Condition VARCHAR(MAX)        
 --DECLARE @FromDate DATETIME='2016-10-01'        
 --DECLARE @ToDate  DATETIME ='2016-10-07'        
 DECLARE @QUERY VARCHAR(MAX)        
             
 SET @QUERY='SELECT SEM.StockEntryID, SCC.Reason,            
   TM.TargetID, TM.TargetName,            
   CM.Name AS CityName,            
   (SELECT TOP 1 CLM.Name FROM dbo.ClassificationMaster CLM WHERE CLM.ClassificationID = TM.ClassificationID) AS  ClassificationName,      
   Convert(varchar(11),SEM.EntryDate,113) as EntryDate, SEM.Username, SEM.cMobileNo             
 FROM dbo.StockEntryMain SEM              
 INNER JOIN dbo.StockEntryCloseCall SCC ON SCC.StockEntryID=SEM.StockEntryID                    
 INNER JOIN dbo.TargetMaster   TM ON TM.TargetID=SEM.TargetID            
 INNER JOIN dbo.CityMaster   CM ON CM.CityID=TM.CityID            
 WHERE '+@Condition+'           
 AND Convert(varchar(10),SEM.EntryDate,120) >= '''+convert(varchar(10),@FromDate,120)+'''             
 AND Convert(Varchar(10),SEM.EntryDate,120)<= '''+ convert(varchar(10),@ToDate,120) +''''            
             
 --PRINT(@QUERY)                        
 EXEC(@QUERY)            
END     
--CREATE PROCEDURE usp_getCloseCallDetails        
--(        
-- @Condition VARCHAR(MAX),        
-- @FromDate DATETIME,        
-- @ToDate  DATETIME        
--)        
--AS        
--BEGIN        
-- DECLARE @QUERY VARCHAR(MAX)        
         
-- SET @QUERY='SELECT SEM.StockEntryID, SCC.Reason,        
--   TM.TargetID, TM.TargetName,        
--   CM.Name AS CityName,        
--   CLM.Name as ClassificationName        
-- FROM dbo.StockEntryMain SEM          
-- INNER JOIN dbo.StockEntryCloseCall SCC ON SCC.StockEntryID=SEM.StockEntryID                
-- INNER JOIN dbo.TargetMaster   TM ON TM.TargetID=SEM.TargetID        
-- INNER JOIN dbo.CityMaster   CM ON CM.CityID=TM.CityID        
-- INNER JOIN dbo.ClassificationMaster CLM on CLM.ClassificationID = TM.ClassificationID        
-- WHERE '+@Condition+'         
-- AND Convert(varchar(10),SEM.EntryDate,120) >= '''+convert(varchar(10),@FromDate,120)+'''         
-- AND Convert(Varchar(10),SEM.EntryDate,120)<= '''+ convert(varchar(10),@ToDate,120) +''''        
         
-- --PRINT(@QUERY)                    
-- EXEC(@QUERY)        
--END 
go

