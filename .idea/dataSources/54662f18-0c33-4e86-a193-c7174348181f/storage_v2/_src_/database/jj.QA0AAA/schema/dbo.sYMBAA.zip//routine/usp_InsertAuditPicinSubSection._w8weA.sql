CREATE procedure usp_InsertAuditPicinSubSection    
as    
begin    
    
INSERT INTO SubSectionMaster(SectionID,SubSectionName,FormPathName,Status,CreatedBy,ModifiedBy,CreatedDate,ModifiedDate)    
VALUES ('22','Audit Pictrue Report','AuditPictureReport.aspx','1','defualtpm','defaultpm',GETDATE(),GETDATE())    
end
go

