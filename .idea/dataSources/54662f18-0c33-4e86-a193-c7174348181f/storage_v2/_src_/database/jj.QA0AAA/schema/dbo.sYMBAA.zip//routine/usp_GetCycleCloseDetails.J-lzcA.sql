CREATE procedure usp_GetCycleCloseDetails    
as    
begin    
    
select ID,CycleStartDate,CycleEndDate,Status from CycleCloseMaster    
end
go

