create procedure usp_GetUserDataDetailsforUpdate 
 @strQuery varchar(MAX)
as  
BEGIN  
 exec(@strQuery)
END
go

