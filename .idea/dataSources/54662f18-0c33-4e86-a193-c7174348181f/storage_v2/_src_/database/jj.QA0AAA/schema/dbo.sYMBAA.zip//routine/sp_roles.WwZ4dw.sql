CREATE procedure [dbo].[sp_roles]
As
BEGIN
SELECT [RoleID]
      ,[Name]      
      ,[Status]
      ,[CreatedBy]
      ,[ModifiedBy]
      ,[CreatedDate]
      ,[ModifiedDate]
  FROM [RoleMaster]
END
go

