create procedure usp_DeleteReportBasic    
@ReportID int    
as    
begin    
delete from ReportBasicMaster where ReportID=@ReportID    
end
go

