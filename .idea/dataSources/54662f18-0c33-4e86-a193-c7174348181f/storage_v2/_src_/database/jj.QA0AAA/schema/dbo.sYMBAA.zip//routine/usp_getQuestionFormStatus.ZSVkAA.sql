CREATE procedure usp_getQuestionFormStatus --'Employee'  
@FormName varchar(300)  
as  
begin  
select IsQuestionForm, FormID from FormMaster where Name=@FormName  
end
go

