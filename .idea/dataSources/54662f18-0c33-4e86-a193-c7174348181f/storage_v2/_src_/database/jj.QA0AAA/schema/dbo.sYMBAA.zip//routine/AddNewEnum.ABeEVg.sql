

CREATE PROC [dbo].[AddNewEnum]  --'order_booking','','',''    
@enumtype varchar(100),    
@status varchar(100),    
@user varchar(100),  
@Validation varchar(500) = ''  
As     
    
 declare @intErrorCode  Int    
    
 Set Nocount off                 
 Begin Transaction      
    
    
begin    
    
if exists(select EnumName from EnumMeta where EnumName=@enumType + 'Master') OR exists (select name from sys.tables where name=@enumType + 'Master')    
Begin    
 select '2'    
    
 SELECT @intErrorCode = @@ERROR              
 IF (@intErrorCode <> 0) GOTO PROBLEM     
End    
    
    
 SELECT @intErrorCode = @@ERROR              
 IF (@intErrorCode <> 0) GOTO PROBLEM     
    
 declare @query varchar(8000)    
    
if not exists (select name from sys.tables where name=@enumType + 'Master')    
begin    
 set @query = 'CREATE TABLE [dbo].['+@enumType+'Master](    
  ['+@enumType+'ID] [int] IDENTITY(1,1) NOT NULL,    
  [Name] [varchar](500) NOT NULL,    
  [Sequence] [int] NULL,    
  [Status] [bit] NOT NULL,    
  [CreatedBy] [varchar](50) NOT NULL,    
  [ModifiedBy] [varchar](50) NOT NULL,    
  [CreatedDate] [datetime] NOT NULL,    
  [ModifiedDate] [datetime] NOT NULL,    
  CONSTRAINT [PK_'+@enumType+'Master] PRIMARY KEY CLUSTERED     
 (    
  ['+@enumType+'ID] ASC    
 )WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]    
 ) ON [PRIMARY]    
    
 SET ANSI_PADDING OFF    
    
    
 ALTER TABLE [dbo].['+@enumType+'Master] ADD  CONSTRAINT [DF_'+@enumType+'Master_Sequence]  DEFAULT ((0)) FOR [Sequence]    
    
    
 ALTER TABLE [dbo].['+@enumType+'Master] ADD  CONSTRAINT [DF_'+@enumType+'Master_Status]  DEFAULT ((1)) FOR [Status]    
    
    
 ALTER TABLE [dbo].['+@enumType+'Master] ADD  CONSTRAINT [DF_'+@enumType+'Master_CratedDate]  DEFAULT (getdate()) FOR [CreatedDate]    
    
    
 ALTER TABLE [dbo].['+@enumType+'Master] ADD  CONSTRAINT [DF_'+@enumType+'Master_ModifiedDate]  DEFAULT (getdate()) FOR [ModifiedDate]    
 '    
 SELECT @intErrorCode = @@ERROR              
 IF (@intErrorCode <> 0) GOTO PROBLEM     
 print @query    
 exec (@query)    
 SELECT @intErrorCode = @@ERROR              
 IF (@intErrorCode <> 0) GOTO PROBLEM     
     
end    
    
 SELECT @intErrorCode = @@ERROR              
 IF (@intErrorCode <> 0) GOTO PROBLEM     
     
    
if not exists (select EnumName from EnumMeta where EnumName=@enumType + 'Master')    
begin    
 insert into EnumMeta (EnumName,source_table,Validation,status,CreatedBy,ModifiedBy) values (@enumType + 'Master',@enumType + 'Master',@Validation,@status,@user,@user)    
 SELECT @intErrorCode = @@ERROR              
 IF (@intErrorCode <> 0) GOTO PROBLEM     
End    
    
if not exists (select * from SubSectionMaster where SubSectionName=@enumType + ' Master')    
begin    
 insert into SubSectionMaster (SectionID,SubSectionName,FormPathName,status,CreatedBy,ModifiedBy) values ('6',@enumType + ' Master','EnumMaster.aspx?form='+@enumType,@status,@user,@user)    
 SELECT @intErrorCode = @@ERROR              
 IF (@intErrorCode <> 0) GOTO PROBLEM     
End    
    
 SELECT @intErrorCode = @@ERROR              
 IF (@intErrorCode <> 0) GOTO PROBLEM     
    
End    
    
COMMIT TRAN              
          select '1'    
PROBLEM:              
IF (@intErrorCode <> 0) BEGIN        
PRINT @intErrorCode    
PRINT 'Unexpected error occurred!'              
    ROLLBACK TRAN              
   select '0'             
   --drop table #temp             
END
go

