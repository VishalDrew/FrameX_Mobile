/*       
Desc:Remove the ALL Relation table and PJP plan    
*/    
CREATE PROCEDURE PROC_RemoveRelationTable --'PictureRelation','PictureRelation_03302021162153'    
@RelationTable varchar(200),    
@BackupTableName varchar(200)    
AS    
BEGIN    
SET NOCOUNT ON;    
DECLARE @DynamicSQL NVARCHAR(4000)    
DECLARE @RemoveTable NVARCHAR(4000)    
DECLARE @BackupTable NVARCHAR(4000)    
DECLARE @SelectTable NVARCHAR(4000)    
SET @BackupTable = N'SELECT * into ' + @BackupTableName +' FROM '+@RelationTable    
    
SET @RemoveTable = N'DELETE FROM '+@RelationTable    
    
SET @SelectTable = N'SELECT * FROM '+@BackupTableName    
--SET @DynamicSQL = N'SELECT * FROM ' + @RelationTable    
--EXECUTE sp_executesql @DynamicSQL    
PRINT @BackupTable    
PRINT @RemoveTable    
PRINT @SelectTable    
EXECUTE sp_executesql @BackupTable    
EXECUTE sp_executesql @RemoveTable    
EXECUTE sp_executesql @SelectTable    
END
go

