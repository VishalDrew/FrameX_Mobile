CREATE procedure usp_UpdateFormSequence  
  
as  
begin  
  
select FormID,Name,FormSequence as 'Sequence' from FormMaster  where FormStatus=1
  
end
go

