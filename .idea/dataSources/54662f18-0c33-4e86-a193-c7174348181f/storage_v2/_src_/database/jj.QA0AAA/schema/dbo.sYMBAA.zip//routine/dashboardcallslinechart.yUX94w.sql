  
CREATE proc dashboardcallslinechart --''      
@userid varchar(200)      
As begin      
      
if (@userid = '')      
begin      
    
Select Convert(varchar,DAY(Entrydate))+'-'+ Convert(varchar(3),DateName(month,Entrydate))as Entrydate,COUNT(*) as Calls,Convert(varchar,Entrydate,102)  From StockEntryMain     
Where Convert(varchar,Entrydate,102) >= Convert(varchar,GETDATE()-10,102)     
    
 GROUP BY Convert(varchar,DAY(Entrydate))+'-'+ Convert(varchar(3),DateName(month,Entrydate)),Convert(varchar,Entrydate,102)  
 Order by Convert(varchar,Entrydate,102)
    
end      
else       
begin      
    
Select Convert(varchar,DAY(Entrydate))+'-'+ Convert(varchar(3),DateName(month,Entrydate))as Entrydate,COUNT(*) as Calls,Convert(varchar,Entrydate,102) From StockEntryMain     
Where Convert(varchar,Entrydate,102) >= Convert(varchar,GETDATE()-10,102) and Username=@userid    
    
 GROUP BY Convert(varchar,DAY(Entrydate))+'-'+ Convert(varchar(3),DateName(month,Entrydate)),Convert(varchar,Entrydate,102)  
 Order by Convert(varchar,Entrydate,102)    
end      
end
go

