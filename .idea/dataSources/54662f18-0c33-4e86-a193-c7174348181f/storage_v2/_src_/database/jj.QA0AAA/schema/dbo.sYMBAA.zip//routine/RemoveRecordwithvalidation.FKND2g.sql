
CREATE procedure RemoveRecordwithvalidation  --'usermaster','defaultmerchandiser'    
@TableName nvarchar(100)    
,@ColumnName  nvarchar(100)    
As    
Begin    
Declare @stk varchar(100) = null  
IF @TableName = 'Targetmaster'  
begin  
set @stk = (select top 1 StockEntryID From StockEntryMain Where  TargetID = @ColumnName)  
if @stk is null  
begin  
Delete From TargetMaster where TargetID = @ColumnName  
select '1'  
  
end  
else  
begin  
select 'Data Entry Exist can`t Remove'  
  
end  
end  
else  
begin  
set @stk = (select top 1 StockEntryID From StockEntryMain Where  Username = (Select username from usermaster where userid =@ColumnName))  
if @stk is null  
begin  
Delete From UserMaster where UserID = @ColumnName  
select '1'  
end  
else  
begin  
select 'Data Entry Exist can`t Remove'  
end  
end  
END
go

