create PROC [dbo].[AddNewRoleGroup] 
@RoleGroupName varchar(100),  
@status varchar(100),  
@user varchar(100)
As     
 declare @intErrorCode  Int    
 Set Nocount off               
 Begin Transaction    
begin  
  
if exists(select RoleGroupID from RoleGroupMaster where Name=@RoleGroupName)
	Begin  
	 select '2'  
	  
	 SELECT @intErrorCode = @@ERROR            
	 IF (@intErrorCode <> 0) GOTO PROBLEM   
End 
 else
begin  
	 declare @query varchar(8000)  
	 insert into RoleGroupMaster (Name,Status,CreatedBy,ModifiedBy) values (@RoleGroupName,@status,@user,@user)  
	 SELECT @intErrorCode = @@ERROR            
	 IF (@intErrorCode <> 0) GOTO PROBLEM   
End  
  
 SELECT @intErrorCode = @@ERROR            
 IF (@intErrorCode <> 0) GOTO PROBLEM   
  
End  
  
COMMIT TRAN            
          select '1'  
PROBLEM:            
IF (@intErrorCode <> 0) BEGIN      
PRINT @intErrorCode  
PRINT 'Unexpected error occurred!'            
    ROLLBACK TRAN            
   select '0'           
   --drop table #temp           
END

go

