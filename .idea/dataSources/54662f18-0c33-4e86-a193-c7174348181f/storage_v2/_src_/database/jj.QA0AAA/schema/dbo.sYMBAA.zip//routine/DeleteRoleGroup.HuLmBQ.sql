create PROC [dbo].[DeleteRoleGroup]            
@GrpRoleID varchar(50)            
            
As begin        
begin try         
  delete from RoleGroupMapping where RoleGroupID=@GrpRoleID
  delete from RoleGroupMaster where RoleGroupID= @GrpRoleID       
select '1' 
end try              
begin catch              
Select '0'              
end catch              
End
go

