CREATE procedure [dbo].[Usp_DeleteRelationTable]  
as  
BEGIN  
SET NOCOUNT ON;  
 DECLARE @MyTable TABLE  
(  
    
  Name varchar(500),  
  rowid int  
)  
 insert into @MyTable  
 select name, row_number()over(order by name) from sys.tables where name like '%Relation'  
 --select * from @MyTable  
 DECLARE @intMax INT  
 set @intMax= @@ROWCOUNT;  
 DECLARE @intFlag INT  
 SET @intFlag = 1  
 WHILE (@intFlag <=@intMax)  
 BEGIN  
    DECLARE @Table_Name sysname, @DynamicSQL nvarchar(4000)    
     declare @tableName nvarchar(200);    
     set @tableName= (select name from @MyTable where rowid= @intFlag);    
     SET @Table_Name = @tableName    
 SET @DynamicSQL = N'DELETE  FROM ' + @Table_Name    
  EXECUTE sp_executesql @DynamicSQL    
 set @intFlag = @intFlag + 1  
 END  
   
   
END  
  
  
  
--sp_helptext Usp_DeleteRelationTable
go

