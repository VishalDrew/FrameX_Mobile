CREATE PROCEDURE mobGetSettingDetails
AS
BEGIN
	SELECT TOP 1 ServerPath, BuildVersionPath, LogFilePath FROM [dbo].[MobileSetting]
END
go

