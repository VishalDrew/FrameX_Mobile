create procedure usp_DownloadAuditQuestionRelation    
as    
begin    
select TAQ.TargetID,TAQ.PictureID,PM.Activity,TAQ.QuestionID,AM.AuditQuestion,CONVERT(varchar,TAQ.CreatedDate,104)as 'CreatedDate',TAQ.CreatedBy,CONVERT(varchar,TAQ.ModifiedDate,104)as 'ModifiedDate',TAQ.ModifiedBy from TargetAuditQuestionRelation TAQ    
 
inner join Auditmaster AM on AM.AuditId=TAQ.QuestionID    
Inner Join PictureMaster PM on PM.PictureID=TAQ.PictureID    
end
go

