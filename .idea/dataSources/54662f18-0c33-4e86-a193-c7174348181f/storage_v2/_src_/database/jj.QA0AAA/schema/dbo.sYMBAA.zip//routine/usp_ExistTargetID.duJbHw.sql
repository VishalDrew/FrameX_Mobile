CREATE procedure usp_ExistTargetID --'1234'  
@TargetID varchar(100)  
as  
begin  
select TargetID,TargetName from TargetMaster where TargetID=@TargetID  
end  
  
 --select * from TargetAuditQuestionRelation
go

