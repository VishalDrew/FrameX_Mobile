  
CREATE PROCEDURE [dbo].[UpdatePjpPlannDetails]  
  
      @PjpID nvarchar(50),  
  
      @PjpTargetID int,  
  
      @PjpUserName varchar(250),  
  
      @PjpDate datetime,  
      @ModifiedBy nvarchar(250),  
      @ModifiedDate datetime  
  
AS  
  
BEGIN  
  
      SET NOCOUNT ON;  
  
      UPDATE  pjpPlanmaster SET PjpTargetID = @PjpTargetID, PjpUserName = @PjpUserName, PjpDate=@PjpDate,  
      ModifiedBy=@ModifiedBy, ModifiedDate=@ModifiedDate  
  
      WHERE PjpId=@PjpID  
  
END  
  
--select * from pjpPlanmaster
go

