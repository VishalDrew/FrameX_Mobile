create PROC [dbo].[UpdateRoleGroup] 
@RoleGroupName varchar(100), 
@grpid varchar(10), 
@status varchar(100),  
@user varchar(100)
As     
 declare @intErrorCode  Int    
 Set Nocount off               
 Begin Transaction    
begin  
  
if exists(select RoleGroupID from RoleGroupMaster where Name=@RoleGroupName and RoleGroupID<>@grpid )
	Begin  
	 select '2'  
	  
	 SELECT @intErrorCode = @@ERROR            
	 IF (@intErrorCode <> 0) GOTO PROBLEM   
End 
 else
begin  
	 declare @query varchar(8000)  
	 update  RoleGroupMaster set Name=@RoleGroupName,Status=@status,ModifiedBy=@user where RoleGroupID=@grpid
	 delete from RoleGroupMapping where RoleGroupID=@grpid
	 	 SELECT @intErrorCode = @@ERROR            
	 IF (@intErrorCode <> 0) GOTO PROBLEM   
End  
  
 SELECT @intErrorCode = @@ERROR            
 IF (@intErrorCode <> 0) GOTO PROBLEM   
  
End  
  
COMMIT TRAN            
          select '1'  
PROBLEM:            
IF (@intErrorCode <> 0) BEGIN      
PRINT @intErrorCode  
PRINT 'Unexpected error occurred!'            
    ROLLBACK TRAN            
   select '0'           
   --drop table #temp           
END

go

