    
    
    
--usp_getVisitorDetails      
CREATE PROCEDURE [dbo].[usp_getVisitorDetails]                  
(                  
 @Condition VARCHAR(MAX),                  
 @FromDate DATETIME,                  
 @ToDate  DATETIME                  
)                  
AS      
BEGIN                
 --DECLARE @Condition VARCHAR(MAX)  ='1=1'            
 --DECLARE @FromDate DATETIME='2021-05-12'              
 --DECLARE @ToDate  DATETIME ='2021-05-12'              
 DECLARE @QUERY VARCHAR(MAX)              
                   
 SET @QUERY='select v.id as VisitorID,   
 LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(a.TargetID)), CHAR(9), '' ''), CHAR(10), '' ''), CHAR(11), '' ''), CHAR(12), '' ''), CHAR(13), '' ''))) as TargetID,    
 -- LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(bm.name)), CHAR(9), '' ''), CHAR(10), '' ''), CHAR(11), '' ''), CHAR(12), '' ''), CHAR(13), '' ''))) as [Branch Name],    
 -- LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(cm.Name)), CHAR(9), '' ''), CHAR(10), '' ''), CHAR(11), '' ''), CHAR(12), '' ''), CHAR(13), '' ''))) as [Chain Name],     
 -- LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(citymaster.NAME)), CHAR(9), '' ''), CHAR(10), '' ''), CHAR(11), '' ''), CHAR(12), '' ''), CHAR(13), '' ''))) [City Name],          
 LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(ci.Name)), CHAR(9), '' ''), CHAR(10), '' ''), CHAR(11), '' ''), CHAR(12), '' ''), CHAR(13), '' ''))) as [Classification Name],     
 --LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(fm.Name)), CHAR(9), '' ''), CHAR(10), '' ''), CHAR(11), '' ''), CHAR(12), '' ''), CHAR(13), '' ''))) as [Format Name],     
-- LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(rm.Name)), CHAR(9), '' ''), CHAR(10), '' ''), CHAR(11), '' ''), CHAR(12), '' ''), CHAR(13), '' ''))) as [Region Name] ,    
 LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(a.TargetName)), CHAR(9), '' ''), CHAR(10), '' ''), CHAR(11), '' ''), CHAR(12), '' ''), CHAR(13), '' ''))) TargetName,    
 -- LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(statemaster.name)), CHAR(9), '' ''), CHAR(10), '' ''), CHAR(11), '' ''), CHAR(12), '' ''), CHAR(13), '' '')))as State,    
 -- LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(OE_OM_NAME)), CHAR(9), '' ''), CHAR(10), '' ''), CHAR(11), '' ''), CHAR(12), '' ''), CHAR(13), '' '')))as OE_OM_NAME,     
 -- LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(Merchandiser_Name)), CHAR(9), '' ''), CHAR(10), '' ''), CHAR(11), '' ''), CHAR(12), '' ''), CHAR(13), '' '')))as Merchandiser_Name,    
--  LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(Supervisor_Name)), CHAR(9), '' ''), CHAR(10), '' ''), CHAR(11), '' ''), CHAR(12), '' ''), CHAR(13), '' '')))as Supervisor_Name,    
-- LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(SO_Name)), CHAR(9), '' ''), CHAR(10), '' ''), CHAR(11), '' ''), CHAR(12), '' ''), CHAR(13), '' '')))as SO_Name,          
-- LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(Store_Code)), CHAR(9), '' ''), CHAR(10), '' ''), CHAR(11), '' ''), CHAR(12), '' ''), CHAR(13), '' '')))as Store_Code ,    
 LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(v.username)), CHAR(9), '' ''), CHAR(10), '' ''), CHAR(11), '' ''), CHAR(12), '' ''), CHAR(13), '' '')))  [User Name],     
 CONVERT(varchar(10),v.entrydate,102) [EntryDate],    
 LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(v.Type)), CHAR(9), '' ''), CHAR(10), '' ''), CHAR(11), '' ''), CHAR(12), '' ''), CHAR(13), '' '')))as Type,     
 LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(v.Name)), CHAR(9), '' ''), CHAR(10), '' ''), CHAR(11), '' ''), CHAR(12), '' ''), CHAR(13), '' ''))) as Name,    
 LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(v.Designation)), CHAR(9), '' ''), CHAR(10), '' ''), CHAR(11), '' ''), CHAR(12), '' ''), CHAR(13), '' ''))) as Designation,    
 LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(v.Remarks)), CHAR(9), '' ''), CHAR(10), '' ''), CHAR(11), '' ''), CHAR(12), '' ''), CHAR(13), '' ''))) as Remarks,    
 v.groomed as ''Promoter well groomed Y/N '' ,      
 v.maintained [Maintained well all categories],    
 v.aware [Aware about all the targets]      
 From                               
 VisitorData v                          
 inner join TargetMaster a on a.TargetID=v.TargetID             
 -- left join ChainMaster cm on a.ChainID = cm.ChainID            
 left join ClassificationMaster ci on a.ClassificationID = ci.ClassificationID            
-- left join FormatMaster fm on a.FormatID = fm.FormatID            
 -- left join RegionMaster rm on a.RegionID = rm.RegionID                   
 -- inner join branchmaster bm on bm.BranchID=a.BranchID   
 -- LEFT JOIN  citymaster ON citymaster.cityid=a.cityid   
 -- inner join statemaster on statemaster.StateID=a.StateID          
           
  WHERE '+@Condition+'                 
  AND Convert(varchar(10),v.EntryDate,120) >= '''+convert(varchar(10),@FromDate,120)+'''                   
  AND Convert(Varchar(10),v.EntryDate,120)<= '''+ convert(varchar(10),@ToDate,120) +''''       
      
                   
 --PRINT(@QUERY)                              
 EXEC(@QUERY)                  
END
go

