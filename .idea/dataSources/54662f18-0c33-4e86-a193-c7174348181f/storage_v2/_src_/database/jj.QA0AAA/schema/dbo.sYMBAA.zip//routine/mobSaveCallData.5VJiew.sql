  
CREATE PROC mobSaveCallData         
@sqlQuery varchar(max)        
AS Begin         
BEGIN TRY        
EXEC(@sqlQuery)        
SELECT 'True'        
END TRY        
BEGIN CATCH      
Select 'False'  
END CATCH        
END
go

