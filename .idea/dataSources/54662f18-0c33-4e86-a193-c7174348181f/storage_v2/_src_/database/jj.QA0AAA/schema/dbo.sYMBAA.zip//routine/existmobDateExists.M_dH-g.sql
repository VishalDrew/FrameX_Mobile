  
CREATE Procedure existmobDateExists  --'7/23/2014 12:00:00 AM','4','10042'                  
@EntryDate datetime,                    
@roleid int,              
@targetid int                  
As  
Begin                    
if  exists(Select * FROM ExitStore WHERE Convert(varchar(20), ExitTime,101)=@EntryDate and RoleID=@roleid and TragetID=@targetid)                    
 begin                    
  select 'True'                    
 END                    
ELSE                    
 Begin                    
  select 'False'                    
 END                    
END
go

