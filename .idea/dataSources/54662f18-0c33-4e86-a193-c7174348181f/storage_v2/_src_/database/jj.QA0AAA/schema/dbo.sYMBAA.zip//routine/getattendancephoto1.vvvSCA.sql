--use jj 

CREATE Proc getattendancephoto1 --'2017-04-22','2017-04-22','4'  ,''  
@fromdate date,    
@todate date,    
 @roleid int,  
 @condition nvarchar(max)    
AS Begin    
  
declare  @query nvarchar(max)  
set @query=  
'Select AD.username,AD.status,date,AD.username+''-''+Convert(varchar,date)+''-''+Convert(varchar,AD.status) as Photo from Attendancedetail AD    
inner join usermaster UM on UM.UserName=AD.username   
inner join citymaster on UM.CityID=citymaster.CityID  
Where date >= '''+cast (@fromdate as nvarchar(10)) +''' and date <='''+ CAST( @todate as nvarchar(10))+''' AND RoleID ='+ cast(@roleid as nvarchar(10)) + @condition;  
  
exec(@query)  
  
  
--Select AD.username,AD.status,date,AD.username+'-'+Convert(varchar,date)+'-'+Convert(varchar,AD.status) as Photo from Attendancedetail AD    
--inner join usermaster UM on UM.UserName=AD.username   
--inner join citymaster on UM.CityID=citymaster.CityID  
--Where date >= @fromdate and date <=@todate AND RoleID = @roleid + @condition  
  
  
    
END
go

