  
  
CREATE procedure usp_checkIDinMasterTable --'General_Question','''1'''  
@FormName nvarchar(200),  
@ID varchar(100)  
as  
begin  
  declare @strQUery nvarchar(max)  
  set @strQUery =('select * from '+@FormName+'Master where '+@FormName+'ID ='+@ID+'')  
  print(@strQUery)  
  exec(@strQUery)  
end  
  
--select * from General_QuestionMaster
go

