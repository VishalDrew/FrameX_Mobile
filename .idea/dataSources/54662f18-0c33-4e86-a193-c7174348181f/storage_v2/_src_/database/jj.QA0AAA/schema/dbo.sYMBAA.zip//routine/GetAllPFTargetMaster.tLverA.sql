CREATE Procedure [dbo].[GetAllPFTargetMaster]

AS
BEGIN
SELECT
    COLUMN_NAME,tc.CONSTRAINT_NAME,tc.CONSTRAINT_TYPE,
    TableName =
      CASE tc.CONSTRAINT_TYPE
         WHEN 'FOREIGN KEY' THEN Replace(tc.CONSTRAINT_NAME,'FK_TargetMaster_','')
         WHEN 'PRIMARY KEY' THEN 'TargetMaster'        
         ELSE 'True'
      END 
FROM
    INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc
    INNER JOIN
    INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE ccu ON tc.CONSTRAINT_NAME = ccu.Constraint_name
WHERE
    (
        tc.CONSTRAINT_TYPE = 'Primary Key'
        OR
        tc.CONSTRAINT_TYPE = 'Foreign Key'
    )
    AND
    tc.TABLE_NAME = 'TargetMaster'   
    
    order by TableName

END

go

