              
CREATE Procedure [dbo].[Usp_GetStatusForCycleRequestforApproval]                      
  @status nvarchar(300),      
  @ID int                 
As                      
Begin      
Select * FROM CycleCloseMaster WHERE Status!=@status and ID=@ID                  
--if  exists(Select * FROM CycleCloseMaster WHERE Status!=@status and ID=@ID)                      
-- begin                      
--  select 'True'                      
-- END                      
--ELSE                      
-- Begin                      
--  select 'False'                      
-- END                      
END             
            
            
--select * from CycleCloseMaster        
--Select * FROM CycleCloseMaster WHERE Status!='Approved'
go

