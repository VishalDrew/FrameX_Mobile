CREATE function [dbo].[fnGetFieldStatus]       
(@enumtype varchar(500),@COLUMN_NAME varchar(500))      
returns varchar(10)      
begin      
declare  @output varchar(200)      

if exists(SELECT * FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE 
			WHERE OBJECTPROPERTY(OBJECT_ID(constraint_name), 'IsforeignKey') = 1
			AND table_name = @enumtype and COLUMN_NAME=@COLUMN_NAME)
Begin
		select @output = '1'
End
else
	if exists(SELECT * FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE 
			WHERE OBJECTPROPERTY(OBJECT_ID(constraint_name), 'IsPrimaryKey') = 1
			AND table_name = @enumtype and COLUMN_NAME=@COLUMN_NAME)
	Begin
			select @output = '2'
	End
	else
	Begin
			select @output = '0'
	End
return @output   
end
go

