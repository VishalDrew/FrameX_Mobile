CREATE procedure usp_GetPictureGalleryFormName  
as  
begin  
 select ReportID, Name, FormID from ReportBasicMaster where isPictureGallery=1  
end

go

