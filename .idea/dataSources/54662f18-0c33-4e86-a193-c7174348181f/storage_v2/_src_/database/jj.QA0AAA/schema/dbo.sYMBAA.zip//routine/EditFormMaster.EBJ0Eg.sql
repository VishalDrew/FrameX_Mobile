CREATE PROC [dbo].[EditFormMaster]  --'CityMaster',''
@enumtype varchar(100),
@enumid varchar(100),
@XML xml
As 

 declare @intErrorCode  Int

 Set Nocount off             
 Begin Transaction  


begin

	declare @columnName varchar(100),@query varchar(8000),@cols nVARCHAR(MAX), @count int

		select @cols= COALESCE(@cols + ', ' + nodeval + ''
		,'' +  nodeval + '') from 
		(
			SELECT nodeval = C.value('local-name(.)', 'varchar(100)') +'='''+ C.value('(.)[1]', 'varchar(500)') +''''
			FROM @XML.nodes('//row/*') AS T(C)
		)aa

 SELECT @intErrorCode = @@ERROR          
 IF (@intErrorCode <> 0) GOTO PROBLEM 

		SELECT @columnName = column_name
		FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
		WHERE OBJECTPROPERTY(OBJECT_ID(constraint_name), 'IsPrimaryKey') = 1
		AND table_name = @enumtype

 SELECT @intErrorCode = @@ERROR          
 IF (@intErrorCode <> 0) GOTO PROBLEM 

				--Check Record is Exist or Not


				declare @temp table (Name varchar(100))

				insert into @temp
				exec('select Name from '+ @enumtype +' where '+ @columnName +' <> '+ @enumid)


 SELECT @intErrorCode = @@ERROR          
 IF (@intErrorCode <> 0) GOTO PROBLEM 

				--select * from @temp

				select @count=count(*) from @temp enum
				inner join 
				(SELECT  
					   Tbl.Col.value('Name[1]', 'varchar(500)') Name  
				FROM   @xml.nodes('//row') Tbl(Col)
				)aa
				on aa.Name=enum.Name

 SELECT @intErrorCode = @@ERROR          
 IF (@intErrorCode <> 0) GOTO PROBLEM 

if(@count=0)
begin
		exec('update '+@enumtype+' set '+ @cols +',ModifiedDate=getdate() where  '+ @columnName +' = '+ @enumid)
 SELECT @intErrorCode = @@ERROR          
 IF (@intErrorCode <> 0) GOTO PROBLEM 
		Select '1'
End
else
begin
		Select '2'
End
End

COMMIT TRAN          
          
PROBLEM:          
IF (@intErrorCode <> 0) BEGIN    
PRINT @intErrorCode
PRINT 'Unexpected error occurred!'          
    ROLLBACK TRAN          
   select '0'         
   --drop table #temp         
END
go

