CREATE Procedure [dbo].[FormExists]-- '72'            
           
@FormID int         
As            
Begin            
if  exists(select * from FormMaster where FormID=@FormID and FormStatus=1)            
 begin            
  select 'True'            
 END            
ELSE            
 Begin            
  select 'False'            
 END            
END
go

