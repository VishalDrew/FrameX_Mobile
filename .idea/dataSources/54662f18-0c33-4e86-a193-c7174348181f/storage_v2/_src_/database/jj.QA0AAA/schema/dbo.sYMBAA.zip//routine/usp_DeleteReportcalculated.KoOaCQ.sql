create procedure usp_DeleteReportcalculated  
@ReportID int    
as    
begin    
delete from ReportCalculate where CalculateReportID=@ReportID    
end
go

