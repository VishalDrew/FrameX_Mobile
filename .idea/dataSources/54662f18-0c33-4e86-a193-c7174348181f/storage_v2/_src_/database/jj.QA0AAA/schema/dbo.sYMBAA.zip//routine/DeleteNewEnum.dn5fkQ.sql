CREATE PROC [dbo].[DeleteNewEnum]  --'AgeMaster'            
@enumtype varchar(100)            
            
As begin        
begin try         
 declare @intErrorCode  Int,@count int,@query varchar(8000)            
 declare @temp table (Name varchar(100))            
begin  
 insert into @temp exec('select name from '+@enumtype)  
 select @count = COUNT(*) FROM @temp  
if (@count = 0)  
begin  
   
  if exists ( SELECT * FROM RoleAccessManagement WHERE SubsectionID = (select SubsectionID from SubSectionMaster where SubSectionName=SUBSTRING(@enumType,1,len(@enumType)-6) + ' Master'))            
   begin  
   select '-1'  
   return;  
   End  
  Else  
  Begin  
   if exists (select * from SubSectionMaster where SubSectionName=SUBSTRING(@enumType,1,len(@enumType)-6) + ' Master')            
    begin            
     delete from SubSectionMaster where SubSectionName = SUBSTRING(@enumType,1,len(@enumType)-6) + ' Master'                
       
     delete from EnumMeta where EnumName=@enumtype  
     set @query='drop table '+@enumtype  
 print @query  
 exec (@query)  
       
    End           
  End                
End           
else             
 begin            
   select '2'            
 End            
End            
select '1'            
end try              
begin catch              
Select '0'              
end catch              
End
go

