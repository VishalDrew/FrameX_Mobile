 CREATE procedure usp_getQuestionsModeforDateentry --'Employee_Questionform'      
 @FormName nvarchar(300)      
 as      
 begin      
 declare @strQuery  nvarchar(max)      
 set @strQuery= 'select '+@FormName+'ID, QuestionMode  from '+@FormName+'Master'      
 exec (@strQuery)      
 end
 go

