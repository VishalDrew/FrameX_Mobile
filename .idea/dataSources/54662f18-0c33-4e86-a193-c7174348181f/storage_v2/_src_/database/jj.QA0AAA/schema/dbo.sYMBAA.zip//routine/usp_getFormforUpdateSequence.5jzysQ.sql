create procedure usp_getFormforUpdateSequence
as
begin
select FormID as 'ID', Name,FormSequence as 'Sequence' from FormMaster
end
go

