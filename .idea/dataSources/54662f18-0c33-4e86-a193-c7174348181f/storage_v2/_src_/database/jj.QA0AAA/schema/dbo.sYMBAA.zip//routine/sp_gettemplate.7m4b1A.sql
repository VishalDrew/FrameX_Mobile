
CREATE Proc sp_gettemplate   
AS Begin  
Select * From Templatemaster Where Status =0   ORDER BY Type,Name
End
go

