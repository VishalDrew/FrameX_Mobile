  -- [GetSpecificEnumData] 'CallRegister',''
CREATE PROC [dbo].[GetSpecificEnumData]  --'FormMaster',''                            
@enumtype varchar(100),                            
@enumid varchar(100)                            
As                             
BEGIN      
  DECLARE @columnName varchar(100),@query varchar(100)                            
 DECLARE @intErrorCode INT                    
       
 BEGIN TRAN                    
  if(@enumid = '')                            
   BEGIN                         
    --PRINT 'CASE:1'         
    SELECT @columnName = column_name        
    FROM INFORMATION_SCHEMA.COLUMNS      
    WHERE Right(column_name,4) = 'Name'                            
    AND table_name = @enumtype                          
      
    SELECT @intErrorCode = @@ERROR      
    IF (@intErrorCode <> 0) GOTO PROBLEM                    
     IF (@enumtype='FormMaster')                
     BEGIN                
      --PRINT 'CASE:2'      
      --exec('Select * from '+ @enumtype +' where Name<>''Picture'' and FormStatus=1 order by '+ @columnName + ' asc')                      
      exec('Select * from '+ @enumtype +' where  FormStatus=1 order by '+ @columnName + ' asc')                      
     END      
     ELSE IF (@enumtype='Activity')                
     BEGIN                
      --PRINT 'CASE:2'      
      --exec('Select * from '+ @enumtype +' where Name<>''Picture'' and FormStatus=1 order by '+ @columnName + ' asc')                      
      exec('Select PictureID, Activity, Sequence, Status, CreatedBy, ModifiedBy, CreatedDate, ModifiedDate from PictureMaster where  Status=1 order by Sequence ASC')                      
     END      
     ELSE IF (@enumtype='User')                
     BEGIN                
      --PRINT 'CASE:2'      
      --exec('Select * from '+ @enumtype +' where Name<>''Picture'' and FormStatus=1 order by '+ @columnName + ' asc')                      
      exec('SELECT USERID, UserName, Sequence, Status, CreatedBy, ModifiedBy, CreatedDate, ModifiedDate FROM dbo.UserMaster WHERE RoleID=''4'' AND Status=1  ORDER BY Sequence DESC')      
     END   
   ELSE IF (@enumtype='CallRegister')                
     BEGIN                
      PRINT 'CASE:2'      
      --exec('Select * from '+ @enumtype +' where Name<>''Picture'' and FormStatus=1 order by '+ @columnName + ' asc')                      
      exec('select EnumName from EnumMeta where EnumName in (''CityMaster'',''ClassificationMaster'')')      
     END   
    ELSE                
     BEGIN                
      --PRINT 'CASE:3'      
      --exec('Select * from '+ @enumtype +'  order by '+ @columnName + ' asc')                  
      exec('Select * from '+ @enumtype +' order by '+ @columnName + ' asc')                     
      END                
                    
    SELECT @intErrorCode = @@ERROR                    
    IF (@intErrorCode <> 0) GOTO PROBLEM                    
     --PRINT 'CASE:4'      
     exec('Select Validation from EnumMeta where EnumName='''+@enumtype+'''')      
                    
    SELECT @intErrorCode = @@ERROR      
    IF (@intErrorCode <> 0) GOTO PROBLEM                    
                    
   END      
  ELSE      
   BEGIN      
    --PRINT 'CASE:5'      
    SELECT @columnName = column_name      
    FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE      
    WHERE OBJECTPROPERTY(OBJECT_ID(constraint_name), 'IsPrimaryKey') = 1      
    AND table_name = @enumtype      
      
    SELECT @intErrorCode = @@ERROR      
    IF (@intErrorCode <> 0) GOTO PROBLEM      
     --PRINT 'CASE:6'      
     exec('Select * from '+ @enumtype +' where '+ @columnName +' = '+ @enumid +' order by Name asc')      
      
    SELECT @intErrorCode = @@ERROR      
    IF (@intErrorCode <> 0) GOTO PROBLEM      
     --PRINT 'CASE:7'      
     exec('Select Validation from EnumMeta where EnumName='''+@enumtype+'''')      
      
    SELECT @intErrorCode = @@ERROR      
    IF (@intErrorCode <> 0) GOTO PROBLEM      
          
   END                            
END      
 COMMIT TRAN      
 PROBLEM:      
  IF (@intErrorCode <> 0)      
   BEGIN      
    Select 'Error'      
    ROLLBACK TRAN                    
   END      
----OLD DATA--21_January_2017--START      
----CREATE PROC [dbo].[GetSpecificEnumData]  --'FormMaster',''                          
----@enumtype varchar(100),                          
----@enumid varchar(100)                          
----As                  
----begin                          
                          
----declare @columnName varchar(100),@query varchar(100)                          
----DECLARE @intErrorCode INT                  
----BEGIN TRAN                  
----if(@enumid = '')                          
---- begin                          
----  SELECT @columnName = column_name                          
----  FROM INFORMATION_SCHEMA.COLUMNS                          
----  WHERE Right(column_name,4) = 'Name'                          
----  AND table_name = @enumtype                        
                      
----SELECT @intErrorCode = @@ERROR                  
----IF (@intErrorCode <> 0) GOTO PROBLEM                  
----  IF (@enumtype='FormMaster')              
---- BEGIN              
---- --exec('Select * from '+ @enumtype +' where Name<>''Picture'' and FormStatus=1 order by '+ @columnName + ' asc')                    
---- exec('Select * from '+ @enumtype +' where  FormStatus=1 order by '+ @columnName + ' asc')                    
---- END              
----   ELSE              
---- BEGIN              
---- --exec('Select * from '+ @enumtype +'  order by '+ @columnName + ' asc')                
---- exec('Select * from '+ @enumtype +' order by '+ @columnName + ' asc')                   
---- END              
                
                  
----SELECT @intErrorCode = @@ERROR                  
----IF (@intErrorCode <> 0) GOTO PROBLEM                  
                       
----  exec('Select Validation from EnumMeta where EnumName='''+@enumtype+'''')                         
                  
----SELECT @intErrorCode = @@ERROR                  
----IF (@intErrorCode <> 0) GOTO PROBLEM                  
                  
---- END                          
----ELSE                           
---- begin                           
----  SELECT @columnName = column_name                          
----  FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE                          
----  WHERE OBJECTPROPERTY(OBJECT_ID(constraint_name), 'IsPrimaryKey') = 1                          
----  AND table_name = @enumtype                          
                    
----SELECT @intErrorCode = @@ERROR                  
----IF (@intErrorCode <> 0) GOTO PROBLEM                  
                          
----  exec('Select * from '+ @enumtype +' where '+ @columnName +' = '+ @enumid +' order by Name asc')                        
                  
----SELECT @intErrorCode = @@ERROR                  
----IF (@intErrorCode <> 0) GOTO PROBLEM                  
                  
----   exec('Select Validation from EnumMeta where EnumName='''+@enumtype+'''')                          
                  
----SELECT @intErrorCode = @@ERROR                  
----IF (@intErrorCode <> 0) GOTO PROBLEM                  
                  
---- END                          
----end                   
                  
----COMMIT TRAN                  
                  
----PROBLEM:                  
----IF (@intErrorCode <> 0)                   
----BEGIN                  
---- Select 'Error'                  
----    ROLLBACK TRAN                  
----END    
----OLD DATA--21_January_2017--END
go

