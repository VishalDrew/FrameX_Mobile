     
        
CREATE procedure usp_FormfielddetailsForDumpReportgggg -- 'Stock_Status',' where SM.EntryDate  between ''2014.11.27'' and ''2014.11.28'' and SM.RoleID in(10) AND ( TM.CityID =''23'' ) AND ( TM.ClassificationID =''3'' )'           
@FormName varchar(300),    
 @Condition varchar(max)      
as        
begin        
declare @value varchar(300)        
declare @formmaster varchar(300)        
set @formmaster = @FormName +'Master'      
declare @stockentry varchar(300)      
set @stockentry=@FormName+'StockEntry'       
set @value=(select FieldName from FormFieldDetail where FormID in(        
select FormID from FormMaster where Name=@FormName) and ForPM=1 and ForDEO=1)        
        
EXEC('select distinct '+@value+' as FieldValue from ' +@formmaster +' fm inner join '+@stockentry+' ss      
on fm.'+@FormName+'ID= ss.'+@FormName+'ID     
inner join StockEntryMain SM    
on SM.StockEntryID = ss.StockEntryID    
inner join TargetMaster TM on TM.TargetID = SM.TargetID '+@Condition+''    
    
    
)        
         
        
    
end       
    
--print(    
--'select  distinct FM.Question from Fitter_Claim_Received_from_FitterMaster FM inner join Fitter_Claim_Received_from_FitterStockEntry FC    
--on FC.Fitter_Claim_Received_from_FitterID = FM.Fitter_Claim_Received_from_FitterID    
--inner join StockEntryMain SM    
--on SM.StockEntryID = FC.StockEntryID    
--where CONVERT(varchar(10),SM.EntryDate,102) between ''2014.11.27'' and ''2014.11.28'' and RoleID=''10''')    
    
--select * from Fitter_Claim_Received_from_FitterStockEntry    
    
--select * from StockEntryMain
go

