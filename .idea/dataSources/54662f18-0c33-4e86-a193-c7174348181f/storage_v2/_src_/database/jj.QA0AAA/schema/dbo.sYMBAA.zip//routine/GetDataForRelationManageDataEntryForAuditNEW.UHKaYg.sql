CREATE Procedure GetDataForRelationManageDataEntryForAuditNEW-- 23004, '  TargetID=23004 and StockEntryID = ''Merc_23004_201409051154551494'' '                                
@TargetID varchar(100),    
@Condition nvarchar(500)                                
                  
As                                
BEgin                                
                  
   
     
   exec('select PM.PictureID,PM.Activity,PS.Photo from PictureMaster PM  
   Inner join PictureRelation PR  
   on PM.PictureID=PR.PictureID  
   inner join PictureStockEntry PS  
   on PS.PictureID = PM.PictureID where PM.Status=''TRUE'' and PS.PictureID in(select Distinct PictureID from TargetAuditQuestionRelation where TargetID='+@TargetID+') and '+ @Condition+'')  
     
                             
                              
--  Select FieldName,ControlType,[Required],                        
--  FormLayout,DataType  From FormMaster                           
--  inner join FormFieldDetail on FormMaster.FormID=FormFieldDetail.FormID                            
--Where Name=@TableName and ForDEO='True' and ForPM = 'False'  --and FieldName <> @TableName+'Name'           
          
--AnswerByPM            
          
                             
  Select FieldName,ControlType,[Required],                        
  FormLayout,DataType,AnswerByPM  From FormMaster                           
  inner join FormFieldDetail on FormMaster.FormID=FormFieldDetail.FormID                            
Where Name='Picture' and ForDEO='True' and ForPM = 'False'  --and FieldName <> @TableName+'Name'           
                         
                      
                      
select FieldName,FormFieldOption.FormFieldOption from FormFieldOption inner join                        
FormFieldDetail on FormFieldDetail.FormFieldID=FormFieldOption.FormFieldID                      
inner join FormMaster on FormMaster.FormID=FormFieldOption.FormID                        
where FormMaster.Name='Picture'                      
                      
END
go

