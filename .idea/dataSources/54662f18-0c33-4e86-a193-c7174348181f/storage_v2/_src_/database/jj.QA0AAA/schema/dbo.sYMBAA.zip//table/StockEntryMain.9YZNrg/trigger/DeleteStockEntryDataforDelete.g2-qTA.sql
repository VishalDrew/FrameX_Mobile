CREATE TRIGGER [dbo].[DeleteStockEntryDataforDelete]
   ON  dbo.StockEntryMain 
   AFTER DELETE
AS 
BEGIN
	
	declare @StockEntryID nvarchar(50),@count int, @formName varchar(500)
	
	select @StockEntryID= StockEntryID from deleted
	
	select @count = count(*) from FormMaster
	
	while (@count>0)
	begin
	
		SELECT @formName = Name FROM
			(SELECT ROW_NUMBER() OVER (ORDER BY FormID) AS Row, Name FROM FormMaster) AS Form
		WHERE Row = @count

	 	exec('Delete from '+@formName+'StockEntry where StockEntryID = ''' + @StockEntryID + '''')
	 	
	 	--print 'Delete from '+@formName+'StockEntry where StockEntryID = ''' + @StockEntryID + ''''
	 	
	 	set @count=@count -1
	 	
	End
END
go

