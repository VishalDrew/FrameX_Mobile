      
      
CREATE procedure usp_FormfielddetailsForDumpReportbackup-- 'Fitter_Claim_Received_from_Fitter'      
@FormName varchar(300)      
as      
begin      
declare @value varchar(300)      
declare @formmaster varchar(300)      
set @formmaster = @FormName +'Master'      
set @value=(select FieldName from FormFieldDetail where FormID in(      
select FormID from FormMaster where Name=@FormName) and ForPM=1 and ForDEO=1)      
      
exec('select '+@value+' as FieldValue from ' +@formmaster)      
       
      
      
end
go

