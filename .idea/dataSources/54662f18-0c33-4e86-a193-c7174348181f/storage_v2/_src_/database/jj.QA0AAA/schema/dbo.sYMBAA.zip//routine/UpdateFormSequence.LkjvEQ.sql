CREATE Procedure UpdateFormSequence-- '72'              
             
@strQuery nvarchar(max)           
As              
Begin              
     declare @Query nvarchar(max)    
     set @Query=@strQuery    
     exec(@Query)        
END
go

