CREATE Procedure UpdateRecord      
      
@TableName nvarchar(50),      
@query  nvarchar(4000),  
@FormDataID varchar(50)  
      
As      
Begin      
      
declare @Error int,@formid nvarchar(50)      
    
begin tran      
Exec (@query)      
    
  --set @formid = @TableName  
select @formid = FormID from FormMaster where Name = SUBSTRING(@TableName,1,LEN(@TableName) - 6)    
    
if(@TableName is not null)    
delete from FormFieldOptionByPM where FormDataID=@FormDataID    
Select  @Error =@@ERROR      
if(@Error <> 0) goto PROBLEM      
    
select @formid     
commit tran      
PROBLEM:     
BEGIN     
select 'E'         
ROLLBACK TRAN       
      
END      
      
END
go

