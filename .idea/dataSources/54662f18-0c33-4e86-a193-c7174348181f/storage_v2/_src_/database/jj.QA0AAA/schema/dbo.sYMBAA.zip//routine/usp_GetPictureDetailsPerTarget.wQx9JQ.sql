  
CREATE procedure usp_GetPictureDetailsPerTarget --'23004'  
@TargetID int  
AS  
BEGIN  
Declare @PictureStockEntry varchar(200)  
Declare @PictureForm varchar(200)  
Declare @PictureMaster varchar(200)  
Set @PictureForm =(select Name from FormMaster where FormID = (select FormID from FormFieldDetail where ForPM=0 and ForDEO=1 and ForQDEO=1 and ControlType='FileUpload'))  
set @PictureStockEntry=@PictureForm+'StockEntry'  
set @PictureMaster=@PictureForm+'Master'  
Declare @ColumnName varchar(200)  
set @ColumnName=(select FieldName from FormFieldDetail where FormID=(select FormID from FormFieldDetail where ForPM=0 and ForDEO=1 and ForQDEO=1 and ControlType='FileUpload')  
and ForPM=1 and ForDEO=1 and ForQDEO=0)  
  
Exec('  
select Distinct PM.'+@PictureForm+'ID as PictureID,PM.'+@ColumnName+' as PictureName from '+@PictureForm+'StockEntry PS  
inner join StockEntryMain SM  
on SM.StockEntryID= PS.StockEntryID  
inner join '+@PictureForm+'Master PM  
on PM.'+@PictureForm+'ID = PS.'+@PictureForm+'ID  
inner join  TargetMaster TM  
on TM.TargetID= SM.TargetID  
where TM.TargetID='+@TargetID+'')  
  
  
END
go

