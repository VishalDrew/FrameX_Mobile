CREATE Proc [dbo].[SelectEnumDB_ExportForUpdate] --'UserMaster'            
@enumtype varchar(500)            
as            
            
Begin            
    
  if (@enumtype='UserMaster')      
  BEGIN      
         
 declare @col varchar(max)      
      
 select @col=coalesce(@col+', ','')+ a.COLUMN_NAME from (select  distinct COLUMN_NAME from INFORMATION_SCHEMA.COLUMNS where TABLE_NAME='UserMaster' and ORDINAL_POSITION>10)a      
 if @col<>''      
  BEGIN      
      
 exec('select UM.UserID,UM.UserName,UM.Password,CONVERT(varchar,UM.RoleID)+''|''+RM.Name as Role,'+@col+'  from UserMaster UM Inner join RoleMaster RM on UM.RoleID=RM.RoleID')      
 END     
  else    
 BEGIN    
  exec('select UM.UserID,UM.UserName,UM.Password,CONVERT(varchar,UM.RoleID)+''|''+RM.Name as Role  from UserMaster UM Inner join RoleMaster RM on UM.RoleID=RM.RoleID')      
 END     
END       
      
End
go

