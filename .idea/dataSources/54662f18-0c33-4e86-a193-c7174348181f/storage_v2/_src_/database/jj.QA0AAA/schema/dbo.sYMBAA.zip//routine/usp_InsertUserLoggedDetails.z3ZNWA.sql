CREATE procedure usp_InsertUserLoggedDetails    
@UserName varchar(300),    
@LoggedDate datetime    
as
begin    
BEGIN TRY    
    
Insert into UserTracker(UserName,LoggedDate)    
values(@UserName,@LoggedDate)    
select '1'    
END TRY    
BEGIN CATCH    
select '0'    
END CATCH    
    
end
go

