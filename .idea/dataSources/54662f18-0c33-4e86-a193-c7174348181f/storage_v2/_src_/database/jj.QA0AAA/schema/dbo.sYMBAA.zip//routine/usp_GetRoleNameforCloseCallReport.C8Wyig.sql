CREATE PROCEDURE usp_GetRoleNameforCloseCallReport      
AS      
BEGIN      
 SELECT * FROM dbo.RoleMaster      
 WHERE RoleID IN ('4','5')  
 --Name LIKE '%Merchandiser%'    
 --OR  Name LIKE '%Supervisor%'    
  --WHERE Name != 'Admin'      
  --AND  Name NOT LIKE '%Manager%'      
END 

go

