CREATE Procedure [dbo].[RptGetAllFormFieldDetail] --'5'                        
@FormID int      
As                        
Begin                        
Select FormFieldID,FieldName               
FRom FormFieldDetail                       
inner join FormMaster on FormMaster.FormID=FormFieldDetail.FormID                       
Where UniqueField='1' and ForPM='1' and FormMaster.FormID=@FormID order by FieldName             
            
Select FormFieldID,FieldName               
FRom FormFieldDetail                       
inner join FormMaster on FormMaster.FormID=FormFieldDetail.FormID                       
--Where ForDEO='1' and ForPM='0' and forQDEO=1 and FormMaster.FormID=@FormID    
Where ForDEO='1' and ForPM='0' and  FormMaster.FormID=@FormID         
Union ALL    
Select FormFieldID,FieldName               
FRom FormFieldDetail                       
inner join FormMaster on FormMaster.FormID=FormFieldDetail.FormID                       
Where ForDEO='0' and ForPM='1' and forQDEO=1 and FormMaster.FormID=@FormID           
    
      
Select fieldname as 'column_name' from FormFieldDetail        
where formid = @FormID AND datatype = 'int' AND Forpm = 0 and fordeo = 1 and forQDEO=1    
Union ALL    
Select fieldname as 'column_name' from FormFieldDetail        
where formid = @FormID AND datatype = 'Varchar(500)' AND Forpm = 1 and fordeo = 0 and forQDEO=1      
      
      
      
END
go

