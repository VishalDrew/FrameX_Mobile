
CREATE Procedure GetDataForRelationManageDataEntry  --'Implementation','  ChainID = 3 and RoleGroupID in (2) and   CityID = 80 and RoleGroupID in (2) and StockEntryID = ''Supe_10078_201501291315312881'''                            
@TableName nvarchar(100),                            
@Condition nvarchar(500)                            
              
As                            
BEgin                            
              
              
Declare @ColumName nvarchar(100),                            
        @ColumID nvarchar(100),                             
        @RelationTableName nvarchar(100),                            
        @MasterTableName nvarchar(100),              
        @StockEntryTableName nvarchar(100)              
                                    
        --Set @ColumName =@TableName+'Name'                            
        Set @ColumID =@TableName+'ID'                            
        Set @RelationTableName =@TableName+'Relation'                            
        Set @MasterTableName =@TableName+'Master'                            
        Set @StockEntryTableName =@TableName+'StockEntry'                            
                    
DECLARE @cols nVARCHAR(MAX)                    
                    
--select @cols= COALESCE(@cols + ', ' + FieldName + '','' +  FieldName + '') from FormFieldDetail inner join                     
--FormMaster on FormMaster.FormID=FormFieldDetail.FormID                    
--where FormMaster.Name=@TableName                    
--and ForDEO='True' --and ForPM='True'       
      
select @cols= COALESCE(@cols + ',' + FieldName + '','' +  FieldName + '') from FormFieldDetail inner join                     
FormMaster on FormMaster.FormID=FormFieldDetail.FormID                    
where FormMaster.Name=@TableName                    
and ForDEO='True'                   
        
if (@cols is null)          
begin          
return          
end          
else          
begin                    
          
                  
print 'Select m.'+@ColumID+','+@cols+' from '+@MasterTableName+' m               
   inner join '+@RelationTableName+' r on r.'+@ColumID+'=m.'+@ColumID+'               
   inner join '+@StockEntryTableName+' s on s.'+@ColumID+'=m.'+@ColumID+'               
   Where m.status=''true'' and '+@Condition +' order by m.Sequence'--+@ColumName              
EXEC('Select m.'+@ColumID+','+@cols+' from '+@MasterTableName+' m               
   inner join '+@RelationTableName+' r on r.'+@ColumID+'=m.'+@ColumID+'               
   inner join '+@StockEntryTableName+' s on s.'+@ColumID+'=m.'+@ColumID+'               
   Where m.status=''true'' and '+@Condition +' order by m.Sequence')                            
                         
                          
--  Select FieldName,ControlType,[Required],                    
--  FormLayout,DataType  From FormMaster                       
--  inner join FormFieldDetail on FormMaster.FormID=FormFieldDetail.FormID                        
--Where Name=@TableName and ForDEO='True' and ForPM = 'False'  --and FieldName <> @TableName+'Name'       
      
--AnswerByPM        
      
                         
  Select FieldName,ControlType,[Required],                    
  FormLayout,DataType,AnswerByPM  From FormMaster                       
  inner join FormFieldDetail on FormMaster.FormID=FormFieldDetail.FormID                        
Where Name=@TableName and ForDEO='True' and ForPM = 'False'  --and FieldName <> @TableName+'Name'       
                     
                  
                  
select FieldName,FormFieldOption.FormFieldOption from FormFieldOption inner join                    
FormFieldDetail on FormFieldDetail.FormFieldID=FormFieldOption.FormFieldID                  
inner join FormMaster on FormMaster.FormID=FormFieldOption.FormID                    
where FormMaster.Name=@TableName                  
                  
END         
End
go

