CREATE proc [dbo].[InsertEnumField] --'UserMaster', 'LastName','','ddl','sd','sumit',''      
@enumtype varchar(500),            
@FieldName varchar(500),            
@FieldType varchar(50),                 
@ControlType varchar(500),              
@Validation varchar(500),            
@CreatedBy varchar(500),      
@EnumName varchar(100) = null,      
@Sequence int = 0     
--,            
--@res varchar(50) output,             
--@Sequence int        
as                
 declare @intErrorCode Int,@Query varchar(MAX),@FK varchar(2000) = '',@columnName varchar(100),@datatype varchar(100)            
 Set Nocount off                  
 Begin Transaction              
            
Begin        
      
if(@EnumName <> '')      
BEGIN      
  SELECT @columnName = column_name      
  FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE      
  WHERE OBJECTPROPERTY(OBJECT_ID(constraint_name), 'IsPrimaryKey') = 1      
  AND table_name = @EnumName      
        
     SELECT @intErrorCode = @@ERROR              
     IF (@intErrorCode <> 0) GOTO PROBLEM         
           
  set @FK = 'CONSTRAINT FK_' + @enumtype + '_'+@EnumName+'  FOREIGN KEY (' + @columnName + ') REFERENCES ' + @EnumName + '(' + @columnName + ')  '      
        
  SELECT @intErrorCode = @@ERROR              
     IF (@intErrorCode <> 0) GOTO PROBLEM         
           
  set @FieldName = @columnName      
        
  SELECT @intErrorCode = @@ERROR              
     IF (@intErrorCode <> 0) GOTO PROBLEM         
           
     select @datatype = DATA_TYPE from INFORMATION_SCHEMA.COLUMNS where COLUMN_NAME=@columnName and TABLE_NAME=@EnumName      
           
     if(@datatype = 'varchar')      
     begin      
  select @datatype = @datatype +'('+ CHARACTER_MAXIMUM_LENGTH + ')' from INFORMATION_SCHEMA.COLUMNS where COLUMN_NAME=@columnName and TABLE_NAME=@EnumName      
     End      
     set @FieldType = @datatype      
END      
      
          
if not exists (select column_name FROM INFORMATION_SCHEMA.COLUMNS where TABLE_NAME = @enumtype and COLUMN_NAME=@FieldName)            
 begin            
   --select * from EmployeeMaster            
    set @Query = 'ALTER TABLE ' + @enumtype + ' add ' + @FieldName +' ' + @FieldType  + ' NULL ' + @FK      
     SELECT @intErrorCode = @@ERROR              
     IF (@intErrorCode <> 0) GOTO PROBLEM             
   print @Query            
   exec (@Query)        
             
    SELECT @intErrorCode = @@ERROR              
     IF (@intErrorCode <> 0) GOTO PROBLEM         
                      
  --insert into HeadingFieldMapping values(@HeadingID,@FieldName,@FieldName,@Sequence)            
  --  SELECT @intErrorCode = @@ERROR              
  --   IF (@intErrorCode <> 0) GOTO PROBLEM       
                 
  insert into EnumFieldControlInfo values(@enumtype,@ControlType,@FieldName,@Validation,'0',@Sequence)            
    SELECT @intErrorCode = @@ERROR              
     IF (@intErrorCode <> 0) GOTO PROBLEM         
               
  select '1'        
 End            
 Else            
 begin            
  select '-1'            
 End            
End                
COMMIT TRAN                    
PROBLEM:              
IF (@intErrorCode <> 0) BEGIN              
PRINT 'Unexpected error occurred!'              
    ROLLBACK TRAN              
   select '0'      
        
END
go

