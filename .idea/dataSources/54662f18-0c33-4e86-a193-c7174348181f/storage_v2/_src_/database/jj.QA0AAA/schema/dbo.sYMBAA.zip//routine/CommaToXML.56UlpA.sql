CREATE FUNCTION dbo.CommaToXML ( @strString varchar(4000))  
  
RETURNS  @Result TABLE(Value varchar(500))  
AS  
BEGIN  
      DECLARE @x XML   
      SELECT @x = CAST('<A>'+ REPLACE(@strString,',','</A><A>')+ '</A>' AS XML)  
  
      INSERT INTO @Result              
      SELECT t.value('.', 'varchar(500)') AS inVal  
      FROM @x.nodes('/A') AS x(t)  
    RETURN  
END
go

