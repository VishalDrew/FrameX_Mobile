create procedure usp_getpictureformname  
as  
begin  
select * from FormMaster where Name='Picture'  
end
go

