--[ReportCalculationTestLastCall]   '1','2023-07-01','2023-07-15'  ,'  and RoleId = 4 ' 
CREATE Procedure [dbo].[ReportCalculationTestLastCall]  --  '1','2015-01-27','2015-01-28'  ,'  and RoleId = 4 '                            
@ReportID int,                            
@FromDate datetime,                            
@ToDate datetime,                            
@filterQuery varchar(MAX)=' and 1 = 1 '                            
as    
begin                             
  SET nocount  ON                            
    DECLARE  @imax INT,                            
             @i    INT                            
    DECLARE  @Contact VARCHAR(100),                            
             @Company VARCHAR(50)                            
   DECLARE @MainTable nvarchar(60)                            
   DECLARE @Full_String nvarchar(4000)                            
   DECLARE @ColumName nvarchar(4000)                            
   DECLARE @RowLabel nvarchar(4000),@ColumnLabel nvarchar(4000),@FormNamne varchar(200),@ValueLabel varchar(200)                            
   DECLARE @CalculateQuery nvarchar(4000),@CalculateColumnName nvarchar(4000)                    
   DECLARE @Query nvarchar(MAX)                            
                               
   set @MainTable='a';                            
 select                     
  @RowLabel=RowLabel,                    
  @ColumnLabel=ColumnLabel,                    
  @ValueLabel=ValueLabel,                    
  @FormNamne=FormMaster.Name,                    
  @CalculateQuery=CalculateQuery,                    
  @CalculateColumnName=CalculateColumnName                  
  from ReportCalculate                            
 inner join FormMaster on ReportCalculate.FormID=FormMaster.FormID                            
 where CalculateReportID=@ReportID                            
                    
                    
 DECLARE  @CompanyInfo  TABLE(                            
     RowID       INT    IDENTITY ( 1 , 1 ),                            
     CompanyName VARCHAR(100),                            
     ContactName VARCHAR(50)                            
     )                            
 INSERT @CompanyInfo                            
  SELECT                                      
   COLUMN_NAME,COLUMN_NAME                            
  FROM                            
   INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc                            
   INNER JOIN                            
   INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE ccu ON tc.CONSTRAINT_NAME = ccu.Constraint_name                                      
  WHERE                                      
   (                                      
    tc.CONSTRAINT_TYPE = 'Foreign Key'                                      
   )                                      
   AND                                      
   tc.TABLE_NAME ='TargetMaster' and COLUMN_NAME in (select * from dbo.CommaToXML (@RowLabel))                            
    SET @imax = @@ROWCOUNT                                       
    SET @i = 1                                       
    WHILE (@i <= @imax)                                       
      BEGIN                                       
        SELECT @Contact = ContactName,                                       
               @Company = CompanyName                                       
        FROM   @CompanyInfo                                       
        WHERE  RowID = @i                                              
   set @ColumName=ISNULL(@ColumName,'') +',' +@Contact+'.Name as '''+REPLACE(@Contact,'ID',' Name') +'''';                                      
   set @Full_String=ISNULL(@Full_String,'') +  ' left join ' +  REPLACE(@Contact,'ID','Master') + ' ' +  @Contact +' on '+ @MainTable +'.'+ @Contact + ' = ' + @Contact +'.'+@Contact                                        
                                                        
         SET @i = @i + 1                                       
      END -- WHILE                               
DECLARE @List VARCHAR(1000)                            
 select @List = COALESCE(@List + ', ', ',') + 'a.' + value from dbo.CommaToXML (@RowLabel) where                             
     value not in (select CompanyName from @CompanyInfo) and value<>''                            
    --set @ColumName=  SUBSTRING(@ColumName,2,(LEN(@ColumName)))                                     
    set @ColumName=  REPLACE(@ColumName,'.*.*','')                                      
           Print @ColumName                            
           Print @List                            
   if(@List is not null)                          
   set @ColumName = ISNULL(@ColumName,'') + @List                       
   if(@ColumName is not null)                          
   Begin                       
  set @ColumName=  SUBSTRING(@ColumName,2,(LEN(@ColumName)))                      
  set @ColumName = ',' + @ColumName + ','                        
 End                      
                             
   set @Query = 'Select a.TargetID'+ISNULL(@ColumName,',')+'m.StockEntryID,Convert(varchar(11),m.EntryDate,113)as EntryDate,                    
     b.'+@ColumnLabel+',p.'+@ValueLabel+',('+@CalculateQuery+') as ['+@CalculateColumnName+'],m.UserName From                         
   StockEntryMain m                     
   inner join '+@FormNamne+'StockEntry p on p.StockEntryID=m.StockEntryID                    
   inner join '+@FormNamne+'Master b on p.'+@FormNamne+'ID = b.'+@FormNamne+'ID                    
   left join TargetMaster a on a.TargetID=m.TargetID ' + ISNULL(@Full_String,'') +'                             
   where CONVERT(varchar,EntryDate,102) between '''+ convert(varchar(20),@FromDate,102)+''' and '''+ convert(varchar(20),@ToDate,102) +''''+ @filterQuery +'
   AND m.EntryDate = (
    SELECT MAX(EntryDate)
    FROM StockEntryMain
    WHERE TargetID = m.TargetID
  ) ORDER BY EntryDate DESC'          
                                      
--print(@Query)     
exec (@Query)                                                      
End
go

