Create Proc DeleteFormField 

@FormFieldID int

As
Begin

Delete From FormFieldDetail where  FormFieldID=@FormFieldID
select '1'
END
go

