
CREATE PROCEDURE usp_GetCityNameforCloseCallReport  
AS  
BEGIN  
 SELECT * FROM dbo.CityMaster  
  WHERE Status='1'  
END
go

