                              
CREATE procedure [dbo].[SP_GetALL_DashboardQuery]                                                   
AS                                                  
BEGIN                                           
SET ANSI_WARNINGS OFF                                            
SET NOCOUNT ON                                      
                                    
truncate table [dbo].[SOSDashboard_Table]                                      
truncate table [dbo].[PromotionDashboard_Table]                                      
truncate table [dbo].[OOSDashboard_Table]                                    
truncate table [dbo].[AttandanceDashboard_Table]                   
truncate table [dbo].[VisibilityDashboard_Table]                   
                    
 --------------------Attendace--------------------------------------------------------------                      
INSERT INTO [dbo].[AttandanceDashboard_Table]                      
      ([Employee Name]                      
      ,[Date]                      
      ,[Attendancestatus]                      
      ,[InTime]                      
      ,[OutTime]                      
      ,[Hours Worked]                      
      --,[List of Stores Covered]                      
      ,[Region Name]                      
      ,[State]                      
      ,[City]              
   ,[TSE Name])       
   
      select UM.Fullname 'Employee Name' ,convert(nvarchar(10), getdate(),120) Date,                          
      CASE  upper(rtrim(lTRIM(isnull(AD.status,'Not Marked'))))                          
      when 'P' Then 'Present'                          
      when 'L' Then 'Leave'                          
      when 'H' Then 'Holiday'                          
      when 'WOFF' Then 'Week off'                          
      when 'T' Then 'Tour'                          
      when 'AO' Then 'At office'                          
      when 'HD' Then 'Half Day'                          
      else 'Not Marked'                          
      end                          
      'Attendance Status',                          
      isnull(convert(varchar(30),AD.createddate,120),'' ) 'In Time',                          
      isnull(convert(nvarchar(30),(select top 1 outtime from stockentrymain where username=UM.UserName                           
      and  convert(nvarchar(10), EntryDate,120) =convert(nvarchar(10), getdate(),120) order by outtime desc),120),'' ) 'Out Time',                          
      isnull(CAST(((select top 1 outtime from stockentrymain where username=UM.UserName                           
      and  convert(nvarchar(10), EntryDate,120) =convert(nvarchar(10), getdate(),120) order by outtime desc)- AD.createddate) as time(0)),'') 'Hours Worked',                          
     -- [dbo].[CommaSeparatedTargetByUsername](UM.UserName) 'List of Stores Covered',                          
      RM.Name Region,SM.Name State,CM.Name as City,'um.Tse_Name' as Tse_Name                          
      from usermaster UM                           
      left join Attendancedetail AD on UM.UserName=AD.username and date =convert(nvarchar(10), getdate(),120)                     
   --left join TargetMaster a on a.TargetID=AD.TargetID and a.Status = 1                
      left join citymaster CM on UM.CityID=CM.CityID                          
      left join statemaster SM on UM.StateID =SM.StateID                          
      left join Regionmaster RM on UM.RegionId = RM.RegionID                          
      where UM.status=1 and UM.RoleID='4' and UM.UserName not like 'default%'                        
              
--   --------------------Visibility--------------------------------------------------------------                    
                
-- INSERT INTO [dbo].[VisibilityDashboard_Table]                    
--      ([TargetID]                    
--      ,[Target Name]                    
--   ,[TSE Name]                
--     ,[Category Name]                    
-- ,[Chain Name]                    
--      ,[State Name]                
--   ,[Classification Name]                
--      ,[Format Name]                    
--      ,[Region Name]                    
--      ,[EntryDate]                    
--      ,[Visibility Name]                    
--     ,[Visibility Available]                    
--      ,[Visibility Remark]          
--   ,Brand          
--      ,[Visibility On but Article not linked in Store]        
--  ,[Visibility ON but LOW stock]        
--   ,[Visibility ON but Zero Stock]            
--   ,[Alternate Visibility at store level]            
--   ,[Visibility on]            
--   ,[Visibility on but inaccurate planogram]            
--   ,[Visibility on  but inaccurate stock placement due to store issue],          
--   [StockScore]          
--      ,[VisibilityScore %],[Target])
	  
--   select [TargetID] ,[Outlet name] ,[TSE Name],[Category Name], [Chain Name],[State Name],[Classification Name],                    
--      [Format Name],RH,                    
--      [EntryDate] ,                    
--      Visibility_Name, Visibility_Available, Visibility_Remark,Brand,    
--   (convert(varchar,TargetID)+ ' - ' +[Outlet name]) as Target    
--    from(            
--   select Tm.TargetName [Outlet name],Tm.TargetID [TargetID] ,Tm.Tse_Name as [TSE Name],cat.Name [Category Name],                     
--      ch.Name [Chain Name],'stm.Name' [State Name],ci.Name [Classification Name],'fm.Name' [Format Name] ,rm.Name [RH],            
--      CONVERT(varchar(10),sem.EntryDate,101) [EntryDate] ,sem.dActaulEntryDate [EntryDatewithTime],            
--      Question as Visibility_Name,ase.Status as Visibility_Available,ase.Remarks as Visibility_Remark,'Brand' as Brand from VisibilityStockEntry   ase            
--      inner join StockEntryMain sem on sem.StockEntryID=ase.StockEntryID                        
--      inner join TargetMaster Tm on Tm.TargetID= sem.TargetID  and Tm.Status = 1                       
--      inner join VisibilityMaster Pm on Pm.VisibilityID=ase.VisibilityID                        
--      inner join CategoryMaster cat on cat.CategoryID=Pm.CategoryID                        
--      inner join CityMaster cm on cm.CityID=Tm.CityID                       
--   Inner join ClassificationMaster ci on Tm.ClassificationID = ci.ClassificationID                
--      left join statemaster stm on stm.stateId =Tm.stateId                     
--      left join Chainmaster ch on ch.chainid=Tm.chainid                        
--      --inner join FormatMaster fm on fm.FormatID=Tm.FormatID                        
--      left join RegionMaster rm on rm.RegionID =Tm.RegionID         
--      where convert(nvarchar(10),EntryDate,102) between                     
--      CONVERT(nvarchar(10),DATEADD(month, DATEDIFF(month, 0, (getdate()-1)), 0),102) and CONVERT(nvarchar(10),getdate()-1,102)                    
--      )x                  
--      order by [Category Name]        
        
----------------------OOS--------------------------------------------------------------                      
                      
INSERT INTO [dbo].[OOSDashboard_Table]                      
      ([TargetID]                      
      ,[Chain Name]                      
      ,[Classification Name]                      
      ,[Format Name]                      
      ,[Region Name]                       
      ,[Target Name]                      
      ,[StockEntryID]                      
      ,[EntryDate]                
   ,[Brand Name]                
   ,[SKU Name]                      
   ,[Category Name]                           
   ,[No Stock]                              
   ,Available                      
   ,[Quantity]                
   ,[TSE Name]                   
 ,[Target]    
      )                      
      Select a.TargetID,cm.Name as 'Chain Name',ci.Name as 'Classification Name','fm.Name' as 'Format Name',                        
      rm.Name as 'Region Name',                        
      a.TargetName,m.StockEntryID,                        
      Convert(varchar,m.EntryDate,101)as EntryDate,'b.brand' brand,                                        
      b.SKU_Name,cat.name as 'Category',                        
      case  when p.SOH = 0 then 1 else 0 end as 'No Stock',                       
      --case When p.SOH != 0 then 1 else 0 end as 'Not Linked' ,                 
		case When p.SOH != 0 then 1 else 0 end as 'Available' ,             
      p.SOH as Quantity,a.TSE_Name as [TSE Name],(convert(varchar,a.TargetID)+ ' - ' +a.TargetName) as Target     
      From                                             
      StockEntryMain m                                         
      inner join AvailabilityStockEntry p on p.StockEntryID=m.StockEntryID                  
      Inner join AvailabilityMaster b on p.AvailabilityID = b.AvailabilityID           
      join AvailabilityRelation ar on ar.AvailabilityID = p.AvailabilityID and ar.TargetID = m.TargetID        
      Inner join TargetMaster a on a.TargetID=m.TargetID and a.Status = 1                       
      left join ChainMaster cm on a.ChainID = cm.ChainID                         
      Inner join ClassificationMaster ci on a.ClassificationID = ci.ClassificationID                         
      --Inner join FormatMaster fm on a.FormatID = fm.FormatID                         
      left join RegionMaster rm on a.RegionID = rm.RegionID                           
      Inner join CategoryMaster cat on cat.CategoryID = b.CategoryID                                           
      where convert(varchar(10),m.EntryDate,102) between                        
      CONVERT(nvarchar(10),DATEADD(month, DATEDIFF(month, 0, (getdate()-1)), 0),102)                         
      and CONVERT(nvarchar(10),getdate()-1,102)                          
      order by cat.Name           
          	
	--select * from FormMaster

----------------------Promotion--------------------------------------------------------------                      
-- INSERT INTO [dbo].[PromotionDashboard_Table]                      
--      ([TargetID]                      
--      ,[Target Name]                      
--      ,[Category Name]                   
--   ,[TSE Name]                
--      ,[Chain Name]                      
--      ,[Classification Name]                      
--      ,[Format Name]                      
--      ,[Region Name]                      
--      ,[EntryDate]                      
--      ,[Promotion Name]
--	  ,[Brand Name]
--      ,[Promo Status]                  
--   ,[Promo Remarks]                
--      ,[Yes]                      
--      ,[Promo SKU not mapped to the store]                  
--   ,[Less Than Offer Price]                  
--   ,[Cycle Not Active]                  
--   ,[No Code]                  
--   ,[No]                  
--   ,[No Stock]                  
--   ,[NA]                     
--      ,[Implemented %],[Target])   
	  
--      select [TargetID] ,[Outlet name] ,[Category],[TSE Name] , [Chain Name],[Classification Name],                      
--      [Format Name],RH,                      
--      [EntryDate] ,                      
--      Promo_SKU,Brand_Name, Promo_Status,[Promo Remarks],[Yes],[Promo SKU not mapped to the store],[Less Than Offer Price],[Cycle Not Active],[No Code],[No],[No Stock],[NA],                      
--   isnull(convert(decimal(18,2),                      
--      convert(decimal,([Yes]))*100/nullif(convert(decimal,                      
--      ([Yes]+[Promo SKU not mapped to the store]+[Less Than Offer Price]+ [Cycle Not Active] +     
--   [No Code] + [No] + [No Stock]+ [NA])),0)),0) 'Implemented %', (convert(varchar,TargetID)+ ' - ' +[Outlet name]) as Target from (                      
--      select   Tm.TargetName [Outlet name],Tm.TargetID [TargetID] ,cat.Name [Category],  Tm.TSE_Name as [TSE Name],                  
--      ch.Name [Chain Name],cal.Name [Classification Name],                      
--      fm.Name [Format Name] ,rm.Name [RH],                       
--      CONVERT(varchar(10),sem.EntryDate,101) [EntryDate] ,sem.dActaulEntryDate [EntryDatewithTime],                      
--      Promo_SKU,Brand_Name,Promo_Status,Promo_If_No_Remarks as [Promo Remarks],                      
--      case  when Promo_Status = 'Yes' then 1 else 0 end as 'Yes',                      
--      case  when (Promo_Status='Promo SKU not mapped to the store' ) then 1 else 0 end as 'Promo SKU not mapped to the store',                       
--      case  when (Promo_Status='Less Than Offer Price') then 1 else 0 end as 'Less Than Offer Price',                   
--   case  when (Promo_Status='Cycle Not Active') then 1 else 0 end as 'Cycle Not Active',                   
--     case  when (Promo_Status='No Stock') then 1 else 0 end as 'No Stock',                      
--      case  when (Promo_Status='No Code')then 1 else 0 end as 'No Code',                  
--   case  when (Promo_Status='No')then 1 else 0 end as 'No',                    
--   case  when (Promo_Status='NA')then 1 else 0 end as 'NA'                    
--      from ImplementationStockEntry pse                          
--      inner join StockEntryMain sem on sem.StockEntryID=pse.StockEntryID                          
--      inner join TargetMaster Tm on Tm.TargetID= sem.TargetID  and Tm.Status = 1                         
--      inner join Implementationmaster Pm on Pm.ImplementationID=pse.ImplementationID                          
--      inner join CategoryMaster cat on cat.CategoryID=Pm.CategoryID                          
--      inner join CityMaster cm on cm.CityID=Tm.CityID                          
--      inner join ClassificationMaster cal on cal.ClassificationID=Tm.ClassificationID                          
--      inner join ChainMaster ch on ch.ChainID=Tm.ChainID                          
--      inner join FormatMaster fm on fm.FormatID=Tm.FormatID                          
--      inner join RegionMaster rm on rm.RegionID =Tm.RegionID                          
--      where convert(nvarchar(10),EntryDate,102) between                       
--      CONVERT(nvarchar(10),DATEADD(month, DATEDIFF(month, 0, (getdate()-1)), 0),102) and CONVERT(nvarchar(10),getdate()-1,102))x                      
--      order by Category                 
                       
----------------------SOS--------------------------------------------------------------                      
                      
INSERT INTO [dbo].[SOSDashboard_Table]                      
      ([StockEntryID]                      
      ,[Target name]                      
      ,[TargetID]      
   ,[TSE Name]                
      ,[Chain Name]                      
      ,[Classification Name]                      
      ,[Format Name]                      
      ,[Region Name]                      
      ,[Category Name]                
   ,[Brand Name]                
      ,[EntryDate]                      
      ,[Industry Facing]                      
      ,[Our Brand Facing]                      
      ,[Our Brand],[Target])       
	  
      select sem.StockEntryID,Tm.TargetName,Tm.TargetID [TargetID] , Tm.Tse_Name as [TSE Name],                     
      ch.Name [Chain Name],                     
      cal.Name  [Classification Name],                     
fm.Name [Format Name],                     
      rm.Name [RH] ,cat.Name [Category Name],                
     sm.SOS,                
      CONVERT(varchar(10),sem.EntryDate,101) [EntryDate],sse.Industry_Facings,                      
      sse.Our_Brand_Facings                      
      --,(sse.Industry_Facing - sse.Our_Brand_Facing ) as 'Competitor'                      
      ,isnull(convert(decimal(18,1),(convert(decimal,sse.Our_Brand_Facings)*100/nullif(convert(decimal,                      
      sse.Industry_Facings),0))),0) as 'Our Brand' , (convert(varchar,Tm.TargetID)+ ' - ' +Tm.TargetName) as Target                   
      from SosStockEntry  sse                        
      inner join StockEntryMain sem on sem.StockEntryID=sse.StockEntryID                          
      inner join TargetMaster Tm on Tm.TargetID= sem.TargetID  and Tm.Status = 1                         
      inner join SosMaster sm on sm.SosID=sse.SosID           
	  left join Regionmaster rm on rm.RegionId=Tm.RegionId  
      left join SosRelation sr on sr.SOSID = sse.SOSID and sr.TargetID = TM.TargetID           
      inner join CategoryMaster cat on cat.CategoryID=sm.CategoryID                          
      inner join CityMaster cm on cm.CityID=Tm.CityID                          
      inner join ClassificationMaster cal on cal.ClassificationID=Tm.ClassificationID                          
      left join ChainMaster ch on ch.ChainID=Tm.ChainID                          
      left join FormatMaster fm on fm.FormatID=Tm.FormatID                          
                              
      where convert(nvarchar(10),EntryDate,102) between                       
      CONVERT(nvarchar(10),DATEADD(month, DATEDIFF(month, 0, (getdate()-1)), 0),102)                       
      and CONVERT(nvarchar(10),getdate()-1,102)                      
      order by cat.Name                                           
END
go

