CREATE Procedure [dbo].[GetAllFormFieldDetail] --'28'            
@FormID int,            
@Mode nvarchar(3)            
As            
Begin            
if(@Mode ='F')            
Begin            
Select FormFieldID,Name,FieldName, Required, ForPM,ForDEO,FormFieldDetail.FormID,DataType,      
ControlType,Fixed,UniqueField,Sequence,AnswerByPM    FRom FormFieldDetail           
inner join FormMaster on FormMaster.FormID=FormFieldDetail.FormID           
Where FormMaster.FormID=@FormID order by FieldName            
END            
            
IF(@Mode ='A')            
            
Begin            
Select FormID,FormFieldID,FormFieldOption FRom FormFieldOption            
Where FormFieldID =@FormID             
END            
            
end
go

