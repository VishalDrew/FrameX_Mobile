CREATE Procedure [dbo].[GetDetails]  --'TargetMaster'          
@tableName nvarchar(50)          
          
as
begin          
          
  SET nocount  ON          
    DECLARE  @imax INT,           
             @i    INT           
    DECLARE  @Contact VARCHAR(100),           
             @Company VARCHAR(50)           
                       
   DECLARE @MainTable nvarchar(60)          
   DECLARE @Full_String nvarchar(4000)          
   DECLARE @ColumName nvarchar(4000)          
   DECLARE @OrderBy nvarchar(4000)          
   set @MainTable='a';           
          
    DECLARE  @CompanyInfo  TABLE(           
                                 RowID       INT    IDENTITY ( 1 , 1 ),           
                                 CompanyName VARCHAR(100),           
                                 ContactName VARCHAR(50)           
                                 )           
    INSERT @CompanyInfo           
   SELECT          
    COLUMN_NAME,COLUMN_NAME          
FROM          
    INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc          
    INNER JOIN          
    INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE ccu ON tc.CONSTRAINT_NAME = ccu.Constraint_name          
WHERE          
    (          
                 
        tc.CONSTRAINT_TYPE = 'Foreign Key'          
    )          
    AND          
    tc.TABLE_NAME =@tableName          
             
               
    SET @imax = @@ROWCOUNT           
    SET @i = 1           
               
    WHILE (@i <= @imax)           
      BEGIN           
        SELECT @Contact = ContactName,           
               @Company = CompanyName           
        FROM   @CompanyInfo           
        WHERE  RowID = @i                  
                 
        set @ColumName=ISNULL(@ColumName,'') +',' +@Contact+'.Name as '''+REPLACE(@Contact,'ID',' Name') +'''';          
       set @Full_String=ISNULL(@Full_String,'') +  ' left join ' +  REPLACE(@Contact,'ID','Master') + ' ' +  @Contact +' on '+ @MainTable +'.'+ @Contact + ' = ' + @Contact +'.'+@Contact            
                            
        SET @i = @i + 1           
      END -- WHILE          
                
                  
      DECLARE @List VARCHAR(1000)          
          
     Select  @List =COALESCE(@List + ', ', '') + FieldName           
     From EnumFieldControlInfo          
     Where FormName=@tableName           
     set @List=  REPLACE(','+@list,',',',a.')          
      set @ColumName=  SUBSTRING(@ColumName,2,(LEN(@ColumName)))          
      -- select @ColumName          
       set @ColumName=  REPLACE(@ColumName,'.*.*','')          
           
          set @OrderBy= Replace(@TableName,'Master','Name')          
   EXEC('Select '+@ColumName+' '+@List+',a.Status From '+@tableName+' a ' + @Full_String +' Order By a.'+@OrderBy)    
   
    Print('Select '+@ColumName+' '+@List+',a.Status From '+@tableName+' a ' + @Full_String +' Order By a.'+@OrderBy)                
             
    SELECT          
    COLUMN_NAME,COLUMN_NAME          
FROM          
    INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc          
    INNER JOIN          
    INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE ccu ON tc.CONSTRAINT_NAME = ccu.Constraint_name          
WHERE          
    (          
                 
        tc.CONSTRAINT_TYPE = 'Foreign Key'          
       or  tc.CONSTRAINT_TYPE = 'Primary Key'          
    )          
    AND          
    tc.TABLE_NAME =@tableName          
END 


--select * from TargetMaster
go

