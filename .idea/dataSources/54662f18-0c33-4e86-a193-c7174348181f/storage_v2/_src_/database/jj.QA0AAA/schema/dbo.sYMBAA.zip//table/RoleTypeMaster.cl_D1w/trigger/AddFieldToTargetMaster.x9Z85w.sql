CREATE TRIGGER [dbo].[AddFieldToTargetMaster]  
ON dbo.RoleTypeMaster  
AFTER INSERT
AS   

BEGIN

	declare @query nvarchar(MAX),@username varchar(500), @RoleID varchar(50),@CreatedBy varchar(50)
	
	select @username = Name from inserted 
	
	select @RoleID = RoleID from inserted 
	
	select @CreatedBy = CreatedBy from inserted 

	insert into UserMaster (UserName,Password,Sequence,RoleID,CreatedBy,ModifiedBy,status,CreatedDate,ModifiedDate) 
							values ( 'default'+@username+'','default'+@username+'','6',@RoleID,@CreatedBy,@CreatedBy,'1',getdate(),getdate() ) 
	set @query='						
 	ALTER TABLE TargetMaster add ' +@username+ ' varchar(50) not null default (''default'+@username+''')'
 	
 	exec sp_executesql @query
END
go

