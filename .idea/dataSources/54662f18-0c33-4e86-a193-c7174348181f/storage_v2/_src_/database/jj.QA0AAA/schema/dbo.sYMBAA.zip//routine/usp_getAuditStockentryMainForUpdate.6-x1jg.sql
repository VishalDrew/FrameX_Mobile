CREATE procedure usp_getAuditStockentryMainForUpdate    
@TargetID int    
as    
begin    
    
  
select * from StockEntryMain SM  
inner join AuditEntryMain AM  
on AM.StockEntryId=sm.StockEntryID WHERE TargetID=@TargetID  
    
end

go

