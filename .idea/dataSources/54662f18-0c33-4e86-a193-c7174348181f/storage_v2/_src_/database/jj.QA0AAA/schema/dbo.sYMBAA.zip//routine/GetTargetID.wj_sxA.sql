CREATE Procedure GetTargetID-- 'cityid=23 and classificationid=3'    
@whereClause nvarchar(max)    
As    
BEGIN    
  
exec('select TargetID from TargetMaster where ' +@whereClause)  
    
END
go

