CREATE Procedure [dbo].[Getformdisplay] -- 'EQuestionsForm'           
@tableName nvarchar(100)                
                
as                
begin                
   Select fieldname,datatype,controltype AS FieldControlType,required AS Fieldvalidation,      
   FormFieldOptionID,FormFieldOption,UniqueField from FormFieldDetail            
    INNER JOIN formmaster ON formmaster.FormID = FormFieldDetail.FormID           
    LEFT JOIN FormFieldOption ON FormFieldOption.FormFieldID= FormFieldDetail.FormFieldID            
              
    Where name = @tableName  and ForPM='1' and FieldName<>'QuestionMode'          
    Order By FieldName            
              
              
              
  Select COLUMN_NAME,tc.TABLE_NAME From INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc INNER JOIN            
INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE ccu ON tc.CONSTRAINT_NAME = ccu.Constraint_name wHEre            
CONSTRAINT_TYPE='PRIMARY KEY' and COLUMN_NAME in (Select COLUMN_NAME From INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc INNER JOIN            
INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE ccu ON tc.CONSTRAINT_NAME = ccu.Constraint_name wHEre            
CONSTRAINT_TYPE='FOREIGN KEY' and tc.TABLE_NAME=@tableName+'Master')            
  end
go

