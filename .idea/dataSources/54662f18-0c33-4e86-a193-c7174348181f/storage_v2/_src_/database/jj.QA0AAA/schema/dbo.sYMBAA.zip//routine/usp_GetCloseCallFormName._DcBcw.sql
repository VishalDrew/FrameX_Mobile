CREATE PROCEDURE usp_GetCloseCallFormName  
AS  
BEGIN  
 SELECT ReportID, Name, FormID   
 FROM dbo.ReportBasicMaster   
 WHERE ColumnLabel='Reason'  
END
go

