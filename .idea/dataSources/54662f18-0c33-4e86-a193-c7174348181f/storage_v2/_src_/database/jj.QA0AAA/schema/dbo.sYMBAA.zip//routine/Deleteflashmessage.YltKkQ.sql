
CREATE Proc Deleteflashmessage
@id varchar(250)
AS
begin
Begin Try
Delete from flashmessageuser where msgid = @id
Delete From flashmessage where id = @id
Select 1
End Try
Begin Catch
Select 0
End Catch
end
go

