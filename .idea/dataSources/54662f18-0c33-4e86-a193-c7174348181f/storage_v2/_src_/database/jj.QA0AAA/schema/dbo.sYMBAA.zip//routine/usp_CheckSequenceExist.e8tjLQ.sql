create procedure usp_CheckSequenceExist  
@strQuery varchar(Max)  
as  
BEGIN  
  
EXEC(@strQuery)  
END
go

