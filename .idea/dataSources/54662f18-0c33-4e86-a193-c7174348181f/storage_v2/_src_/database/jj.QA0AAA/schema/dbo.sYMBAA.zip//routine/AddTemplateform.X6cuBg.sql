
CREATE Proc [dbo].[AddTemplateform]  --1  
@templateid int    
AS BEGIN    
begin try   
IF @templateid = 1      
BEGIN       
INSERT INTO FormMaster VALUES('Availability','1',1,'TargetID%','Grid',0,0,'defaultpm','defaultpm',GETDATE(),GETDATE())      
declare @formid int       
SELECT  @formid = FormId From Formmaster Where Name = 'Availability'    
INSERT INTO FormFieldDetail VALUES(@formid,'SKU','Varchar(500)','TextBox',1,1,1,0,1,5,0,0)      
INSERT INTO FormFieldDetail VALUES(@formid,'Qty','Int','TextBox',1,0,1,0,0,6,0,0)     
Alter Table  AvailabilityRelation Add CONSTRAINT fk_MasterRelationTargetAvailability FOREIGN KEY (TargetID) REFERENCES TargetMaster(TargetID)   
Update Templatemaster Set Status = 1 Where id = 1      
end      
ELSE if @templateid  = 2      
 Begin      
INSERT INTO FormMaster VALUES('Promotion','3',1,'TargetID%','Grid',0,0,'defaultpm','defaultpm',GETDATE(),GETDATE())      
declare @formidn int       
SELECT  @formidn = FormId From Formmaster Where Name = 'Promotion'       
 INSERT INTO FormFieldDetail VALUES(@formidn,'Promotion','Varchar(500)','TextBox',1,1,1,0,1,5,0,0)      
INSERT INTO FormFieldDetail VALUES(@formidn,'ImpStatus','Varchar(500)','DropDownList',1,0,1,0,0,6,0,0)   
declare @formfieldid int       
select @formfieldid =  FormFieldId From FormFieldDetail Where FormId = @formidn AND Fieldname = 'ImpStatus'  
Insert Into FormFieldOption VALUES (@formidn,@formfieldid,'Yes',0)      
Insert Into FormFieldOption VALUES (@formidn,@formfieldid,'No',0)      
  
Alter Table  PromotionRelation Add CONSTRAINT fk_MasterRelationTargetPromotion FOREIGN KEY (TargetID) REFERENCES TargetMaster(TargetID)   
Update Templatemaster Set Status = 1 Where id = 2      
end      
ELSE if @templateid  = 3      
 Begin      
INSERT INTO FormMaster VALUES('Sos','1',1,'TargetID%','Grid',0,0,'defaultpm','defaultpm',GETDATE(),GETDATE())      
declare @formidnm int       
SELECT  @formidnm = FormId From Formmaster Where Name = 'Sos'        
 INSERT INTO FormFieldDetail VALUES(@formidnm,'Sos','Varchar(500)','TextBox',1,1,1,0,1,5,0,0)      
INSERT INTO FormFieldDetail VALUES(@formidnm,'Industry_Facing','Int','TextBox',1,0,1,0,0,6,0,0)      
INSERT INTO FormFieldDetail VALUES(@formidnm,'Brand_Facing','Int','TextBox',1,0,1,0,0,7,0,0)      
Alter Table  SosRelation Add CONSTRAINT fk_MasterRelationTargetSos FOREIGN KEY (TargetID) REFERENCES TargetMaster(TargetID)   
Update Templatemaster Set Status = 1 Where id = 3      
end      
Select 1
end try
begin catch
select 0
end catch      
END
go

