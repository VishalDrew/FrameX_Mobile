CREATE procedure usp_alterstockeentryform --'GeneralQuestionForm'      
@FormName varchar(200)      
as      
begin      
declare @strQuer varchar(max)  
declare @isQuestion varchar(10)  
set @isQuestion=(select IsQuestionForm from FormMaster where Name=@FormName)  
select @isQuestion  
IF (@isQuestion ='1')  
BEGIN  
-- select * from FormMaster  
 set @strQuer='alter table '+@FormName+'StockEntry Add QuestionMode varchar(300)  alter table MOB'+@FormName+'StockEntry Add QuestionMode varchar(300)'      
END  
--print (@strQuer)      
exec (@strQuer)      
end      
      
      
--select * from EQuestionsFormStockEntry  
  
--select * from FormMaster
go

