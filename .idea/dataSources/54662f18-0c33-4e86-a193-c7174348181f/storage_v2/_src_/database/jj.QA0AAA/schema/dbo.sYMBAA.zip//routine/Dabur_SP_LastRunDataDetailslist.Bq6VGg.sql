                   
create PROCEDURE [dbo].[Dabur_SP_LastRunDataDetailslist] --'8','2020'              
             
AS              
BEGIN   
DECLARE @DATE DATETIME
SET @DATE=getdate()-1
select Count(*) as RecordCount,CONVERT(nvarchar(10),(@DATE-DAY(@DATE)+1),105) as FromDate,CONVERT(nvarchar(10),@DATE,105) as Todate from SOSDashboard_Table       
END


go

