CREATE procedure usp_getDumpreportdetails --'Program_Question',' where SM.EntryDate  between ''2014.11.27'' and ''2014.11.28'' and SM.RoleID in(4) AND ( TM.CityID =''23'' ) AND ( TM.ClassificationID =''3'' )'
@TableName varchar(200),  
@Condition nvarchar(MAX) 
  
  
as
begin  
                
Declare @ColumName nvarchar(100),                                    
        @ColumID nvarchar(100),                                     
                                     
        @MasterTableName nvarchar(100),                      
        @StockEntryTableName nvarchar(100)                      
                                            
        --Set @ColumName =@TableName+'Name'                                    
        Set @ColumID =@TableName+'ID'         
                                         
        Set @MasterTableName =@TableName+'Master'                                    
        Set @StockEntryTableName =@TableName+'StockEntry'                                    
  
  
declare @isQuestionForm int  
set @isQuestionForm=(select IsQuestionForm from FormMaster where Name=@TableName)  
                    
DECLARE @cols nVARCHAR(MAX)                            
   
if @isQuestionForm='1'  
BEGIN  
  
  
                 
              
select @cols= COALESCE(@cols + ',' + FieldName + '','' +  FieldName + '') from FormFieldDetail inner join                             
FormMaster on FormMaster.FormID=FormFieldDetail.FormID                            
where FormMaster.Name=@TableName  AND FieldName <> 'QuestionMode'                           
and ForQDEO='True'  
                 
                
if (@cols is null)                  
begin                  
return                  
end                  
else                  
begin   
                           
     
 Exec( ' select SM.StockEntryID,'+@cols+',PQ.QuestionMode from '+@StockEntryTableName+' PQ inner join  
StockEntryMain SM  
on PQ.StockEntryID=SM.StockEntryID  
inner join '+@MasterTableName+' PM  
on PM.'+@ColumID+'=PQ.'+@ColumID+'  
inner join TargetMaster TM on TM.TargetID=SM.TargetID '+@Condition+'')  
                                    
 end      
 END  
Else  
 BEGIN  
   
   select @cols= COALESCE(@cols + ',' + FieldName + '','' +  FieldName + '') from FormFieldDetail inner join                       
FormMaster on FormMaster.FormID=FormFieldDetail.FormID                      
where FormMaster.Name=@TableName                     
and ForDEO='True'      
         
if (@cols is null)            
begin            
return            
end            
else            
begin                      
    
    
      
 Exec( ' select SM.StockEntryID,'+@cols+' from '+@StockEntryTableName+' PQ inner join  
StockEntryMain SM  
on PQ.StockEntryID=SM.StockEntryID  
inner join '+@MasterTableName+' PM  
on PM.'+@ColumID+'=PQ.'+@ColumID+'  
inner join TargetMaster TM on TM.TargetID=SM.TargetID  '+@Condition+'')  
                                   
                                   
         
      
    end  
 END                          
              
         
       end
go

