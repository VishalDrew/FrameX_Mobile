
CREATE Procedure getflashmessageuser    
AS
BEGIN    
Select UserName+' ('+Name+')' as users,UserName From UserMaster UM    
INNER JOIN RoleMaster RM ON RM.RoleID = UM.RoleID    
Where UserName not in('defaultadmin','defaultpm','defaultsupervisor','defaultmerchandiser')
ORDER by RM.RoleID,UserName    
end
go

