CREATE procedure usp_GetFormForDataTable        
as
begin        
         
create table #tempMap        
(Name varchar(300),        
Mapwith varchar(100),        
ROwId int        
)        

create table #temp2
(Name varchar(200),Formmpawith varchar(300),ColID int)
insert into #temp2
select Name, FormMapWith, ROW_NUMBER()over(order by FormSequence) from FormMaster where FormStatus=1 order by FormSequence        


create table #temp1
(Name varchar(300))
		  
Insert into #temp1
Select  Name  From FormMaster                             
		  inner join FormFieldDetail on FormMaster.FormID=FormFieldDetail.FormID                              
		Where ForDEO='True' and ForPM = 'False'  
		union
		  	Select Name  From FormMaster                                     
		  inner join FormFieldDetail on FormMaster.FormID=FormFieldDetail.FormID                                      
		Where ForPM=1 and Fixed=1 and ForDEO=0 and ForQDEO=1              
		UNION              
			   Select Name From FormMaster                                     
			  inner join FormFieldDetail on FormMaster.FormID=FormFieldDetail.FormID                                      
			Where ForPM=0 and Fixed=0 and ForDEO=1 and ForQDEO=1
	
  
 -- Insert into #tempMap
 -- select  a.Name,a.Formmpawith,a.ColID from #temp2 a Inner join #temp1 b
 --on a.Name=b.Name

  Insert into #tempMap
  select  a.Name,a.Formmpawith,ROW_NUMBER()over(order by ColID) from #temp2 a Inner join #temp1 b
 on a.Name=b.Name order by ColID 
  
  drop table #temp1  
			
drop table #temp2
        
--select Name, FormMapWith, ROW_NUMBER()over(order by FormSequence) from FormMaster where FormStatus=1 order by FormSequence        

create table #tempFinal        
  (MapColumn varchar(300),        
  TableName varchar(300))        
        
        
declare @from int        
set @from=1        
declare @to int        
        
set @to =(select COUNT(*)+1 from #tempMap)
     
        
while @from<@to        
 begin        
  declare @mapValue varchar(300)        
  declare @Name varchar(300)        
  set @mapValue = (select Mapwith from #tempMap where ROwId=@from)        
  set @Name = (select Name from #tempMap where ROwId=@from)        
          
  declare @vValue varchar(300)        
  set @vValue=(select substring(@mapValue,1,len(@mapValue)-1))        
  create table #mpValue        
  (id int,        
  MapName varchar(300))        
  insert into #mpValue        
  select top 10 * from dbo.split(@vValue,'%')        
  declare @frm int        
  set @frm=1        
  declare @tm int        
  set @tm=(select COUNT(*)+1 from #mpValue)        
  while @frm <@tm        
   begin        
    declare @mVal varchar(300)        
    set @mVal = (select MapName from #mpValue where id=@frm)        
    insert into #tempFinal        
    values(@mVal,@Name+'Relation')        
    set @frm=@frm+1        
   end        
          
  drop table #mpValue        
  set @from=@from+1        
 end        
        
        
DECLARE @List VARCHAR(1000)         
select @List =COALESCE(@List + ', ', '') + MapColumn+'/'+TableName From #tempFinal         
Select @List         

select Name, FormMapWith from FormMaster where FormStatus=1 
EXCEPT 
select Name,        
Mapwith from #tempMap      

         
drop table #tempFinal        
drop Table #tempMap        
        
--select * from FormMaster        
end
go

