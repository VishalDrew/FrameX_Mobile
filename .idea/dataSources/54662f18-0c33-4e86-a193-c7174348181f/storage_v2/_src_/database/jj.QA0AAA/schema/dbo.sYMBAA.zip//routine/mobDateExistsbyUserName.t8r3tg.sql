CREATE Procedure [dbo].[mobDateExistsbyUserName]            
@EntryDate date,                    
@roleid int,              
@targetid int,    
@username varchar(50)                  
As                    
Begin                    
if  exists(Select * FROM StockEntryMain WHERE Convert(date, EntryDate)=@EntryDate and roleid=@roleid and TargetID=@targetid and username=@username)                    
 begin                    
  select 'True'                    
 END                    
ELSE                    
 Begin                    
  select 'False'                  
 END                    
END 
go

